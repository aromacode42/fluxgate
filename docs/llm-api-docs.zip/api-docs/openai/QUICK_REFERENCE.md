# OpenAI API — Quick Reference

A condensed lookup card for the most-used endpoints. For the full method-level reference, see `API_REFERENCE.md`.

**Base URL:** `https://api.openai.com/v1`
**Required headers:**
- `Authorization: Bearer sk-...`
- `Content-Type: application/json`
- Optional: `OpenAI-Organization: org-...`, `OpenAI-Project: proj_...`, `OpenAI-Beta: assistants=v2`

---

## Two parallel chat APIs

OpenAI now offers two top-level chat APIs. **Both work; pick one per project:**

| | `/v1/chat/completions` | `/v1/responses` |
|---|---|---|
| Style | stateless messages in/out | stateful with optional state |
| Tools | client-defined tools | client tools + built-in (`web_search`, `code_interpreter`, `file_search`) |
| Streaming | SSE | SSE with richer event types |
| Models | all models | newer models, recommended for agentic use |
| Recommendation | familiar, broadly supported | recommended for new code |

---

## `/v1/chat/completions` — classic chat

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-5.5",
    "messages": [
      {"role": "system", "content": "You are helpful."},
      {"role": "user",   "content": "Hello"}
    ]
  }'
```

Required: `model`, `messages`.

Notable optional fields:
- `max_completion_tokens` (preferred) / `max_tokens` (legacy)
- `temperature` (0..2; default 1) — **ignored for o-series and GPT-5 reasoning modes**
- `top_p`, `frequency_penalty`, `presence_penalty`, `seed`
- `tools` — array of tool definitions
- `tool_choice` — `"auto" | "none" | "required" | {"type":"function","function":{"name":"..."}}`
- `response_format` — `{"type":"json_schema","json_schema":{...}}` or `{"type":"json_object"}`
- `stream` — boolean
- `stream_options.include_usage` — include token counts in stream
- `reasoning_effort` — `"low" | "medium" | "high"` (reasoning models only)
- `parallel_tool_calls` — bool, default true
- `user` — opaque end-user identifier
- `n` — number of completions
- `logprobs`, `top_logprobs`

Tool definition:
```json
{
  "type": "function",
  "function": {
    "name": "get_weather",
    "description": "Get current weather for a location",
    "parameters": {
      "type": "object",
      "properties": {"location": {"type": "string"}},
      "required": ["location"]
    },
    "strict": true
  }
}
```

---

## `/v1/responses` — newer responses API

```bash
curl https://api.openai.com/v1/responses \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-5.5",
    "input": "Hello",
    "instructions": "You are helpful."
  }'
```

Or with messages-style input:
```json
{
  "model": "gpt-5.5",
  "input": [
    {"role": "user", "content": [{"type": "input_text", "text": "Hello"}]}
  ],
  "tools": [{"type": "web_search"}],
  "store": true
}
```

Notable fields:
- `input` — string or array of input items
- `instructions` — system-prompt-equivalent
- `tools` — including built-ins: `{"type":"web_search"}`, `{"type":"code_interpreter","container":{"type":"auto"}}`, `{"type":"file_search","vector_store_ids":[...]}`, `{"type":"computer_use_preview","display_width":1024,"display_height":768,"environment":"browser"}`
- `store` — bool, persist on server for retrieval
- `previous_response_id` — chain off prior response
- `reasoning` — `{"effort":"medium","summary":"auto"}`
- `text.format` — `{"type":"json_schema","schema":{...}}`

Retrieval: `GET /v1/responses/{id}`, list items: `GET /v1/responses/{id}/input_items`

---

## Embeddings

### `POST /v1/embeddings`
```json
{
  "model": "text-embedding-3-large",
  "input": "Your text here",
  "dimensions": 1536,
  "encoding_format": "float"
}
```
- `input` can be a string or array of strings (batch)
- `dimensions` lets you reduce vector size (only for `text-embedding-3-*`)

---

## Audio

| Endpoint | Purpose |
|---|---|
| `POST /v1/audio/speech` | TTS — body: `{model, input, voice}` |
| `POST /v1/audio/transcriptions` | STT (Whisper) |
| `POST /v1/audio/translations` | STT + translate to English |

For real-time voice, use `/v1/realtime` (WebSocket).

---

## Images

### `POST /v1/images/generations`
```json
{
  "model": "gpt-image-1",
  "prompt": "A futuristic cityscape at dusk",
  "size": "1024x1024",
  "quality": "high",
  "n": 1
}
```

Also: `/v1/images/edits`, `/v1/images/variations` (variations are `dall-e-2` only).

---

## Files & Vector Stores

### Files (all uploaded data)
- `POST /v1/files` — multipart upload, requires `purpose` field (`assistants`, `batch`, `fine-tune`, `user_data`, `evals`, `vision`)
- `GET /v1/files` — list
- `GET /v1/files/{id}/content` — download content

### Vector Stores (for file_search)
- `POST /v1/vector_stores`
- `POST /v1/vector_stores/{id}/files` (or `/file_batches`)
- `POST /v1/vector_stores/{id}/search` (search within store)

---

## Batch API

50% discount, async, ~24h SLA. Submit a JSONL file of `{"custom_id":"...","method":"POST","url":"/v1/chat/completions","body":{...}}` lines.

```bash
# 1. Upload JSONL
POST /v1/files (purpose=batch) -> file_id

# 2. Create batch
POST /v1/batches { "input_file_id": "...", "endpoint": "/v1/chat/completions", "completion_window": "24h" }

# 3. Poll
GET /v1/batches/{id}

# 4. Download results
GET /v1/files/{output_file_id}/content
```

---

## Models

- `GET /v1/models` — list all available
- `GET /v1/models/{id}` — single

---

## Fine-tuning

`/v1/fine_tuning/jobs` — create, list, retrieve, cancel; `/v1/fine_tuning/jobs/{id}/events`, `/checkpoints`. Most current method.

---

## Moderation

`POST /v1/moderations` — body: `{model:"omni-moderation-latest", input:"..."}`. Free.

---

## Rate limits

Returned in headers on every response:
- `x-ratelimit-limit-requests`, `x-ratelimit-remaining-requests`, `x-ratelimit-reset-requests`
- `x-ratelimit-limit-tokens`, `x-ratelimit-remaining-tokens`, `x-ratelimit-reset-tokens`

429 response body includes `Retry-After` header.

---

## Errors

```json
{
  "error": {
    "message": "...",
    "type": "invalid_request_error",
    "param": "model",
    "code": "model_not_found"
  }
}
```

---

## Realtime API

`wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview`

WebSocket protocol with session events for low-latency voice and tool use. See `client.realtime` in `API_REFERENCE.md` for the SDK helpers.

---

## OpenAI-compatible third-party endpoints

The `/v1/chat/completions` shape is widely supported by other providers as a compatibility layer:
- Anthropic: `https://api.anthropic.com/v1/...` with the OpenAI-compat shim
- Google: Vertex AI has an OpenAI-compatible endpoint
- Many self-hosted servers (vLLM, Ollama, LM Studio)

Switch by changing only `base_url`, `api_key`, and `model`.
