# OpenAI Python SDK — API Reference

**SDK Version:** `2.32.0`
**API Base URL:** `https://api.openai.com/v1`
**API Version:** v1 (path-based)

> Auto-generated from SDK introspection. Method signatures are extracted directly from the official SDK.

---

## Top-level Resources on `OpenAI` client

| Resource | Class | Description |
|---|---|---|
| `client.audio` | `Audio` |  |
| `client.batches` | `Batches` | Create large batches of API requests to run asynchronously. |
| `client.beta` | `Beta` |  |
| `client.chat` | `Chat` |  |
| `client.completions` | `Completions` | Given a prompt, the model will return one or more predicted completions, and can |
| `client.containers` | `Containers` |  |
| `client.conversations` | `Conversations` | Manage conversations and conversation items. |
| `client.embeddings` | `Embeddings` | Get a vector representation of a given input that can be easily consumed by mach |
| `client.evals` | `Evals` | Manage and run evals in the OpenAI platform. |
| `client.files` | `Files` | Files are used to upload documents that can be used with features like Assistant |
| `client.fine_tuning` | `FineTuning` |  |
| `client.images` | `Images` | Given a prompt and/or an input image, the model will generate a new image. |
| `client.models` | `Models` | List and describe the various models available in the API. |
| `client.moderations` | `Moderations` | Given text and/or image inputs, classifies if those inputs are potentially harmf |
| `client.qs` | `Querystring` |  |
| `client.realtime` | `Realtime` |  |
| `client.responses` | `Responses` |  |
| `client.skills` | `Skills` |  |
| `client.timeout` | `Timeout` | Timeout configuration. |
| `client.uploads` | `Uploads` | Use Uploads to upload large files in multiple parts. |
| `client.vector_stores` | `VectorStores` |  |
| `client.videos` | `Videos` |  |
| `client.webhooks` | `Webhooks` |  |
| `client.with_raw_response` | `OpenAIWithRawResponse` |  |
| `client.with_streaming_response` | `OpenAIWithStreamedResponse` |  |

---

## `client.audio`

### Sub-resource: `speech`

#### `create(*, input: 'str', model: 'Union[str, SpeechModel]', voice: 'speech_create_params.Voice', instructions: 'str | Omit' = OMIT, response_format: "Literal['mp3', 'opus', 'aac', 'flac', 'wav', 'pcm'] | Omit" = OMIT, speed: 'float | Omit' = OMIT, stream_format: "Literal['sse', 'audio'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Generates audio from the input text.

Returns the audio file content, or a stream of audio events.

Args:
  input: The text to generate audio for. The maximum length is 4096 characters.

  model:
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, input: 'str', model: 'Union[str, SpeechModel]', voice: 'speech_create_params.Voice', instructions: 'str | Omit' = OMIT, response_format: "Literal['mp3', 'opus', 'aac', 'flac', 'wav', 'pcm'] | Omit" = OMIT, speed: 'float | Omit' = OMIT, stream_format: "Literal['sse', 'audio'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Generates audio from the input text.

Returns the audio file content, or a stream of audio events.

Args:
  input: The text to generate audio for. The maximum length is 4096 characters.

  model:
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, input: 'str', model: 'Union[str, SpeechModel]', voice: 'speech_create_params.Voice', instructions: 'str | Omit' = OMIT, response_format: "Literal['mp3', 'opus', 'aac', 'flac', 'wav', 'pcm'] | Omit" = OMIT, speed: 'float | Omit' = OMIT, stream_format: "Literal['sse', 'audio'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Generates audio from the input text.

Returns the audio file content, or a stream of audio events.

Args:
  input: The text to generate audio for. The maximum length is 4096 characters.

  model:
...
```

### Sub-resource: `transcriptions`

#### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', chunking_strategy: 'Optional[transcription_create_params.ChunkingStrategy] | Omit' = OMIT, include: 'List[TranscriptionInclude] | Omit' = OMIT, known_speaker_names: 'SequenceNotStr[str] | Omit' = OMIT, known_speaker_references: 'SequenceNotStr[str] | Omit' = OMIT, language: 'str | Omit' = OMIT, prompt: 'str | Omit' = OMIT, response_format: 'Union[AudioResponseFormat, Omit]' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, timestamp_granularities: "List[Literal['word', 'segment']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str | Transcription | TranscriptionDiarized | TranscriptionVerbose | Stream[TranscriptionStreamEvent]'`

#### Sub-resource: `with_raw_response`

##### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', chunking_strategy: 'Optional[transcription_create_params.ChunkingStrategy] | Omit' = OMIT, include: 'List[TranscriptionInclude] | Omit' = OMIT, known_speaker_names: 'SequenceNotStr[str] | Omit' = OMIT, known_speaker_references: 'SequenceNotStr[str] | Omit' = OMIT, language: 'str | Omit' = OMIT, prompt: 'str | Omit' = OMIT, response_format: 'Union[AudioResponseFormat, Omit]' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, timestamp_granularities: "List[Literal['word', 'segment']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str | Transcription | TranscriptionDiarized | TranscriptionVerbose | Stream[TranscriptionStreamEvent]'`

#### Sub-resource: `with_streaming_response`

##### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', chunking_strategy: 'Optional[transcription_create_params.ChunkingStrategy] | Omit' = OMIT, include: 'List[TranscriptionInclude] | Omit' = OMIT, known_speaker_names: 'SequenceNotStr[str] | Omit' = OMIT, known_speaker_references: 'SequenceNotStr[str] | Omit' = OMIT, language: 'str | Omit' = OMIT, prompt: 'str | Omit' = OMIT, response_format: 'Union[AudioResponseFormat, Omit]' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, timestamp_granularities: "List[Literal['word', 'segment']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str | Transcription | TranscriptionDiarized | TranscriptionVerbose | Stream[TranscriptionStreamEvent]'`

### Sub-resource: `translations`

#### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', prompt: 'str | Omit' = OMIT, response_format: "Union[Literal['json', 'text', 'srt', 'verbose_json', 'vtt'], Omit]" = OMIT, temperature: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Translation | TranslationVerbose | str'`

```
Translates audio into English.

Args:
  file: The audio file object (not file name) translate, in one of these formats: flac,
      mp3, mp4, mpeg, mpga, m4a, ogg, wav, or webm.

  model: ID of the model to use. Only `whisper-1` (which is powered by our open source
      Whisper V2 model) is currently available.
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', prompt: 'str | Omit' = OMIT, response_format: "Union[Literal['json', 'text', 'srt', 'verbose_json', 'vtt'], Omit]" = OMIT, temperature: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Translation | TranslationVerbose | str'`

```
Translates audio into English.

Args:
  file: The audio file object (not file name) translate, in one of these formats: flac,
      mp3, mp4, mpeg, mpga, m4a, ogg, wav, or webm.

  model: ID of the model to use. Only `whisper-1` (which is powered by our open source
      Whisper V2 model) is currently available.
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, file: 'FileTypes', model: 'Union[str, AudioModel]', prompt: 'str | Omit' = OMIT, response_format: "Union[Literal['json', 'text', 'srt', 'verbose_json', 'vtt'], Omit]" = OMIT, temperature: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Translation | TranslationVerbose | str'`

```
Translates audio into English.

Args:
  file: The audio file object (not file name) translate, in one of these formats: flac,
      mp3, mp4, mpeg, mpga, m4a, ogg, wav, or webm.

  model: ID of the model to use. Only `whisper-1` (which is powered by our open source
      Whisper V2 model) is currently available.
...
```

---

## `client.batches`

Create large batches of API requests to run asynchronously.

### `cancel(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Cancels an in-progress batch.

The batch will be in status `cancelling` for up to
10 minutes, before changing to `cancelled`, where it will have partial results
(if any) available in the output file.

Args:
  extra_headers: Send extra headers
...
```

### `create(*, completion_window: "Literal['24h']", endpoint: "Literal['/v1/responses', '/v1/chat/completions', '/v1/embeddings', '/v1/completions', '/v1/moderations', '/v1/images/generations', '/v1/images/edits', '/v1/videos']", input_file_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, output_expires_after: 'batch_create_params.OutputExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Creates and executes a batch from an uploaded file of requests

Args:
  completion_window: The time frame within which the batch should be processed. Currently only `24h`
      is supported.

  endpoint: The endpoint to be used for all requests in the batch. Currently
      `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`, `/v1/completions`,
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Batch]'`

```
List your organization's batches.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

### `retrieve(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Retrieves a batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_raw_response`

#### `cancel(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Cancels an in-progress batch.

The batch will be in status `cancelling` for up to
10 minutes, before changing to `cancelled`, where it will have partial results
(if any) available in the output file.

Args:
  extra_headers: Send extra headers
...
```

#### `create(*, completion_window: "Literal['24h']", endpoint: "Literal['/v1/responses', '/v1/chat/completions', '/v1/embeddings', '/v1/completions', '/v1/moderations', '/v1/images/generations', '/v1/images/edits', '/v1/videos']", input_file_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, output_expires_after: 'batch_create_params.OutputExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Creates and executes a batch from an uploaded file of requests

Args:
  completion_window: The time frame within which the batch should be processed. Currently only `24h`
      is supported.

  endpoint: The endpoint to be used for all requests in the batch. Currently
      `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`, `/v1/completions`,
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Batch]'`

```
List your organization's batches.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Retrieves a batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_streaming_response`

#### `cancel(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Cancels an in-progress batch.

The batch will be in status `cancelling` for up to
10 minutes, before changing to `cancelled`, where it will have partial results
(if any) available in the output file.

Args:
  extra_headers: Send extra headers
...
```

#### `create(*, completion_window: "Literal['24h']", endpoint: "Literal['/v1/responses', '/v1/chat/completions', '/v1/embeddings', '/v1/completions', '/v1/moderations', '/v1/images/generations', '/v1/images/edits', '/v1/videos']", input_file_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, output_expires_after: 'batch_create_params.OutputExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Creates and executes a batch from an uploaded file of requests

Args:
  completion_window: The time frame within which the batch should be processed. Currently only `24h`
      is supported.

  endpoint: The endpoint to be used for all requests in the batch. Currently
      `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`, `/v1/completions`,
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Batch]'`

```
List your organization's batches.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Retrieves a batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.beta`

### Sub-resource: `assistants`

#### `create(*, model: 'Union[str, ChatModel]', description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_create_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Create an assistant with a model and instructions.

Args:
  model: ID of the model to use. You can use the
      [List models](https://platform.openai.com/docs/api-reference/models/list) API to
      see all of your available models, or see our
      [Model overview](https://platform.openai.com/docs/models) for descriptions of
      them.
...
```

#### `delete(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantDeleted'`

```
Delete an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Assistant]'`

```
Returns a list of assistants.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Retrieves an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(assistant_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: "Union[str, Literal['gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.5-preview', 'gpt-4.5-preview-2025-02-27', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613']] | Omit" = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_update_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Modifies an assistant.

Args:
  description: The description of the assistant.

The maximum length is 512 characters.

  instructions: The system instructions that the assistant uses. The maximum length is 256,000
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, model: 'Union[str, ChatModel]', description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_create_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Create an assistant with a model and instructions.

Args:
  model: ID of the model to use. You can use the
      [List models](https://platform.openai.com/docs/api-reference/models/list) API to
      see all of your available models, or see our
      [Model overview](https://platform.openai.com/docs/models) for descriptions of
      them.
...
```

##### `delete(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantDeleted'`

```
Delete an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Assistant]'`

```
Returns a list of assistants.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Retrieves an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(assistant_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: "Union[str, Literal['gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.5-preview', 'gpt-4.5-preview-2025-02-27', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613']] | Omit" = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_update_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Modifies an assistant.

Args:
  description: The description of the assistant.

The maximum length is 512 characters.

  instructions: The system instructions that the assistant uses. The maximum length is 256,000
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, model: 'Union[str, ChatModel]', description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_create_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Create an assistant with a model and instructions.

Args:
  model: ID of the model to use. You can use the
      [List models](https://platform.openai.com/docs/api-reference/models/list) API to
      see all of your available models, or see our
      [Model overview](https://platform.openai.com/docs/models) for descriptions of
      them.
...
```

##### `delete(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantDeleted'`

```
Delete an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Assistant]'`

```
Returns a list of assistants.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(assistant_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Retrieves an assistant.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(assistant_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: "Union[str, Literal['gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.5-preview', 'gpt-4.5-preview-2025-02-27', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613']] | Omit" = OMIT, name: 'Optional[str] | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_resources: 'Optional[assistant_update_params.ToolResources] | Omit' = OMIT, tools: 'Iterable[AssistantToolParam] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Assistant'`

```
Modifies an assistant.

Args:
  description: The description of the assistant.

The maximum length is 512 characters.

  instructions: The system instructions that the assistant uses. The maximum length is 256,000
...
```

### Sub-resource: `realtime`

#### `connect(*, model: 'str', extra_query: 'Query' = {}, extra_headers: 'Headers' = {}, websocket_connection_options: 'WebsocketConnectionOptions' = {}) -> 'RealtimeConnectionManager'`

```
The Realtime API enables you to build low-latency, multi-modal conversational experiences. It currently supports text and audio as both input and output, as well as function calling.

Some notable benefits of the API include:

- Native speech-to-speech: Skipping an intermediate text format means low latency and nuanced output.
- Natural, steerable voices: The models have natural inflection and can laugh, whisper, and adhere to tone direction.
- Simultaneous multimodal output: Text is useful for moderation; faster-than-realtime audio ensures stable playback.

...
```

#### Sub-resource: `sessions`

##### `create(*, client_secret: 'session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, instructions: 'str | NotGiven' = NOT_GIVEN, max_response_output_tokens: "Union[int, Literal['inf']] | NotGiven" = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, model: "Literal['gpt-realtime', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17'] | NotGiven" = NOT_GIVEN, output_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, speed: 'float | NotGiven' = NOT_GIVEN, temperature: 'float | NotGiven' = NOT_GIVEN, tool_choice: 'str | NotGiven' = NOT_GIVEN, tools: 'Iterable[session_create_params.Tool] | NotGiven' = NOT_GIVEN, tracing: 'session_create_params.Tracing | NotGiven' = NOT_GIVEN, turn_detection: 'session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, voice: "Union[str, Literal['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse']] | NotGiven" = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SessionCreateResponse'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API. Can be configured with the same session parameters as the
`session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

##### Sub-resource: `with_raw_response`

###### `create(*, client_secret: 'session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, instructions: 'str | NotGiven' = NOT_GIVEN, max_response_output_tokens: "Union[int, Literal['inf']] | NotGiven" = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, model: "Literal['gpt-realtime', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17'] | NotGiven" = NOT_GIVEN, output_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, speed: 'float | NotGiven' = NOT_GIVEN, temperature: 'float | NotGiven' = NOT_GIVEN, tool_choice: 'str | NotGiven' = NOT_GIVEN, tools: 'Iterable[session_create_params.Tool] | NotGiven' = NOT_GIVEN, tracing: 'session_create_params.Tracing | NotGiven' = NOT_GIVEN, turn_detection: 'session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, voice: "Union[str, Literal['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse']] | NotGiven" = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SessionCreateResponse'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API. Can be configured with the same session parameters as the
`session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

##### Sub-resource: `with_streaming_response`

###### `create(*, client_secret: 'session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, instructions: 'str | NotGiven' = NOT_GIVEN, max_response_output_tokens: "Union[int, Literal['inf']] | NotGiven" = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, model: "Literal['gpt-realtime', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17'] | NotGiven" = NOT_GIVEN, output_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, speed: 'float | NotGiven' = NOT_GIVEN, temperature: 'float | NotGiven' = NOT_GIVEN, tool_choice: 'str | NotGiven' = NOT_GIVEN, tools: 'Iterable[session_create_params.Tool] | NotGiven' = NOT_GIVEN, tracing: 'session_create_params.Tracing | NotGiven' = NOT_GIVEN, turn_detection: 'session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, voice: "Union[str, Literal['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse']] | NotGiven" = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SessionCreateResponse'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API. Can be configured with the same session parameters as the
`session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

#### Sub-resource: `transcription_sessions`

##### `create(*, client_secret: 'transcription_session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, include: 'List[str] | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'transcription_session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'transcription_session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, turn_detection: 'transcription_session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'TranscriptionSession'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API specifically for realtime transcriptions. Can be configured with
the same session parameters as the `transcription_session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

##### Sub-resource: `with_raw_response`

###### `create(*, client_secret: 'transcription_session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, include: 'List[str] | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'transcription_session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'transcription_session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, turn_detection: 'transcription_session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'TranscriptionSession'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API specifically for realtime transcriptions. Can be configured with
the same session parameters as the `transcription_session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

##### Sub-resource: `with_streaming_response`

###### `create(*, client_secret: 'transcription_session_create_params.ClientSecret | NotGiven' = NOT_GIVEN, include: 'List[str] | NotGiven' = NOT_GIVEN, input_audio_format: "Literal['pcm16', 'g711_ulaw', 'g711_alaw'] | NotGiven" = NOT_GIVEN, input_audio_noise_reduction: 'transcription_session_create_params.InputAudioNoiseReduction | NotGiven' = NOT_GIVEN, input_audio_transcription: 'transcription_session_create_params.InputAudioTranscription | NotGiven' = NOT_GIVEN, modalities: "List[Literal['text', 'audio']] | NotGiven" = NOT_GIVEN, turn_detection: 'transcription_session_create_params.TurnDetection | NotGiven' = NOT_GIVEN, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'TranscriptionSession'`

```
Create an ephemeral API token for use in client-side applications with the
Realtime API specifically for realtime transcriptions. Can be configured with
the same session parameters as the `transcription_session.update` client event.

It responds with a session object, plus a `client_secret` key which contains a
usable ephemeral API token that can be used to authenticate browser clients for
the Realtime API.

...
```

### Sub-resource: `threads`

#### `create(*, messages: 'Iterable[thread_create_params.Message] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_create_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Create a thread.

Args:
  messages: A list of [messages](https://platform.openai.com/docs/api-reference/messages) to
      start the thread with.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

#### `create_and_run(*, assistant_id: 'str', instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, thread: 'thread_create_and_run_params.Thread | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tool_resources: 'Optional[thread_create_and_run_params.ToolResources] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[thread_create_and_run_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

#### `create_and_run_poll(*, assistant_id: 'str', instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, thread: 'thread_create_and_run_params.Thread | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tool_resources: 'Optional[thread_create_and_run_params.ToolResources] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[thread_create_and_run_params.TruncationStrategy] | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
A helper to create a thread, start a run and then poll for a terminal state.
More information on Run lifecycles can be found here:
https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
```

#### `create_and_run_stream(*, assistant_id: 'str', instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, thread: 'thread_create_and_run_params.Thread | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tool_resources: 'Optional[thread_create_and_run_params.ToolResources] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[thread_create_and_run_params.TruncationStrategy] | Omit' = OMIT, event_handler: 'AssistantEventHandlerT | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantStreamManager[AssistantEventHandler] | AssistantStreamManager[AssistantEventHandlerT]'`

```
Create a thread and stream the run back
```

#### `delete(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ThreadDeleted'`

```
Delete a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Retrieves a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(thread_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_update_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Modifies a thread.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `messages`

##### `create(thread_id: 'str', *, content: 'Union[str, Iterable[MessageContentPartParam]]', role: "Literal['user', 'assistant']", attachments: 'Optional[Iterable[message_create_params.Attachment]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Create a message.

Args:
  content: The text contents of the message.

  role:
      The role of the entity that is creating the message. Allowed values include:

...
```

##### `delete(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageDeleted'`

```
Deletes a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, run_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Message]'`

```
Returns a list of messages for a given thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Retrieve a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(message_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Modifies a message.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `with_raw_response`

###### `create(thread_id: 'str', *, content: 'Union[str, Iterable[MessageContentPartParam]]', role: "Literal['user', 'assistant']", attachments: 'Optional[Iterable[message_create_params.Attachment]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Create a message.

Args:
  content: The text contents of the message.

  role:
      The role of the entity that is creating the message. Allowed values include:

...
```

###### `delete(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageDeleted'`

```
Deletes a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, run_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Message]'`

```
Returns a list of messages for a given thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Retrieve a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `update(message_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Modifies a message.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `with_streaming_response`

###### `create(thread_id: 'str', *, content: 'Union[str, Iterable[MessageContentPartParam]]', role: "Literal['user', 'assistant']", attachments: 'Optional[Iterable[message_create_params.Attachment]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Create a message.

Args:
  content: The text contents of the message.

  role:
      The role of the entity that is creating the message. Allowed values include:

...
```

###### `delete(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageDeleted'`

```
Deletes a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, run_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Message]'`

```
Returns a list of messages for a given thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Retrieve a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `update(message_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Modifies a message.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `runs`

##### `cancel(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Cancels a run that is `in_progress`.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(thread_id: 'str', *, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

##### `create_and_poll(*, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
A helper to create a run an poll for a terminal state. More information on Run
lifecycles can be found here:
https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
```

##### `create_and_stream(*, assistant_id: 'str', additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, thread_id: 'str', event_handler: 'AssistantEventHandlerT | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantStreamManager[AssistantEventHandler] | AssistantStreamManager[AssistantEventHandlerT]'`

```
Create a Run stream
```

##### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Run]'`

```
Returns a list of runs belonging to a thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `poll(run_id: 'str', thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN, poll_interval_ms: 'int | Omit' = OMIT) -> 'Run'`

```
A helper to poll a run status until it reaches a terminal state. More
information on Run lifecycles can be found here:
https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
```

##### `retrieve(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Retrieves a run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `stream(*, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, thread_id: 'str', event_handler: 'AssistantEventHandlerT | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantStreamManager[AssistantEventHandler] | AssistantStreamManager[AssistantEventHandlerT]'`

```
Create a Run stream
```

##### `submit_tool_outputs(run_id: 'str', *, thread_id: 'str', tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

##### `submit_tool_outputs_and_poll(*, tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', run_id: 'str', thread_id: 'str', poll_interval_ms: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
A helper to submit a tool output to a run and poll for a terminal run state.
More information on Run lifecycles can be found here:
https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
```

##### `submit_tool_outputs_stream(*, tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', run_id: 'str', thread_id: 'str', event_handler: 'AssistantEventHandlerT | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'AssistantStreamManager[AssistantEventHandler] | AssistantStreamManager[AssistantEventHandlerT]'`

```
Submit the tool outputs from a previous run and stream the run to a terminal
state. More information on Run lifecycles can be found here:
https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
```

##### `update(run_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Modifies a run.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `steps`

###### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

###### Sub-resource: `with_raw_response`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

###### Sub-resource: `with_streaming_response`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

##### Sub-resource: `with_raw_response`

###### `cancel(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Cancels a run that is `in_progress`.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `create(thread_id: 'str', *, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Run]'`

```
Returns a list of runs belonging to a thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Retrieves a run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `submit_tool_outputs(run_id: 'str', *, thread_id: 'str', tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `update(run_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Modifies a run.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

###### Sub-resource: `steps`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

##### Sub-resource: `with_streaming_response`

###### `cancel(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Cancels a run that is `in_progress`.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `create(thread_id: 'str', *, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Run]'`

```
Returns a list of runs belonging to a thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Retrieves a run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `submit_tool_outputs(run_id: 'str', *, thread_id: 'str', tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `update(run_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Modifies a run.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

###### Sub-resource: `steps`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, messages: 'Iterable[thread_create_params.Message] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_create_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Create a thread.

Args:
  messages: A list of [messages](https://platform.openai.com/docs/api-reference/messages) to
      start the thread with.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

##### `create_and_run(*, assistant_id: 'str', instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, thread: 'thread_create_and_run_params.Thread | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tool_resources: 'Optional[thread_create_and_run_params.ToolResources] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[thread_create_and_run_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

##### `delete(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ThreadDeleted'`

```
Delete a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `retrieve(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Retrieves a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(thread_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_update_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Modifies a thread.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `messages`

###### `create(thread_id: 'str', *, content: 'Union[str, Iterable[MessageContentPartParam]]', role: "Literal['user', 'assistant']", attachments: 'Optional[Iterable[message_create_params.Attachment]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Create a message.

Args:
  content: The text contents of the message.

  role:
      The role of the entity that is creating the message. Allowed values include:

...
```

###### `delete(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageDeleted'`

```
Deletes a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, run_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Message]'`

```
Returns a list of messages for a given thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Retrieve a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `update(message_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Modifies a message.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `runs`

###### `cancel(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Cancels a run that is `in_progress`.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `create(thread_id: 'str', *, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Run]'`

```
Returns a list of runs belonging to a thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Retrieves a run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `submit_tool_outputs(run_id: 'str', *, thread_id: 'str', tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `update(run_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Modifies a run.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

###### Sub-resource: `steps`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, messages: 'Iterable[thread_create_params.Message] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_create_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Create a thread.

Args:
  messages: A list of [messages](https://platform.openai.com/docs/api-reference/messages) to
      start the thread with.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

##### `create_and_run(*, assistant_id: 'str', instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, thread: 'thread_create_and_run_params.Thread | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tool_resources: 'Optional[thread_create_and_run_params.ToolResources] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[thread_create_and_run_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

##### `delete(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ThreadDeleted'`

```
Delete a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `retrieve(thread_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Retrieves a thread.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(thread_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, tool_resources: 'Optional[thread_update_params.ToolResources] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Thread'`

```
Modifies a thread.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `messages`

###### `create(thread_id: 'str', *, content: 'Union[str, Iterable[MessageContentPartParam]]', role: "Literal['user', 'assistant']", attachments: 'Optional[Iterable[message_create_params.Attachment]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Create a message.

Args:
  content: The text contents of the message.

  role:
      The role of the entity that is creating the message. Allowed values include:

...
```

###### `delete(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageDeleted'`

```
Deletes a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, run_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Message]'`

```
Returns a list of messages for a given thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(message_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Retrieve a message.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `update(message_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message'`

```
Modifies a message.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

##### Sub-resource: `runs`

###### `cancel(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Cancels a run that is `in_progress`.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `create(thread_id: 'str', *, assistant_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, additional_instructions: 'Optional[str] | Omit' = OMIT, additional_messages: 'Optional[Iterable[run_create_params.AdditionalMessage]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_prompt_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'Union[str, ChatModel, None] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'Optional[AssistantResponseFormatOptionParam] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'Optional[AssistantToolChoiceOptionParam] | Omit' = OMIT, tools: 'Optional[Iterable[AssistantToolParam]] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation_strategy: 'Optional[run_create_params.TruncationStrategy] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `list(thread_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Run]'`

```
Returns a list of runs belonging to a thread.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

###### `retrieve(run_id: 'str', *, thread_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Retrieves a run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

###### `submit_tool_outputs(run_id: 'str', *, thread_id: 'str', tool_outputs: 'Iterable[run_submit_tool_outputs_params.ToolOutput]', stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run | Stream[AssistantStreamEvent]'`

###### `update(run_id: 'str', *, thread_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Run'`

```
Modifies a run.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

###### Sub-resource: `steps`

####### `list(run_id: 'str', *, thread_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, include: 'List[RunStepInclude] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunStep]'`

```
Returns a list of run steps belonging to a run.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

####### `retrieve(step_id: 'str', *, thread_id: 'str', run_id: 'str', include: 'List[RunStepInclude] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunStep'`

```
Retrieves a run step.

Args:
  include: A list of additional fields to include in the response. Currently the only
      supported value is `step_details.tool_calls[*].file_search.results[*].content`
      to fetch the file search result content.

      See the
...
```

---

## `client.chat`

### Sub-resource: `completions`

#### `create(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'completion_create_params.ResponseFormat | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion | Stream[ChatCompletionChunk]'`

#### `delete(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletionDeleted'`

```
Delete a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be deleted.

Args:
  extra_headers: Send extra headers

...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletion]'`

```
List stored Chat Completions.

Only Chat Completions that have been stored with
the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last chat completion from the previous pagination request.

...
```

#### `parse(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, response_format: 'type[ResponseFormatT] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedChatCompletion[ResponseFormatT]'`

```
Wrapper over the `client.chat.completions.create()` method that provides richer integrations with Python specific types
& returns a `ParsedChatCompletion` object, which is a subclass of the standard `ChatCompletion` class.

You can pass a pydantic model to this method and it will automatically convert the model
into a JSON schema, send it to the API and parse the response content back into the given model.

This method will also automatically parse `function` tool calls if:
- You use the `openai.pydantic_function_tool()` helper method
...
```

#### `retrieve(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Get a stored chat completion.

Only Chat Completions that have been created with
the `store` parameter set to `true` will be returned.

Args:
  extra_headers: Send extra headers

...
```

#### `stream(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, response_format: 'completion_create_params.ResponseFormat | type[ResponseFormatT] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletionStreamManager[ResponseFormatT]'`

```
Wrapper over the `client.chat.completions.create(stream=True)` method that provides a more granular event API
and automatic accumulation of each delta.

This also supports all of the parsing utilities that `.parse()` does.

Unlike `.create(stream=True)`, the `.stream()` method requires usage within a context manager to prevent accidental leakage of the response:

```py
...
```

#### `update(completion_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Modify a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be modified. Currently, the only
supported modification is to update the `metadata` field.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

#### Sub-resource: `messages`

##### `list(completion_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletionStoreMessage]'`

```
Get the messages in a stored chat completion.

Only Chat Completions that have
been created with the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last message from the previous pagination request.

...
```

##### Sub-resource: `with_raw_response`

###### `list(completion_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletionStoreMessage]'`

```
Get the messages in a stored chat completion.

Only Chat Completions that have
been created with the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last message from the previous pagination request.

...
```

##### Sub-resource: `with_streaming_response`

###### `list(completion_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletionStoreMessage]'`

```
Get the messages in a stored chat completion.

Only Chat Completions that have
been created with the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last message from the previous pagination request.

...
```

#### Sub-resource: `with_raw_response`

##### `create(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'completion_create_params.ResponseFormat | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion | Stream[ChatCompletionChunk]'`

##### `delete(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletionDeleted'`

```
Delete a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be deleted.

Args:
  extra_headers: Send extra headers

...
```

##### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletion]'`

```
List stored Chat Completions.

Only Chat Completions that have been stored with
the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last chat completion from the previous pagination request.

...
```

##### `parse(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, response_format: 'type[ResponseFormatT] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedChatCompletion[ResponseFormatT]'`

```
Wrapper over the `client.chat.completions.create()` method that provides richer integrations with Python specific types
& returns a `ParsedChatCompletion` object, which is a subclass of the standard `ChatCompletion` class.

You can pass a pydantic model to this method and it will automatically convert the model
into a JSON schema, send it to the API and parse the response content back into the given model.

This method will also automatically parse `function` tool calls if:
- You use the `openai.pydantic_function_tool()` helper method
...
```

##### `retrieve(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Get a stored chat completion.

Only Chat Completions that have been created with
the `store` parameter set to `true` will be returned.

Args:
  extra_headers: Send extra headers

...
```

##### `update(completion_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Modify a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be modified. Currently, the only
supported modification is to update the `metadata` field.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### Sub-resource: `messages`

###### `list(completion_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletionStoreMessage]'`

```
Get the messages in a stored chat completion.

Only Chat Completions that have
been created with the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last message from the previous pagination request.

...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, response_format: 'completion_create_params.ResponseFormat | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion | Stream[ChatCompletionChunk]'`

##### `delete(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletionDeleted'`

```
Delete a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be deleted.

Args:
  extra_headers: Send extra headers

...
```

##### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletion]'`

```
List stored Chat Completions.

Only Chat Completions that have been stored with
the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last chat completion from the previous pagination request.

...
```

##### `parse(*, messages: 'Iterable[ChatCompletionMessageParam]', model: 'Union[str, ChatModel]', audio: 'Optional[ChatCompletionAudioParam] | Omit' = OMIT, response_format: 'type[ResponseFormatT] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, function_call: 'completion_create_params.FunctionCall | Omit' = OMIT, functions: 'Iterable[completion_create_params.Function] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[bool] | Omit' = OMIT, max_completion_tokens: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, modalities: "Optional[List[Literal['text', 'audio']]] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, parallel_tool_calls: 'bool | Omit' = OMIT, prediction: 'Optional[ChatCompletionPredictionContentParam] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning_effort: 'Optional[ReasoningEffort] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, tool_choice: 'ChatCompletionToolChoiceOptionParam | Omit' = OMIT, tools: 'Iterable[ChatCompletionToolUnionParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, web_search_options: 'completion_create_params.WebSearchOptions | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedChatCompletion[ResponseFormatT]'`

```
Wrapper over the `client.chat.completions.create()` method that provides richer integrations with Python specific types
& returns a `ParsedChatCompletion` object, which is a subclass of the standard `ChatCompletion` class.

You can pass a pydantic model to this method and it will automatically convert the model
into a JSON schema, send it to the API and parse the response content back into the given model.

This method will also automatically parse `function` tool calls if:
- You use the `openai.pydantic_function_tool()` helper method
...
```

##### `retrieve(completion_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Get a stored chat completion.

Only Chat Completions that have been created with
the `store` parameter set to `true` will be returned.

Args:
  extra_headers: Send extra headers

...
```

##### `update(completion_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ChatCompletion'`

```
Modify a stored chat completion.

Only Chat Completions that have been created
with the `store` parameter set to `true` can be modified. Currently, the only
supported modification is to update the `metadata` field.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### Sub-resource: `messages`

###### `list(completion_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ChatCompletionStoreMessage]'`

```
Get the messages in a stored chat completion.

Only Chat Completions that have
been created with the `store` parameter set to `true` will be returned.

Args:
  after: Identifier for the last message from the previous pagination request.

...
```

---

## `client.completions`

Given a prompt, the model will return one or more predicted completions, and can also return the probabilities of alternative tokens at each position.

### `create(*, model: "Union[str, Literal['gpt-3.5-turbo-instruct', 'davinci-002', 'babbage-002']]", prompt: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]], None]', best_of: 'Optional[int] | Omit' = OMIT, echo: 'Optional[bool] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `with_raw_response`

#### `create(*, model: "Union[str, Literal['gpt-3.5-turbo-instruct', 'davinci-002', 'babbage-002']]", prompt: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]], None]', best_of: 'Optional[int] | Omit' = OMIT, echo: 'Optional[bool] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `with_streaming_response`

#### `create(*, model: "Union[str, Literal['gpt-3.5-turbo-instruct', 'davinci-002', 'babbage-002']]", prompt: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]], None]', best_of: 'Optional[int] | Omit' = OMIT, echo: 'Optional[bool] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

---

## `client.containers`

### `create(*, name: 'str', expires_after: 'container_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, memory_limit: "Literal['1g', '4g', '16g', '64g'] | Omit" = OMIT, network_policy: 'container_create_params.NetworkPolicy | Omit' = OMIT, skills: 'Iterable[container_create_params.Skill] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerCreateResponse'`

```
Create Container

Args:
  name: Name of the container to create.

  expires_after: Container expiration time in seconds relative to the 'anchor' time.

  file_ids: IDs of files to copy to the container.
...
```

### `delete(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, name: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ContainerListResponse]'`

```
List Containers

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

### `retrieve(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerRetrieveResponse'`

```
Retrieve Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `files`

#### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

#### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `content`

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `with_raw_response`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `with_streaming_response`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_raw_response`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_streaming_response`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_raw_response`

#### `create(*, name: 'str', expires_after: 'container_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, memory_limit: "Literal['1g', '4g', '16g', '64g'] | Omit" = OMIT, network_policy: 'container_create_params.NetworkPolicy | Omit' = OMIT, skills: 'Iterable[container_create_params.Skill] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerCreateResponse'`

```
Create Container

Args:
  name: Name of the container to create.

  expires_after: Container expiration time in seconds relative to the 'anchor' time.

  file_ids: IDs of files to copy to the container.
...
```

#### `delete(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, name: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ContainerListResponse]'`

```
List Containers

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerRetrieveResponse'`

```
Retrieve Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, name: 'str', expires_after: 'container_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, memory_limit: "Literal['1g', '4g', '16g', '64g'] | Omit" = OMIT, network_policy: 'container_create_params.NetworkPolicy | Omit' = OMIT, skills: 'Iterable[container_create_params.Skill] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerCreateResponse'`

```
Create Container

Args:
  name: Name of the container to create.

  expires_after: Container expiration time in seconds relative to the 'anchor' time.

  file_ids: IDs of files to copy to the container.
...
```

#### `delete(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, name: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ContainerListResponse]'`

```
List Containers

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerRetrieveResponse'`

```
Retrieve Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.conversations`

Manage conversations and conversation items.

### `create(*, items: 'Optional[Iterable[ResponseInputItemParam]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Create a conversation.

Args:
  items: Initial items to include in the conversation context. You may add up to 20 items
      at a time.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

### `delete(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationDeletedResource'`

```
Delete a conversation.

Items in the conversation will not be deleted.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### `retrieve(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Get a conversation

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `update(conversation_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Update a conversation

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

### Sub-resource: `items`

#### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

#### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

#### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_raw_response`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_streaming_response`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

### Sub-resource: `with_raw_response`

#### `create(*, items: 'Optional[Iterable[ResponseInputItemParam]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Create a conversation.

Args:
  items: Initial items to include in the conversation context. You may add up to 20 items
      at a time.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

#### `delete(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationDeletedResource'`

```
Delete a conversation.

Items in the conversation will not be deleted.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Get a conversation

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(conversation_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Update a conversation

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `items`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, items: 'Optional[Iterable[ResponseInputItemParam]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Create a conversation.

Args:
  items: Initial items to include in the conversation context. You may add up to 20 items
      at a time.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

#### `delete(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationDeletedResource'`

```
Delete a conversation.

Items in the conversation will not be deleted.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Get a conversation

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(conversation_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Update a conversation

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `items`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

---

## `client.embeddings`

Get a vector representation of a given input that can be easily consumed by machine learning models and algorithms.

### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]]]', model: 'Union[str, EmbeddingModel]', dimensions: 'int | Omit' = OMIT, encoding_format: "Literal['float', 'base64'] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CreateEmbeddingResponse'`

```
Creates an embedding vector representing the input text.

Args:
  input: Input text to embed, encoded as a string or array of tokens. To embed multiple
      inputs in a single request, pass an array of strings or array of token arrays.
      The input must not exceed the max input tokens for the model (8192 tokens for
      all embedding models), cannot be an empty string, and any array must be 2048
      dimensions or less.
...
```

### Sub-resource: `with_raw_response`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]]]', model: 'Union[str, EmbeddingModel]', dimensions: 'int | Omit' = OMIT, encoding_format: "Literal['float', 'base64'] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CreateEmbeddingResponse'`

```
Creates an embedding vector representing the input text.

Args:
  input: Input text to embed, encoded as a string or array of tokens. To embed multiple
      inputs in a single request, pass an array of strings or array of token arrays.
      The input must not exceed the max input tokens for the model (8192 tokens for
      all embedding models), cannot be an empty string, and any array must be 2048
      dimensions or less.
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]]]', model: 'Union[str, EmbeddingModel]', dimensions: 'int | Omit' = OMIT, encoding_format: "Literal['float', 'base64'] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CreateEmbeddingResponse'`

```
Creates an embedding vector representing the input text.

Args:
  input: Input text to embed, encoded as a string or array of tokens. To embed multiple
      inputs in a single request, pass an array of strings or array of token arrays.
      The input must not exceed the max input tokens for the model (8192 tokens for
      all embedding models), cannot be an empty string, and any array must be 2048
      dimensions or less.
...
```

---

## `client.evals`

Manage and run evals in the OpenAI platform.

### `create(*, data_source_config: 'eval_create_params.DataSourceConfig', testing_criteria: 'Iterable[eval_create_params.TestingCriterion]', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalCreateResponse'`

```
Create the structure of an evaluation that can be used to test a model's
performance. An evaluation is a set of testing criteria and the config for a
data source, which dictates the schema of the data used in the evaluation. After
creating an evaluation, you can run it on different models and model parameters.
We support several types of graders and datasources. For more information, see
the [Evals guide](https://platform.openai.com/docs/guides/evals).

Args:
...
```

### `delete(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalDeleteResponse'`

```
Delete an evaluation.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: "Literal['created_at', 'updated_at'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[EvalListResponse]'`

```
List evaluations for a project.

Args:
  after: Identifier for the last eval from the previous pagination request.

  limit: Number of evals to retrieve.

  order: Sort order for evals by timestamp. Use `asc` for ascending order or `desc` for
...
```

### `retrieve(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalRetrieveResponse'`

```
Get an evaluation by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `update(eval_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalUpdateResponse'`

```
Update certain properties of an evaluation.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

### Sub-resource: `runs`

#### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

#### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `output_items`

##### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

##### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `with_raw_response`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `with_streaming_response`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_raw_response`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_streaming_response`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_raw_response`

#### `create(*, data_source_config: 'eval_create_params.DataSourceConfig', testing_criteria: 'Iterable[eval_create_params.TestingCriterion]', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalCreateResponse'`

```
Create the structure of an evaluation that can be used to test a model's
performance. An evaluation is a set of testing criteria and the config for a
data source, which dictates the schema of the data used in the evaluation. After
creating an evaluation, you can run it on different models and model parameters.
We support several types of graders and datasources. For more information, see
the [Evals guide](https://platform.openai.com/docs/guides/evals).

Args:
...
```

#### `delete(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalDeleteResponse'`

```
Delete an evaluation.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: "Literal['created_at', 'updated_at'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[EvalListResponse]'`

```
List evaluations for a project.

Args:
  after: Identifier for the last eval from the previous pagination request.

  limit: Number of evals to retrieve.

  order: Sort order for evals by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalRetrieveResponse'`

```
Get an evaluation by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(eval_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalUpdateResponse'`

```
Update certain properties of an evaluation.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `runs`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, data_source_config: 'eval_create_params.DataSourceConfig', testing_criteria: 'Iterable[eval_create_params.TestingCriterion]', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalCreateResponse'`

```
Create the structure of an evaluation that can be used to test a model's
performance. An evaluation is a set of testing criteria and the config for a
data source, which dictates the schema of the data used in the evaluation. After
creating an evaluation, you can run it on different models and model parameters.
We support several types of graders and datasources. For more information, see
the [Evals guide](https://platform.openai.com/docs/guides/evals).

Args:
...
```

#### `delete(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalDeleteResponse'`

```
Delete an evaluation.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: "Literal['created_at', 'updated_at'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[EvalListResponse]'`

```
List evaluations for a project.

Args:
  after: Identifier for the last eval from the previous pagination request.

  limit: Number of evals to retrieve.

  order: Sort order for evals by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalRetrieveResponse'`

```
Get an evaluation by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(eval_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalUpdateResponse'`

```
Update certain properties of an evaluation.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `runs`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.files`

Files are used to upload documents that can be used with features like Assistants and Fine-tuning.

### `content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `create(*, file: 'FileTypes', purpose: 'FilePurpose', expires_after: 'file_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Upload a file that can be used across various endpoints.

Individual files can be
up to 512 MB, and each project can store up to 2.5 TB of files in total. There
is no organization-wide storage limit.

- The Assistants API supports files up to 2 million tokens and of specific file
  types. See the
...
```

### `delete(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileDeleted'`

```
Delete a file and remove it from all vector stores.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, purpose: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileObject]'`

```
Returns a list of files.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

### `retrieve(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Returns information about a specific file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `retrieve_content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `wait_for_processing(id: 'str', *, poll_interval: 'float' = 5.0, max_wait_seconds: 'float' = 1800) -> 'FileObject'`

```
Waits for the given file to be processed, default timeout is 30 mins.
```

### Sub-resource: `with_raw_response`

#### `content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(*, file: 'FileTypes', purpose: 'FilePurpose', expires_after: 'file_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Upload a file that can be used across various endpoints.

Individual files can be
up to 512 MB, and each project can store up to 2.5 TB of files in total. There
is no organization-wide storage limit.

- The Assistants API supports files up to 2 million tokens and of specific file
  types. See the
...
```

#### `delete(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileDeleted'`

```
Delete a file and remove it from all vector stores.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, purpose: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileObject]'`

```
Returns a list of files.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Returns information about a specific file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve_content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_streaming_response`

#### `content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(*, file: 'FileTypes', purpose: 'FilePurpose', expires_after: 'file_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Upload a file that can be used across various endpoints.

Individual files can be
up to 512 MB, and each project can store up to 2.5 TB of files in total. There
is no organization-wide storage limit.

- The Assistants API supports files up to 2 million tokens and of specific file
  types. See the
...
```

#### `delete(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileDeleted'`

```
Delete a file and remove it from all vector stores.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, purpose: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileObject]'`

```
Returns a list of files.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Returns information about a specific file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve_content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.fine_tuning`

### Sub-resource: `jobs`

#### `cancel(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Immediately cancel a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(*, model: "Union[str, Literal['babbage-002', 'davinci-002', 'gpt-3.5-turbo', 'gpt-4o-mini']]", training_file: 'str', hyperparameters: 'job_create_params.Hyperparameters | Omit' = OMIT, integrations: 'Optional[Iterable[job_create_params.Integration]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, method: 'job_create_params.Method | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, validation_file: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Creates a fine-tuning job which begins the process of creating a new model from
a given dataset.

Response includes details of the enqueued job including job status and the name
of the fine-tuned models once complete.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Dict[str, str]] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJob]'`

```
List your organization's fine-tuning jobs

Args:
  after: Identifier for the last job from the previous pagination request.

  limit: Number of fine-tuning jobs to retrieve.

  metadata: Optional metadata filter. To filter, use the syntax `metadata[k]=v`.
...
```

#### `list_events(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobEvent]'`

```
Get status updates for a fine-tuning job.

Args:
  after: Identifier for the last event from the previous pagination request.

  limit: Number of events to retrieve.

  extra_headers: Send extra headers
...
```

#### `pause(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Pause a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `resume(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Resume a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Get info about a fine-tuning job.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `checkpoints`

##### `list(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobCheckpoint]'`

```
List checkpoints for a fine-tuning job.

Args:
  after: Identifier for the last checkpoint ID from the previous pagination request.

  limit: Number of checkpoints to retrieve.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_raw_response`

###### `list(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobCheckpoint]'`

```
List checkpoints for a fine-tuning job.

Args:
  after: Identifier for the last checkpoint ID from the previous pagination request.

  limit: Number of checkpoints to retrieve.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_streaming_response`

###### `list(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobCheckpoint]'`

```
List checkpoints for a fine-tuning job.

Args:
  after: Identifier for the last checkpoint ID from the previous pagination request.

  limit: Number of checkpoints to retrieve.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_raw_response`

##### `cancel(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Immediately cancel a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(*, model: "Union[str, Literal['babbage-002', 'davinci-002', 'gpt-3.5-turbo', 'gpt-4o-mini']]", training_file: 'str', hyperparameters: 'job_create_params.Hyperparameters | Omit' = OMIT, integrations: 'Optional[Iterable[job_create_params.Integration]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, method: 'job_create_params.Method | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, validation_file: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Creates a fine-tuning job which begins the process of creating a new model from
a given dataset.

Response includes details of the enqueued job including job status and the name
of the fine-tuned models once complete.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

...
```

##### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Dict[str, str]] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJob]'`

```
List your organization's fine-tuning jobs

Args:
  after: Identifier for the last job from the previous pagination request.

  limit: Number of fine-tuning jobs to retrieve.

  metadata: Optional metadata filter. To filter, use the syntax `metadata[k]=v`.
...
```

##### `list_events(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobEvent]'`

```
Get status updates for a fine-tuning job.

Args:
  after: Identifier for the last event from the previous pagination request.

  limit: Number of events to retrieve.

  extra_headers: Send extra headers
...
```

##### `pause(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Pause a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `resume(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Resume a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `retrieve(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Get info about a fine-tuning job.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `checkpoints`

###### `list(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobCheckpoint]'`

```
List checkpoints for a fine-tuning job.

Args:
  after: Identifier for the last checkpoint ID from the previous pagination request.

  limit: Number of checkpoints to retrieve.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_streaming_response`

##### `cancel(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Immediately cancel a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(*, model: "Union[str, Literal['babbage-002', 'davinci-002', 'gpt-3.5-turbo', 'gpt-4o-mini']]", training_file: 'str', hyperparameters: 'job_create_params.Hyperparameters | Omit' = OMIT, integrations: 'Optional[Iterable[job_create_params.Integration]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, method: 'job_create_params.Method | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, validation_file: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Creates a fine-tuning job which begins the process of creating a new model from
a given dataset.

Response includes details of the enqueued job including job status and the name
of the fine-tuned models once complete.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

...
```

##### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, metadata: 'Optional[Dict[str, str]] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJob]'`

```
List your organization's fine-tuning jobs

Args:
  after: Identifier for the last job from the previous pagination request.

  limit: Number of fine-tuning jobs to retrieve.

  metadata: Optional metadata filter. To filter, use the syntax `metadata[k]=v`.
...
```

##### `list_events(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobEvent]'`

```
Get status updates for a fine-tuning job.

Args:
  after: Identifier for the last event from the previous pagination request.

  limit: Number of events to retrieve.

  extra_headers: Send extra headers
...
```

##### `pause(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Pause a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `resume(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Resume a fine-tune job.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `retrieve(fine_tuning_job_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FineTuningJob'`

```
Get info about a fine-tuning job.

[Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `checkpoints`

###### `list(fine_tuning_job_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FineTuningJobCheckpoint]'`

```
List checkpoints for a fine-tuning job.

Args:
  after: Identifier for the last checkpoint ID from the previous pagination request.

  limit: Number of checkpoints to retrieve.

  extra_headers: Send extra headers
...
```

---

## `client.images`

Given a prompt and/or an input image, the model will generate a new image.

### `create_variation(*, image: 'FileTypes', model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse'`

```
Creates a variation of a given image.

This endpoint only supports `dall-e-2`.

Args:
  image: The image to use as the basis for the variation(s). Must be a valid PNG file,
      less than 4MB, and square.

...
```

### `edit(*, image: 'Union[FileTypes, SequenceNotStr[FileTypes]]', prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, input_fidelity: "Optional[Literal['high', 'low']] | Omit" = OMIT, mask: 'FileTypes | Omit' = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024', '1536x1024', '1024x1536', 'auto']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageEditStreamEvent]'`

### `generate(*, prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, moderation: "Optional[Literal['low', 'auto']] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'hd', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['auto', '1024x1024', '1536x1024', '1024x1536', '256x256', '512x512', '1792x1024', '1024x1792']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, style: "Optional[Literal['vivid', 'natural']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageGenStreamEvent]'`

### Sub-resource: `with_raw_response`

#### `create_variation(*, image: 'FileTypes', model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse'`

```
Creates a variation of a given image.

This endpoint only supports `dall-e-2`.

Args:
  image: The image to use as the basis for the variation(s). Must be a valid PNG file,
      less than 4MB, and square.

...
```

#### `edit(*, image: 'Union[FileTypes, SequenceNotStr[FileTypes]]', prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, input_fidelity: "Optional[Literal['high', 'low']] | Omit" = OMIT, mask: 'FileTypes | Omit' = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024', '1536x1024', '1024x1536', 'auto']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageEditStreamEvent]'`

#### `generate(*, prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, moderation: "Optional[Literal['low', 'auto']] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'hd', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['auto', '1024x1024', '1536x1024', '1024x1536', '256x256', '512x512', '1792x1024', '1024x1792']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, style: "Optional[Literal['vivid', 'natural']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageGenStreamEvent]'`

### Sub-resource: `with_streaming_response`

#### `create_variation(*, image: 'FileTypes', model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse'`

```
Creates a variation of a given image.

This endpoint only supports `dall-e-2`.

Args:
  image: The image to use as the basis for the variation(s). Must be a valid PNG file,
      less than 4MB, and square.

...
```

#### `edit(*, image: 'Union[FileTypes, SequenceNotStr[FileTypes]]', prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, input_fidelity: "Optional[Literal['high', 'low']] | Omit" = OMIT, mask: 'FileTypes | Omit' = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024', '1536x1024', '1024x1536', 'auto']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageEditStreamEvent]'`

#### `generate(*, prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, moderation: "Optional[Literal['low', 'auto']] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'hd', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['auto', '1024x1024', '1536x1024', '1024x1536', '256x256', '512x512', '1792x1024', '1024x1792']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, style: "Optional[Literal['vivid', 'natural']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageGenStreamEvent]'`

---

## `client.models`

List and describe the various models available in the API.

### `delete(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelDeleted'`

```
Delete a fine-tuned model.

You must have the Owner role in your organization to
delete a model.

Args:
  extra_headers: Send extra headers

...
```

### `list(*, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[Model]'`

```
Lists the currently available models, and provides basic information about each
one such as the owner and availability.
```

### `retrieve(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Model'`

```
Retrieves a model instance, providing basic information about the model such as
the owner and permissioning.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

...
```

### Sub-resource: `with_raw_response`

#### `delete(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelDeleted'`

```
Delete a fine-tuned model.

You must have the Owner role in your organization to
delete a model.

Args:
  extra_headers: Send extra headers

...
```

#### `list(*, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[Model]'`

```
Lists the currently available models, and provides basic information about each
one such as the owner and availability.
```

#### `retrieve(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Model'`

```
Retrieves a model instance, providing basic information about the model such as
the owner and permissioning.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

...
```

### Sub-resource: `with_streaming_response`

#### `delete(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelDeleted'`

```
Delete a fine-tuned model.

You must have the Owner role in your organization to
delete a model.

Args:
  extra_headers: Send extra headers

...
```

#### `list(*, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[Model]'`

```
Lists the currently available models, and provides basic information about each
one such as the owner and availability.
```

#### `retrieve(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Model'`

```
Retrieves a model instance, providing basic information about the model such as
the owner and permissioning.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

...
```

---

## `client.moderations`

Given text and/or image inputs, classifies if those inputs are potentially harmful.

### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[ModerationMultiModalInputParam]]', model: 'Union[str, ModerationModel] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModerationCreateResponse'`

```
Classifies if text and/or image inputs are potentially harmful.

Learn more in
the [moderation guide](https://platform.openai.com/docs/guides/moderation).

Args:
  input: Input (or inputs) to classify. Can be a single string, an array of strings, or
      an array of multi-modal input objects similar to other models.
...
```

### Sub-resource: `with_raw_response`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[ModerationMultiModalInputParam]]', model: 'Union[str, ModerationModel] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModerationCreateResponse'`

```
Classifies if text and/or image inputs are potentially harmful.

Learn more in
the [moderation guide](https://platform.openai.com/docs/guides/moderation).

Args:
  input: Input (or inputs) to classify. Can be a single string, an array of strings, or
      an array of multi-modal input objects similar to other models.
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[ModerationMultiModalInputParam]]', model: 'Union[str, ModerationModel] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModerationCreateResponse'`

```
Classifies if text and/or image inputs are potentially harmful.

Learn more in
the [moderation guide](https://platform.openai.com/docs/guides/moderation).

Args:
  input: Input (or inputs) to classify. Can be a single string, an array of strings, or
      an array of multi-modal input objects similar to other models.
...
```

---

## `client.qs`

### `parse(query: 'str') -> 'Mapping[str, object]'`

### `stringify(params: 'Params', *, array_format: 'ArrayFormat | NotGiven' = NOT_GIVEN, nested_format: 'NestedFormat | NotGiven' = NOT_GIVEN) -> 'str'`

### `stringify_items(params: 'Params', *, array_format: 'ArrayFormat | NotGiven' = NOT_GIVEN, nested_format: 'NestedFormat | NotGiven' = NOT_GIVEN) -> 'list[tuple[str, str]]'`

---

## `client.realtime`

### `connect(*, call_id: 'str | Omit' = OMIT, model: 'str | Omit' = OMIT, extra_query: 'Query' = {}, extra_headers: 'Headers' = {}, websocket_connection_options: 'WebSocketConnectionOptions' = {}, on_reconnecting: 'Callable[[ReconnectingEvent], ReconnectingOverrides | None] | None' = None, max_retries: 'int' = 5, initial_delay: 'float' = 0.5, max_delay: 'float' = 8.0, max_queue_size: 'int' = 1048576) -> 'RealtimeConnectionManager'`

```
The Realtime API enables you to build low-latency, multi-modal conversational experiences. It currently supports text and audio as both input and output, as well as function calling.

Some notable benefits of the API include:

- Native speech-to-speech: Skipping an intermediate text format means low latency and nuanced output.
- Natural, steerable voices: The models have natural inflection and can laugh, whisper, and adhere to tone direction.
- Simultaneous multimodal output: Text is useful for moderation; faster-than-realtime audio ensures stable playback.

...
```

### Sub-resource: `calls`

#### `accept(call_id: 'str', *, type: "Literal['realtime']", audio: 'RealtimeAudioConfigParam | Omit' = OMIT, include: "List[Literal['item.input_audio_transcription.logprobs']] | Omit" = OMIT, instructions: 'str | Omit' = OMIT, max_output_tokens: "Union[int, Literal['inf']] | Omit" = OMIT, model: "Union[str, Literal['gpt-realtime', 'gpt-realtime-1.5', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17', 'gpt-realtime-mini', 'gpt-realtime-mini-2025-10-06', 'gpt-realtime-mini-2025-12-15', 'gpt-audio-1.5', 'gpt-audio-mini', 'gpt-audio-mini-2025-10-06', 'gpt-audio-mini-2025-12-15']] | Omit" = OMIT, output_modalities: "List[Literal['text', 'audio']] | Omit" = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, tool_choice: 'RealtimeToolChoiceConfigParam | Omit' = OMIT, tools: 'RealtimeToolsConfigParam | Omit' = OMIT, tracing: 'Optional[RealtimeTracingConfigParam] | Omit' = OMIT, truncation: 'RealtimeTruncationParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Accept an incoming SIP call and configure the realtime session that will handle
it.

Args:
  type: The type of session to create. Always `realtime` for the Realtime API.

  audio: Configuration for input and output audio.

...
```

#### `create(*, sdp: 'str', session: 'RealtimeSessionCreateRequestParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Create a new Realtime API call over WebRTC and receive the SDP answer needed to
complete the peer connection.

Args:
  sdp: WebRTC Session Description Protocol (SDP) offer generated by the caller.

  session: Realtime session object configuration.

...
```

#### `hangup(call_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
End an active Realtime API call, whether it was initiated over SIP or WebRTC.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `refer(call_id: 'str', *, target_uri: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Transfer an active SIP call to a new destination using the SIP REFER verb.

Args:
  target_uri: URI that should appear in the SIP Refer-To header. Supports values like
      `tel:+14155550123` or `sip:agent@example.com`.

  extra_headers: Send extra headers

...
```

#### `reject(call_id: 'str', *, status_code: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Decline an incoming SIP call by returning a SIP status code to the caller.

Args:
  status_code: SIP response code to send back to the caller. Defaults to `603` (Decline) when
      omitted.

  extra_headers: Send extra headers

...
```

#### Sub-resource: `with_raw_response`

##### `accept(call_id: 'str', *, type: "Literal['realtime']", audio: 'RealtimeAudioConfigParam | Omit' = OMIT, include: "List[Literal['item.input_audio_transcription.logprobs']] | Omit" = OMIT, instructions: 'str | Omit' = OMIT, max_output_tokens: "Union[int, Literal['inf']] | Omit" = OMIT, model: "Union[str, Literal['gpt-realtime', 'gpt-realtime-1.5', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17', 'gpt-realtime-mini', 'gpt-realtime-mini-2025-10-06', 'gpt-realtime-mini-2025-12-15', 'gpt-audio-1.5', 'gpt-audio-mini', 'gpt-audio-mini-2025-10-06', 'gpt-audio-mini-2025-12-15']] | Omit" = OMIT, output_modalities: "List[Literal['text', 'audio']] | Omit" = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, tool_choice: 'RealtimeToolChoiceConfigParam | Omit' = OMIT, tools: 'RealtimeToolsConfigParam | Omit' = OMIT, tracing: 'Optional[RealtimeTracingConfigParam] | Omit' = OMIT, truncation: 'RealtimeTruncationParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Accept an incoming SIP call and configure the realtime session that will handle
it.

Args:
  type: The type of session to create. Always `realtime` for the Realtime API.

  audio: Configuration for input and output audio.

...
```

##### `create(*, sdp: 'str', session: 'RealtimeSessionCreateRequestParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

##### `hangup(call_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
End an active Realtime API call, whether it was initiated over SIP or WebRTC.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `refer(call_id: 'str', *, target_uri: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Transfer an active SIP call to a new destination using the SIP REFER verb.

Args:
  target_uri: URI that should appear in the SIP Refer-To header. Supports values like
      `tel:+14155550123` or `sip:agent@example.com`.

  extra_headers: Send extra headers

...
```

##### `reject(call_id: 'str', *, status_code: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Decline an incoming SIP call by returning a SIP status code to the caller.

Args:
  status_code: SIP response code to send back to the caller. Defaults to `603` (Decline) when
      omitted.

  extra_headers: Send extra headers

...
```

#### Sub-resource: `with_streaming_response`

##### `accept(call_id: 'str', *, type: "Literal['realtime']", audio: 'RealtimeAudioConfigParam | Omit' = OMIT, include: "List[Literal['item.input_audio_transcription.logprobs']] | Omit" = OMIT, instructions: 'str | Omit' = OMIT, max_output_tokens: "Union[int, Literal['inf']] | Omit" = OMIT, model: "Union[str, Literal['gpt-realtime', 'gpt-realtime-1.5', 'gpt-realtime-2025-08-28', 'gpt-4o-realtime-preview', 'gpt-4o-realtime-preview-2024-10-01', 'gpt-4o-realtime-preview-2024-12-17', 'gpt-4o-realtime-preview-2025-06-03', 'gpt-4o-mini-realtime-preview', 'gpt-4o-mini-realtime-preview-2024-12-17', 'gpt-realtime-mini', 'gpt-realtime-mini-2025-10-06', 'gpt-realtime-mini-2025-12-15', 'gpt-audio-1.5', 'gpt-audio-mini', 'gpt-audio-mini-2025-10-06', 'gpt-audio-mini-2025-12-15']] | Omit" = OMIT, output_modalities: "List[Literal['text', 'audio']] | Omit" = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, tool_choice: 'RealtimeToolChoiceConfigParam | Omit' = OMIT, tools: 'RealtimeToolsConfigParam | Omit' = OMIT, tracing: 'Optional[RealtimeTracingConfigParam] | Omit' = OMIT, truncation: 'RealtimeTruncationParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Accept an incoming SIP call and configure the realtime session that will handle
it.

Args:
  type: The type of session to create. Always `realtime` for the Realtime API.

  audio: Configuration for input and output audio.

...
```

##### `create(*, sdp: 'str', session: 'RealtimeSessionCreateRequestParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

##### `hangup(call_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
End an active Realtime API call, whether it was initiated over SIP or WebRTC.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `refer(call_id: 'str', *, target_uri: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Transfer an active SIP call to a new destination using the SIP REFER verb.

Args:
  target_uri: URI that should appear in the SIP Refer-To header. Supports values like
      `tel:+14155550123` or `sip:agent@example.com`.

  extra_headers: Send extra headers

...
```

##### `reject(call_id: 'str', *, status_code: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Decline an incoming SIP call by returning a SIP status code to the caller.

Args:
  status_code: SIP response code to send back to the caller. Defaults to `603` (Decline) when
      omitted.

  extra_headers: Send extra headers

...
```

### Sub-resource: `client_secrets`

#### `create(*, expires_after: 'client_secret_create_params.ExpiresAfter | Omit' = OMIT, session: 'client_secret_create_params.Session | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ClientSecretCreateResponse'`

```
Create a Realtime client secret with an associated session configuration.

Client secrets are short-lived tokens that can be passed to a client app, such
as a web frontend or mobile client, which grants access to the Realtime API
without leaking your main API key. You can configure a custom TTL for each
client secret.

You can also attach session configuration options to the client secret, which
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, expires_after: 'client_secret_create_params.ExpiresAfter | Omit' = OMIT, session: 'client_secret_create_params.Session | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ClientSecretCreateResponse'`

```
Create a Realtime client secret with an associated session configuration.

Client secrets are short-lived tokens that can be passed to a client app, such
as a web frontend or mobile client, which grants access to the Realtime API
without leaking your main API key. You can configure a custom TTL for each
client secret.

You can also attach session configuration options to the client secret, which
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, expires_after: 'client_secret_create_params.ExpiresAfter | Omit' = OMIT, session: 'client_secret_create_params.Session | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ClientSecretCreateResponse'`

```
Create a Realtime client secret with an associated session configuration.

Client secrets are short-lived tokens that can be passed to a client app, such
as a web frontend or mobile client, which grants access to the Realtime API
without leaking your main API key. You can configure a custom TTL for each
client secret.

You can also attach session configuration options to the client secret, which
...
```

---

## `client.responses`

### `cancel(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response'`

```
Cancels a model response with the given ID.

Only responses created with the
`background` parameter set to `true` can be cancelled.
[Learn more](https://platform.openai.com/docs/guides/background).

Args:
  extra_headers: Send extra headers
...
```

### `compact(*, model: "Union[Literal['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-mini-2026-03-17', 'gpt-5.4-nano-2026-03-17', 'gpt-5.3-chat-latest', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-chat-latest', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5.1-codex', 'gpt-5.1-mini', 'gpt-5.1-chat-latest', 'gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-5-chat-latest', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o4-mini', 'o4-mini-2025-04-16', 'o3', 'o3-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o1-preview', 'o1-preview-2024-09-12', 'o1-mini', 'o1-mini-2024-09-12', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-audio-preview', 'gpt-4o-audio-preview-2024-10-01', 'gpt-4o-audio-preview-2024-12-17', 'gpt-4o-audio-preview-2025-06-03', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-4o-search-preview', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview-2025-03-11', 'gpt-4o-mini-search-preview-2025-03-11', 'chatgpt-4o-latest', 'codex-mini-latest', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0301', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613', 'o1-pro', 'o1-pro-2025-03-19', 'o3-pro', 'o3-pro-2025-06-10', 'o3-deep-research', 'o3-deep-research-2025-06-26', 'o4-mini-deep-research', 'o4-mini-deep-research-2025-06-26', 'computer-use-preview', 'computer-use-preview-2025-03-11', 'gpt-5-codex', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5.1-codex-max'], str, None]", input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt_cache_key: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CompactedResponse'`

```
Compact a conversation.

Returns a compacted response object.

Learn when and how to compact long-running conversations in the
[conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
For ZDR-compatible compaction details, see
[Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
...
```

### `connect(extra_query: 'Query' = {}, extra_headers: 'Headers' = {}, websocket_connection_options: 'WebSocketConnectionOptions' = {}, on_reconnecting: 'Callable[[ReconnectingEvent], ReconnectingOverrides | None] | None' = None, max_retries: 'int' = 5, initial_delay: 'float' = 0.5, max_delay: 'float' = 8.0, max_queue_size: 'int' = 1048576) -> 'ResponsesConnectionManager'`

```
Connect to a persistent Responses API WebSocket.

Send `response.create` events and receive response stream events over the socket.
```

### `create(*, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

### `delete(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Deletes a model response with the given ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `parse(*, text_format: 'type[TextFormatT] | Omit' = OMIT, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ParseableToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedResponse[TextFormatT]'`

### `retrieve(response_id: 'str', *, include: 'List[ResponseIncludable] | Omit' = OMIT, include_obfuscation: 'bool | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

### `stream(*, response_id: 'str | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, text_format: 'type[TextFormatT] | Omit' = OMIT, tools: 'Iterable[ParseableToolParam] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResponseStreamManager[TextFormatT]'`

### Sub-resource: `input_items`

#### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `with_raw_response`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `with_streaming_response`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

### Sub-resource: `input_tokens`

#### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

#### Sub-resource: `with_raw_response`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

#### Sub-resource: `with_streaming_response`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

### Sub-resource: `with_raw_response`

#### `cancel(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response'`

```
Cancels a model response with the given ID.

Only responses created with the
`background` parameter set to `true` can be cancelled.
[Learn more](https://platform.openai.com/docs/guides/background).

Args:
  extra_headers: Send extra headers
...
```

#### `compact(*, model: "Union[Literal['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-mini-2026-03-17', 'gpt-5.4-nano-2026-03-17', 'gpt-5.3-chat-latest', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-chat-latest', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5.1-codex', 'gpt-5.1-mini', 'gpt-5.1-chat-latest', 'gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-5-chat-latest', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o4-mini', 'o4-mini-2025-04-16', 'o3', 'o3-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o1-preview', 'o1-preview-2024-09-12', 'o1-mini', 'o1-mini-2024-09-12', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-audio-preview', 'gpt-4o-audio-preview-2024-10-01', 'gpt-4o-audio-preview-2024-12-17', 'gpt-4o-audio-preview-2025-06-03', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-4o-search-preview', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview-2025-03-11', 'gpt-4o-mini-search-preview-2025-03-11', 'chatgpt-4o-latest', 'codex-mini-latest', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0301', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613', 'o1-pro', 'o1-pro-2025-03-19', 'o3-pro', 'o3-pro-2025-06-10', 'o3-deep-research', 'o3-deep-research-2025-06-26', 'o4-mini-deep-research', 'o4-mini-deep-research-2025-06-26', 'computer-use-preview', 'computer-use-preview-2025-03-11', 'gpt-5-codex', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5.1-codex-max'], str, None]", input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt_cache_key: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CompactedResponse'`

```
Compact a conversation.

Returns a compacted response object.

Learn when and how to compact long-running conversations in the
[conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
For ZDR-compatible compaction details, see
[Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
...
```

#### `create(*, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### `delete(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Deletes a model response with the given ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `parse(*, text_format: 'type[TextFormatT] | Omit' = OMIT, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ParseableToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedResponse[TextFormatT]'`

#### `retrieve(response_id: 'str', *, include: 'List[ResponseIncludable] | Omit' = OMIT, include_obfuscation: 'bool | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### Sub-resource: `input_items`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `input_tokens`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

### Sub-resource: `with_streaming_response`

#### `cancel(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response'`

```
Cancels a model response with the given ID.

Only responses created with the
`background` parameter set to `true` can be cancelled.
[Learn more](https://platform.openai.com/docs/guides/background).

Args:
  extra_headers: Send extra headers
...
```

#### `compact(*, model: "Union[Literal['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-mini-2026-03-17', 'gpt-5.4-nano-2026-03-17', 'gpt-5.3-chat-latest', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-chat-latest', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5.1-codex', 'gpt-5.1-mini', 'gpt-5.1-chat-latest', 'gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-5-chat-latest', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o4-mini', 'o4-mini-2025-04-16', 'o3', 'o3-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o1-preview', 'o1-preview-2024-09-12', 'o1-mini', 'o1-mini-2024-09-12', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-audio-preview', 'gpt-4o-audio-preview-2024-10-01', 'gpt-4o-audio-preview-2024-12-17', 'gpt-4o-audio-preview-2025-06-03', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-4o-search-preview', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview-2025-03-11', 'gpt-4o-mini-search-preview-2025-03-11', 'chatgpt-4o-latest', 'codex-mini-latest', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0301', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613', 'o1-pro', 'o1-pro-2025-03-19', 'o3-pro', 'o3-pro-2025-06-10', 'o3-deep-research', 'o3-deep-research-2025-06-26', 'o4-mini-deep-research', 'o4-mini-deep-research-2025-06-26', 'computer-use-preview', 'computer-use-preview-2025-03-11', 'gpt-5-codex', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5.1-codex-max'], str, None]", input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt_cache_key: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CompactedResponse'`

```
Compact a conversation.

Returns a compacted response object.

Learn when and how to compact long-running conversations in the
[conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
For ZDR-compatible compaction details, see
[Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
...
```

#### `create(*, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### `delete(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Deletes a model response with the given ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve(response_id: 'str', *, include: 'List[ResponseIncludable] | Omit' = OMIT, include_obfuscation: 'bool | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### Sub-resource: `input_items`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `input_tokens`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

---

## `client.skills`

### `create(*, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Create a new skill.

Args:
  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### `delete(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkill'`

```
Delete a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Skill]'`

```
List all skills for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Get a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `update(skill_id: 'str', *, default_version: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Update the default version pointer for a skill.

Args:
  default_version: The skill version number to set as default.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### Sub-resource: `content`

#### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_raw_response`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_streaming_response`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `versions`

#### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

#### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

#### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `content`

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `with_raw_response`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `with_streaming_response`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `with_raw_response`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `with_streaming_response`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### Sub-resource: `with_raw_response`

#### `create(*, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Create a new skill.

Args:
  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `delete(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkill'`

```
Delete a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Skill]'`

```
List all skills for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Get a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(skill_id: 'str', *, default_version: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Update the default version pointer for a skill.

Args:
  default_version: The skill version number to set as default.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `content`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `versions`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Create a new skill.

Args:
  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `delete(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkill'`

```
Delete a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Skill]'`

```
List all skills for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Get a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(skill_id: 'str', *, default_version: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Update the default version pointer for a skill.

Args:
  default_version: The skill version number to set as default.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `content`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `versions`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

---

## `client.timeout`

Timeout configuration.

**Usage**:

Timeout(None)               # No timeouts.
Timeout(5.0)                # 5s timeout on all operations.
Timeout(None, connect=5.0)  # 5s timeout on connect, no other timeouts.
Timeout(5.0, connect=10.0)  # 10s timeout on connect. 5s timeout elsewhere.
Timeout(5.0, pool=None)     # No timeout on acquiring connection from pool.
                            # 5s timeout elsewhere.

### `as_dict() -> 'dict[str, float | None]'`

---

## `client.uploads`

Use Uploads to upload large files in multiple parts.

### `cancel(upload_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Cancels the Upload.

No Parts may be added after an Upload is cancelled.

Returns the Upload object with status `cancelled`.

Args:
  extra_headers: Send extra headers
...
```

### `complete(upload_id: 'str', *, part_ids: 'SequenceNotStr[str]', md5: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Completes the
[Upload](https://platform.openai.com/docs/api-reference/uploads/object).

Within the returned Upload object, there is a nested
[File](https://platform.openai.com/docs/api-reference/files/object) object that
is ready to use in the rest of the platform.

You can specify the order of the Parts by passing in an ordered list of the Part
...
```

### `create(*, bytes: 'int', filename: 'str', mime_type: 'str', purpose: 'FilePurpose', expires_after: 'upload_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Creates an intermediate
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
that you can add
[Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
Currently, an Upload can accept at most 8 GB in total and expires after an hour
after you create it.

Once you complete the Upload, we will create a
...
```

### `upload_file_chunked(*, file: 'os.PathLike[str] | bytes', mime_type: 'str', purpose: 'FilePurpose', filename: 'str | None' = None, bytes: 'int | None' = None, part_size: 'int | None' = None, md5: 'str | Omit' = OMIT) -> 'Upload'`

```
Splits the given file into multiple parts and uploads them sequentially.

```py
from pathlib import Path

client.uploads.upload_file(
    file=Path("my-paper.pdf"),
    mime_type="pdf",
...
```

### Sub-resource: `parts`

#### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

#### Sub-resource: `with_raw_response`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

#### Sub-resource: `with_streaming_response`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

### Sub-resource: `with_raw_response`

#### `cancel(upload_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Cancels the Upload.

No Parts may be added after an Upload is cancelled.

Returns the Upload object with status `cancelled`.

Args:
  extra_headers: Send extra headers
...
```

#### `complete(upload_id: 'str', *, part_ids: 'SequenceNotStr[str]', md5: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Completes the
[Upload](https://platform.openai.com/docs/api-reference/uploads/object).

Within the returned Upload object, there is a nested
[File](https://platform.openai.com/docs/api-reference/files/object) object that
is ready to use in the rest of the platform.

You can specify the order of the Parts by passing in an ordered list of the Part
...
```

#### `create(*, bytes: 'int', filename: 'str', mime_type: 'str', purpose: 'FilePurpose', expires_after: 'upload_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Creates an intermediate
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
that you can add
[Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
Currently, an Upload can accept at most 8 GB in total and expires after an hour
after you create it.

Once you complete the Upload, we will create a
...
```

#### Sub-resource: `parts`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

### Sub-resource: `with_streaming_response`

#### `cancel(upload_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Cancels the Upload.

No Parts may be added after an Upload is cancelled.

Returns the Upload object with status `cancelled`.

Args:
  extra_headers: Send extra headers
...
```

#### `complete(upload_id: 'str', *, part_ids: 'SequenceNotStr[str]', md5: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Completes the
[Upload](https://platform.openai.com/docs/api-reference/uploads/object).

Within the returned Upload object, there is a nested
[File](https://platform.openai.com/docs/api-reference/files/object) object that
is ready to use in the rest of the platform.

You can specify the order of the Parts by passing in an ordered list of the Part
...
```

#### `create(*, bytes: 'int', filename: 'str', mime_type: 'str', purpose: 'FilePurpose', expires_after: 'upload_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Creates an intermediate
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
that you can add
[Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
Currently, an Upload can accept at most 8 GB in total and expires after an hour
after you create it.

Once you complete the Upload, we will create a
...
```

#### Sub-resource: `parts`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

---

## `client.vector_stores`

### `create(*, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, description: 'str | Omit' = OMIT, expires_after: 'vector_store_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Create a vector store.

Args:
  chunking_strategy: The chunking strategy used to chunk the file(s). If not set, will use the `auto`
      strategy. Only applicable if `file_ids` is non-empty.

  description: A description for the vector store. Can be used to describe the vector store's
      purpose.
...
```

### `delete(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreDeleted'`

```
Delete a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStore]'`

```
Returns a list of vector stores.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

### `retrieve(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Retrieves a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `search(vector_store_id: 'str', *, query: 'Union[str, SequenceNotStr[str]]', filters: 'vector_store_search_params.Filters | Omit' = OMIT, max_num_results: 'int | Omit' = OMIT, ranking_options: 'vector_store_search_params.RankingOptions | Omit' = OMIT, rewrite_query: 'bool | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[VectorStoreSearchResponse]'`

```
Search a vector store for relevant chunks based on a query and file attributes
filter.

Args:
  query: A query string for a search

  filters: A filter to apply based on file attributes.

...
```

### `update(vector_store_id: 'str', *, expires_after: 'Optional[vector_store_update_params.ExpiresAfter] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Modifies a vector store.

Args:
  expires_after: The expiration policy for a vector store.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.
...
```

### Sub-resource: `file_batches`

#### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

#### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

#### `create_and_poll(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store batch and poll until all files have been processed.
```

#### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

#### `poll(batch_id: 'str', *, vector_store_id: 'str', poll_interval_ms: 'int | Omit' = OMIT) -> 'VectorStoreFileBatch'`

```
Wait for the given file batch to be processed.

Note: this will return even if one of the files failed to process, you need to
check batch.file_counts.failed_count to handle this case.
```

#### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `upload_and_poll(vector_store_id: 'str', *, files: 'Iterable[FileTypes]', max_concurrency: 'int' = 5, file_ids: 'SequenceNotStr[str]' = [], poll_interval_ms: 'int | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT) -> 'VectorStoreFileBatch'`

```
Uploads the given files concurrently and then creates a vector store file batch.

If you've already uploaded certain files that you want to include in this batch
then you can pass their IDs through the `file_ids` argument.

By default, if any file upload fails then an exception will be eagerly raised.

The number of concurrency uploads is configurable using the `max_concurrency`
...
```

#### Sub-resource: `with_raw_response`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `with_streaming_response`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `files`

#### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

#### `create_and_poll(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Attach a file to the given vector store and wait for it to be processed.
```

#### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

#### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

#### `poll(file_id: 'str', *, vector_store_id: 'str', poll_interval_ms: 'int | Omit' = OMIT) -> 'VectorStoreFile'`

```
Wait for the vector store file to finish processing.

Note: this will return even if the file failed to process, you need to check
file.last_error and file.status to handle these cases
```

#### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

#### `upload(*, vector_store_id: 'str', file: 'FileTypes', chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT) -> 'VectorStoreFile'`

```
Upload a file to the `files` API and then attach it to the given vector store.

Note the file will be asynchronously processed (you can use the alternative
polling helper method to wait for processing to complete).
```

#### `upload_and_poll(*, vector_store_id: 'str', file: 'FileTypes', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT) -> 'VectorStoreFile'`

```
Add a file to a vector store and poll until processing is complete.
```

#### Sub-resource: `with_raw_response`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

#### Sub-resource: `with_streaming_response`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

### Sub-resource: `with_raw_response`

#### `create(*, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, description: 'str | Omit' = OMIT, expires_after: 'vector_store_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Create a vector store.

Args:
  chunking_strategy: The chunking strategy used to chunk the file(s). If not set, will use the `auto`
      strategy. Only applicable if `file_ids` is non-empty.

  description: A description for the vector store. Can be used to describe the vector store's
      purpose.
...
```

#### `delete(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreDeleted'`

```
Delete a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStore]'`

```
Returns a list of vector stores.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Retrieves a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `search(vector_store_id: 'str', *, query: 'Union[str, SequenceNotStr[str]]', filters: 'vector_store_search_params.Filters | Omit' = OMIT, max_num_results: 'int | Omit' = OMIT, ranking_options: 'vector_store_search_params.RankingOptions | Omit' = OMIT, rewrite_query: 'bool | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[VectorStoreSearchResponse]'`

```
Search a vector store for relevant chunks based on a query and file attributes
filter.

Args:
  query: A query string for a search

  filters: A filter to apply based on file attributes.

...
```

#### `update(vector_store_id: 'str', *, expires_after: 'Optional[vector_store_update_params.ExpiresAfter] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Modifies a vector store.

Args:
  expires_after: The expiration policy for a vector store.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.
...
```

#### Sub-resource: `file_batches`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, description: 'str | Omit' = OMIT, expires_after: 'vector_store_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Create a vector store.

Args:
  chunking_strategy: The chunking strategy used to chunk the file(s). If not set, will use the `auto`
      strategy. Only applicable if `file_ids` is non-empty.

  description: A description for the vector store. Can be used to describe the vector store's
      purpose.
...
```

#### `delete(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreDeleted'`

```
Delete a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStore]'`

```
Returns a list of vector stores.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Retrieves a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `search(vector_store_id: 'str', *, query: 'Union[str, SequenceNotStr[str]]', filters: 'vector_store_search_params.Filters | Omit' = OMIT, max_num_results: 'int | Omit' = OMIT, ranking_options: 'vector_store_search_params.RankingOptions | Omit' = OMIT, rewrite_query: 'bool | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[VectorStoreSearchResponse]'`

```
Search a vector store for relevant chunks based on a query and file attributes
filter.

Args:
  query: A query string for a search

  filters: A filter to apply based on file attributes.

...
```

#### `update(vector_store_id: 'str', *, expires_after: 'Optional[vector_store_update_params.ExpiresAfter] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Modifies a vector store.

Args:
  expires_after: The expiration policy for a vector store.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.
...
```

#### Sub-resource: `file_batches`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

---

## `client.videos`

### `create(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job from a prompt and optional reference assets.

Args:
  prompt: Text prompt that describes the video to generate.

  input_reference: Optional reference asset upload or reference object that guides generation.

  model: The video generation model to use (allowed values: sora-2, sora-2-pro). Defaults
...
```

### `create_and_poll(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, poll_interval_ms: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a video and wait for it to be processed.
```

### `create_character(*, name: 'str', video: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoCreateCharacterResponse'`

```
Create a character from an uploaded video.

Args:
  name: Display name for this API character.

  video: Video file used to create a character.

  extra_headers: Send extra headers
...
```

### `delete(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoDeleteResponse'`

```
Permanently delete a completed or failed video and its stored assets.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `download_content(video_id: 'str', *, variant: "Literal['video', 'thumbnail', 'spritesheet'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download the generated video bytes or a derived preview asset.

Streams the rendered video content for the specified video job.

Args:
  variant: Which downloadable asset to return. Defaults to the MP4 video.

  extra_headers: Send extra headers
...
```

### `edit(*, prompt: 'str', video: 'video_edit_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job by editing a source video or existing
generated video.

Args:
  prompt: Text prompt that describes how to edit the source video.

  video: Reference to the completed video to edit.

...
```

### `extend(*, prompt: 'str', seconds: 'VideoSeconds', video: 'video_extend_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create an extension of a completed video.

Args:
  prompt: Updated text prompt that directs the extension generation.

  seconds: Length of the newly generated extension segment in seconds (allowed values: 4,
      8, 12, 16, 20).

...
```

### `get_character(character_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoGetCharacterResponse'`

```
Fetch a character.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[Video]'`

```
List recently generated videos for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

### `poll(video_id: 'str', *, poll_interval_ms: 'int | Omit' = OMIT) -> 'Video'`

```
Wait for the vector store file to finish processing.

Note: this will return even if the file failed to process, you need to check
file.last_error and file.status to handle these cases
```

### `remix(video_id: 'str', *, prompt: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a remix of a completed video using a refreshed prompt.

Args:
  prompt: Updated text prompt that directs the remix generation.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### `retrieve(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Fetch the latest metadata for a generated video.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_raw_response`

#### `create(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job from a prompt and optional reference assets.

Args:
  prompt: Text prompt that describes the video to generate.

  input_reference: Optional reference asset upload or reference object that guides generation.

  model: The video generation model to use (allowed values: sora-2, sora-2-pro). Defaults
...
```

#### `create_character(*, name: 'str', video: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoCreateCharacterResponse'`

```
Create a character from an uploaded video.

Args:
  name: Display name for this API character.

  video: Video file used to create a character.

  extra_headers: Send extra headers
...
```

#### `delete(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoDeleteResponse'`

```
Permanently delete a completed or failed video and its stored assets.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `download_content(video_id: 'str', *, variant: "Literal['video', 'thumbnail', 'spritesheet'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download the generated video bytes or a derived preview asset.

Streams the rendered video content for the specified video job.

Args:
  variant: Which downloadable asset to return. Defaults to the MP4 video.

  extra_headers: Send extra headers
...
```

#### `edit(*, prompt: 'str', video: 'video_edit_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job by editing a source video or existing
generated video.

Args:
  prompt: Text prompt that describes how to edit the source video.

  video: Reference to the completed video to edit.

...
```

#### `extend(*, prompt: 'str', seconds: 'VideoSeconds', video: 'video_extend_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create an extension of a completed video.

Args:
  prompt: Updated text prompt that directs the extension generation.

  seconds: Length of the newly generated extension segment in seconds (allowed values: 4,
      8, 12, 16, 20).

...
```

#### `get_character(character_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoGetCharacterResponse'`

```
Fetch a character.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[Video]'`

```
List recently generated videos for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `remix(video_id: 'str', *, prompt: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a remix of a completed video using a refreshed prompt.

Args:
  prompt: Updated text prompt that directs the remix generation.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Fetch the latest metadata for a generated video.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `with_streaming_response`

#### `create(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job from a prompt and optional reference assets.

Args:
  prompt: Text prompt that describes the video to generate.

  input_reference: Optional reference asset upload or reference object that guides generation.

  model: The video generation model to use (allowed values: sora-2, sora-2-pro). Defaults
...
```

#### `create_character(*, name: 'str', video: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoCreateCharacterResponse'`

```
Create a character from an uploaded video.

Args:
  name: Display name for this API character.

  video: Video file used to create a character.

  extra_headers: Send extra headers
...
```

#### `delete(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoDeleteResponse'`

```
Permanently delete a completed or failed video and its stored assets.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `download_content(video_id: 'str', *, variant: "Literal['video', 'thumbnail', 'spritesheet'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download the generated video bytes or a derived preview asset.

Streams the rendered video content for the specified video job.

Args:
  variant: Which downloadable asset to return. Defaults to the MP4 video.

  extra_headers: Send extra headers
...
```

#### `edit(*, prompt: 'str', video: 'video_edit_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job by editing a source video or existing
generated video.

Args:
  prompt: Text prompt that describes how to edit the source video.

  video: Reference to the completed video to edit.

...
```

#### `extend(*, prompt: 'str', seconds: 'VideoSeconds', video: 'video_extend_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create an extension of a completed video.

Args:
  prompt: Updated text prompt that directs the extension generation.

  seconds: Length of the newly generated extension segment in seconds (allowed values: 4,
      8, 12, 16, 20).

...
```

#### `get_character(character_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoGetCharacterResponse'`

```
Fetch a character.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[Video]'`

```
List recently generated videos for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `remix(video_id: 'str', *, prompt: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a remix of a completed video using a refreshed prompt.

Args:
  prompt: Updated text prompt that directs the remix generation.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Fetch the latest metadata for a generated video.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.webhooks`

### `unwrap(payload: 'str | bytes', headers: 'HeadersLike', *, secret: 'str | None' = None) -> 'UnwrapWebhookEvent'`

```
Validates that the given payload was sent by OpenAI and parses the payload.
```

### `verify_signature(payload: 'str | bytes', headers: 'HeadersLike', *, secret: 'str | None' = None, tolerance: 'int' = 300) -> 'None'`

```
Validates whether or not the webhook payload was sent by OpenAI.

Args:
    payload: The webhook payload
    headers: The webhook headers
    secret: The webhook secret (optional, will use client secret if not provided)
    tolerance: Maximum age of the webhook in seconds (default: 300 = 5 minutes)
```

---

## `client.with_raw_response`

### Sub-resource: `batches`

#### `cancel(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Cancels an in-progress batch.

The batch will be in status `cancelling` for up to
10 minutes, before changing to `cancelled`, where it will have partial results
(if any) available in the output file.

Args:
  extra_headers: Send extra headers
...
```

#### `create(*, completion_window: "Literal['24h']", endpoint: "Literal['/v1/responses', '/v1/chat/completions', '/v1/embeddings', '/v1/completions', '/v1/moderations', '/v1/images/generations', '/v1/images/edits', '/v1/videos']", input_file_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, output_expires_after: 'batch_create_params.OutputExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Creates and executes a batch from an uploaded file of requests

Args:
  completion_window: The time frame within which the batch should be processed. Currently only `24h`
      is supported.

  endpoint: The endpoint to be used for all requests in the batch. Currently
      `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`, `/v1/completions`,
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Batch]'`

```
List your organization's batches.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Retrieves a batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `completions`

#### `create(*, model: "Union[str, Literal['gpt-3.5-turbo-instruct', 'davinci-002', 'babbage-002']]", prompt: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]], None]', best_of: 'Optional[int] | Omit' = OMIT, echo: 'Optional[bool] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `containers`

#### `create(*, name: 'str', expires_after: 'container_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, memory_limit: "Literal['1g', '4g', '16g', '64g'] | Omit" = OMIT, network_policy: 'container_create_params.NetworkPolicy | Omit' = OMIT, skills: 'Iterable[container_create_params.Skill] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerCreateResponse'`

```
Create Container

Args:
  name: Name of the container to create.

  expires_after: Container expiration time in seconds relative to the 'anchor' time.

  file_ids: IDs of files to copy to the container.
...
```

#### `delete(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, name: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ContainerListResponse]'`

```
List Containers

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerRetrieveResponse'`

```
Retrieve Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `conversations`

#### `create(*, items: 'Optional[Iterable[ResponseInputItemParam]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Create a conversation.

Args:
  items: Initial items to include in the conversation context. You may add up to 20 items
      at a time.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

#### `delete(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationDeletedResource'`

```
Delete a conversation.

Items in the conversation will not be deleted.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Get a conversation

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(conversation_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Update a conversation

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `items`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

### Sub-resource: `embeddings`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]]]', model: 'Union[str, EmbeddingModel]', dimensions: 'int | Omit' = OMIT, encoding_format: "Literal['float', 'base64'] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CreateEmbeddingResponse'`

```
Creates an embedding vector representing the input text.

Args:
  input: Input text to embed, encoded as a string or array of tokens. To embed multiple
      inputs in a single request, pass an array of strings or array of token arrays.
      The input must not exceed the max input tokens for the model (8192 tokens for
      all embedding models), cannot be an empty string, and any array must be 2048
      dimensions or less.
...
```

### Sub-resource: `evals`

#### `create(*, data_source_config: 'eval_create_params.DataSourceConfig', testing_criteria: 'Iterable[eval_create_params.TestingCriterion]', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalCreateResponse'`

```
Create the structure of an evaluation that can be used to test a model's
performance. An evaluation is a set of testing criteria and the config for a
data source, which dictates the schema of the data used in the evaluation. After
creating an evaluation, you can run it on different models and model parameters.
We support several types of graders and datasources. For more information, see
the [Evals guide](https://platform.openai.com/docs/guides/evals).

Args:
...
```

#### `delete(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalDeleteResponse'`

```
Delete an evaluation.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: "Literal['created_at', 'updated_at'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[EvalListResponse]'`

```
List evaluations for a project.

Args:
  after: Identifier for the last eval from the previous pagination request.

  limit: Number of evals to retrieve.

  order: Sort order for evals by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalRetrieveResponse'`

```
Get an evaluation by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(eval_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalUpdateResponse'`

```
Update certain properties of an evaluation.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `runs`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `files`

#### `content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(*, file: 'FileTypes', purpose: 'FilePurpose', expires_after: 'file_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Upload a file that can be used across various endpoints.

Individual files can be
up to 512 MB, and each project can store up to 2.5 TB of files in total. There
is no organization-wide storage limit.

- The Assistants API supports files up to 2 million tokens and of specific file
  types. See the
...
```

#### `delete(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileDeleted'`

```
Delete a file and remove it from all vector stores.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, purpose: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileObject]'`

```
Returns a list of files.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Returns information about a specific file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve_content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `images`

#### `create_variation(*, image: 'FileTypes', model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse'`

```
Creates a variation of a given image.

This endpoint only supports `dall-e-2`.

Args:
  image: The image to use as the basis for the variation(s). Must be a valid PNG file,
      less than 4MB, and square.

...
```

#### `edit(*, image: 'Union[FileTypes, SequenceNotStr[FileTypes]]', prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, input_fidelity: "Optional[Literal['high', 'low']] | Omit" = OMIT, mask: 'FileTypes | Omit' = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024', '1536x1024', '1024x1536', 'auto']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageEditStreamEvent]'`

#### `generate(*, prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, moderation: "Optional[Literal['low', 'auto']] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'hd', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['auto', '1024x1024', '1536x1024', '1024x1536', '256x256', '512x512', '1792x1024', '1024x1792']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, style: "Optional[Literal['vivid', 'natural']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageGenStreamEvent]'`

### Sub-resource: `models`

#### `delete(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelDeleted'`

```
Delete a fine-tuned model.

You must have the Owner role in your organization to
delete a model.

Args:
  extra_headers: Send extra headers

...
```

#### `list(*, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[Model]'`

```
Lists the currently available models, and provides basic information about each
one such as the owner and availability.
```

#### `retrieve(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Model'`

```
Retrieves a model instance, providing basic information about the model such as
the owner and permissioning.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

...
```

### Sub-resource: `moderations`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[ModerationMultiModalInputParam]]', model: 'Union[str, ModerationModel] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModerationCreateResponse'`

```
Classifies if text and/or image inputs are potentially harmful.

Learn more in
the [moderation guide](https://platform.openai.com/docs/guides/moderation).

Args:
  input: Input (or inputs) to classify. Can be a single string, an array of strings, or
      an array of multi-modal input objects similar to other models.
...
```

### Sub-resource: `responses`

#### `cancel(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response'`

```
Cancels a model response with the given ID.

Only responses created with the
`background` parameter set to `true` can be cancelled.
[Learn more](https://platform.openai.com/docs/guides/background).

Args:
  extra_headers: Send extra headers
...
```

#### `compact(*, model: "Union[Literal['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-mini-2026-03-17', 'gpt-5.4-nano-2026-03-17', 'gpt-5.3-chat-latest', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-chat-latest', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5.1-codex', 'gpt-5.1-mini', 'gpt-5.1-chat-latest', 'gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-5-chat-latest', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o4-mini', 'o4-mini-2025-04-16', 'o3', 'o3-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o1-preview', 'o1-preview-2024-09-12', 'o1-mini', 'o1-mini-2024-09-12', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-audio-preview', 'gpt-4o-audio-preview-2024-10-01', 'gpt-4o-audio-preview-2024-12-17', 'gpt-4o-audio-preview-2025-06-03', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-4o-search-preview', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview-2025-03-11', 'gpt-4o-mini-search-preview-2025-03-11', 'chatgpt-4o-latest', 'codex-mini-latest', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0301', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613', 'o1-pro', 'o1-pro-2025-03-19', 'o3-pro', 'o3-pro-2025-06-10', 'o3-deep-research', 'o3-deep-research-2025-06-26', 'o4-mini-deep-research', 'o4-mini-deep-research-2025-06-26', 'computer-use-preview', 'computer-use-preview-2025-03-11', 'gpt-5-codex', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5.1-codex-max'], str, None]", input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt_cache_key: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CompactedResponse'`

```
Compact a conversation.

Returns a compacted response object.

Learn when and how to compact long-running conversations in the
[conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
For ZDR-compatible compaction details, see
[Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
...
```

#### `create(*, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### `delete(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Deletes a model response with the given ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `parse(*, text_format: 'type[TextFormatT] | Omit' = OMIT, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ParseableToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, verbosity: "Optional[Literal['low', 'medium', 'high']] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedResponse[TextFormatT]'`

#### `retrieve(response_id: 'str', *, include: 'List[ResponseIncludable] | Omit' = OMIT, include_obfuscation: 'bool | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### Sub-resource: `input_items`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `input_tokens`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

### Sub-resource: `skills`

#### `create(*, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Create a new skill.

Args:
  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `delete(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkill'`

```
Delete a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Skill]'`

```
List all skills for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Get a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(skill_id: 'str', *, default_version: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Update the default version pointer for a skill.

Args:
  default_version: The skill version number to set as default.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `content`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `versions`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### Sub-resource: `uploads`

#### `cancel(upload_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Cancels the Upload.

No Parts may be added after an Upload is cancelled.

Returns the Upload object with status `cancelled`.

Args:
  extra_headers: Send extra headers
...
```

#### `complete(upload_id: 'str', *, part_ids: 'SequenceNotStr[str]', md5: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Completes the
[Upload](https://platform.openai.com/docs/api-reference/uploads/object).

Within the returned Upload object, there is a nested
[File](https://platform.openai.com/docs/api-reference/files/object) object that
is ready to use in the rest of the platform.

You can specify the order of the Parts by passing in an ordered list of the Part
...
```

#### `create(*, bytes: 'int', filename: 'str', mime_type: 'str', purpose: 'FilePurpose', expires_after: 'upload_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Creates an intermediate
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
that you can add
[Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
Currently, an Upload can accept at most 8 GB in total and expires after an hour
after you create it.

Once you complete the Upload, we will create a
...
```

#### Sub-resource: `parts`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

### Sub-resource: `vector_stores`

#### `create(*, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, description: 'str | Omit' = OMIT, expires_after: 'vector_store_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Create a vector store.

Args:
  chunking_strategy: The chunking strategy used to chunk the file(s). If not set, will use the `auto`
      strategy. Only applicable if `file_ids` is non-empty.

  description: A description for the vector store. Can be used to describe the vector store's
      purpose.
...
```

#### `delete(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreDeleted'`

```
Delete a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStore]'`

```
Returns a list of vector stores.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Retrieves a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `search(vector_store_id: 'str', *, query: 'Union[str, SequenceNotStr[str]]', filters: 'vector_store_search_params.Filters | Omit' = OMIT, max_num_results: 'int | Omit' = OMIT, ranking_options: 'vector_store_search_params.RankingOptions | Omit' = OMIT, rewrite_query: 'bool | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[VectorStoreSearchResponse]'`

```
Search a vector store for relevant chunks based on a query and file attributes
filter.

Args:
  query: A query string for a search

  filters: A filter to apply based on file attributes.

...
```

#### `update(vector_store_id: 'str', *, expires_after: 'Optional[vector_store_update_params.ExpiresAfter] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Modifies a vector store.

Args:
  expires_after: The expiration policy for a vector store.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.
...
```

#### Sub-resource: `file_batches`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

### Sub-resource: `videos`

#### `create(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job from a prompt and optional reference assets.

Args:
  prompt: Text prompt that describes the video to generate.

  input_reference: Optional reference asset upload or reference object that guides generation.

  model: The video generation model to use (allowed values: sora-2, sora-2-pro). Defaults
...
```

#### `create_character(*, name: 'str', video: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoCreateCharacterResponse'`

```
Create a character from an uploaded video.

Args:
  name: Display name for this API character.

  video: Video file used to create a character.

  extra_headers: Send extra headers
...
```

#### `delete(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoDeleteResponse'`

```
Permanently delete a completed or failed video and its stored assets.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `download_content(video_id: 'str', *, variant: "Literal['video', 'thumbnail', 'spritesheet'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download the generated video bytes or a derived preview asset.

Streams the rendered video content for the specified video job.

Args:
  variant: Which downloadable asset to return. Defaults to the MP4 video.

  extra_headers: Send extra headers
...
```

#### `edit(*, prompt: 'str', video: 'video_edit_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job by editing a source video or existing
generated video.

Args:
  prompt: Text prompt that describes how to edit the source video.

  video: Reference to the completed video to edit.

...
```

#### `extend(*, prompt: 'str', seconds: 'VideoSeconds', video: 'video_extend_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create an extension of a completed video.

Args:
  prompt: Updated text prompt that directs the extension generation.

  seconds: Length of the newly generated extension segment in seconds (allowed values: 4,
      8, 12, 16, 20).

...
```

#### `get_character(character_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoGetCharacterResponse'`

```
Fetch a character.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[Video]'`

```
List recently generated videos for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `remix(video_id: 'str', *, prompt: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a remix of a completed video using a refreshed prompt.

Args:
  prompt: Updated text prompt that directs the remix generation.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Fetch the latest metadata for a generated video.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

---

## `client.with_streaming_response`

### Sub-resource: `batches`

#### `cancel(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Cancels an in-progress batch.

The batch will be in status `cancelling` for up to
10 minutes, before changing to `cancelled`, where it will have partial results
(if any) available in the output file.

Args:
  extra_headers: Send extra headers
...
```

#### `create(*, completion_window: "Literal['24h']", endpoint: "Literal['/v1/responses', '/v1/chat/completions', '/v1/embeddings', '/v1/completions', '/v1/moderations', '/v1/images/generations', '/v1/images/edits', '/v1/videos']", input_file_id: 'str', metadata: 'Optional[Metadata] | Omit' = OMIT, output_expires_after: 'batch_create_params.OutputExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Creates and executes a batch from an uploaded file of requests

Args:
  completion_window: The time frame within which the batch should be processed. Currently only `24h`
      is supported.

  endpoint: The endpoint to be used for all requests in the batch. Currently
      `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`, `/v1/completions`,
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Batch]'`

```
List your organization's batches.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Batch'`

```
Retrieves a batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `completions`

#### `create(*, model: "Union[str, Literal['gpt-3.5-turbo-instruct', 'davinci-002', 'babbage-002']]", prompt: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]], None]', best_of: 'Optional[int] | Omit' = OMIT, echo: 'Optional[bool] | Omit' = OMIT, frequency_penalty: 'Optional[float] | Omit' = OMIT, logit_bias: 'Optional[Dict[str, int]] | Omit' = OMIT, logprobs: 'Optional[int] | Omit' = OMIT, max_tokens: 'Optional[int] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, presence_penalty: 'Optional[float] | Omit' = OMIT, seed: 'Optional[int] | Omit' = OMIT, stop: 'Union[Optional[str], SequenceNotStr[str], None] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[ChatCompletionStreamOptionsParam] | Omit' = OMIT, suffix: 'Optional[str] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `containers`

#### `create(*, name: 'str', expires_after: 'container_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, memory_limit: "Literal['1g', '4g', '16g', '64g'] | Omit" = OMIT, network_policy: 'container_create_params.NetworkPolicy | Omit' = OMIT, skills: 'Iterable[container_create_params.Skill] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerCreateResponse'`

```
Create Container

Args:
  name: Name of the container to create.

  expires_after: Container expiration time in seconds relative to the 'anchor' time.

  file_ids: IDs of files to copy to the container.
...
```

#### `delete(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, name: 'str | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ContainerListResponse]'`

```
List Containers

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(container_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ContainerRetrieveResponse'`

```
Retrieve Container

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `create(container_id: 'str', *, file: 'FileTypes | Omit' = OMIT, file_id: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileCreateResponse'`

```
Create a Container File

You can send either a multipart/form-data request with the raw file content, or
a JSON request with a file ID.

Args:
  file: The File object (not file name) to be uploaded.

...
```

##### `delete(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Delete Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(container_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileListResponse]'`

```
List Container files

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

##### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileRetrieveResponse'`

```
Retrieve Container File

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `content`

###### `retrieve(file_id: 'str', *, container_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Retrieve Container File Content

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `conversations`

#### `create(*, items: 'Optional[Iterable[ResponseInputItemParam]] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Create a conversation.

Args:
  items: Initial items to include in the conversation context. You may add up to 20 items
      at a time.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
...
```

#### `delete(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationDeletedResource'`

```
Delete a conversation.

Items in the conversation will not be deleted.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(conversation_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Get a conversation

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(conversation_id: 'str', *, metadata: 'Optional[Metadata]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Update a conversation

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `items`

##### `create(conversation_id: 'str', *, items: 'Iterable[ResponseInputItemParam]', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItemList'`

```
Create items in a conversation with the given ID.

Args:
  items: The items to add to the conversation. You may add up to 20 items at a time.

  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.
...
```

##### `delete(item_id: 'str', *, conversation_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Conversation'`

```
Delete an item from a conversation with the given IDs.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(conversation_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[ConversationItem]'`

```
List all items for a conversation with the given ID.

Args:
  after: An item ID to list items after, used in pagination.

  include: Specify additional output data to include in the model response. Currently
      supported values are:

...
```

##### `retrieve(item_id: 'str', *, conversation_id: 'str', include: 'List[ResponseIncludable] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ConversationItem'`

```
Get a single item from a conversation with the given IDs.

Args:
  include: Additional fields to include in the response. See the `include` parameter for
      [listing Conversation items above](https://platform.openai.com/docs/api-reference/conversations/list-items#conversations_list_items-include)
      for more information.

  extra_headers: Send extra headers
...
```

### Sub-resource: `embeddings`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[int], Iterable[Iterable[int]]]', model: 'Union[str, EmbeddingModel]', dimensions: 'int | Omit' = OMIT, encoding_format: "Literal['float', 'base64'] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CreateEmbeddingResponse'`

```
Creates an embedding vector representing the input text.

Args:
  input: Input text to embed, encoded as a string or array of tokens. To embed multiple
      inputs in a single request, pass an array of strings or array of token arrays.
      The input must not exceed the max input tokens for the model (8192 tokens for
      all embedding models), cannot be an empty string, and any array must be 2048
      dimensions or less.
...
```

### Sub-resource: `evals`

#### `create(*, data_source_config: 'eval_create_params.DataSourceConfig', testing_criteria: 'Iterable[eval_create_params.TestingCriterion]', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalCreateResponse'`

```
Create the structure of an evaluation that can be used to test a model's
performance. An evaluation is a set of testing criteria and the config for a
data source, which dictates the schema of the data used in the evaluation. After
creating an evaluation, you can run it on different models and model parameters.
We support several types of graders and datasources. For more information, see
the [Evals guide](https://platform.openai.com/docs/guides/evals).

Args:
...
```

#### `delete(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalDeleteResponse'`

```
Delete an evaluation.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: "Literal['created_at', 'updated_at'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[EvalListResponse]'`

```
List evaluations for a project.

Args:
  after: Identifier for the last eval from the previous pagination request.

  limit: Number of evals to retrieve.

  order: Sort order for evals by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(eval_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalRetrieveResponse'`

```
Get an evaluation by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(eval_id: 'str', *, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'EvalUpdateResponse'`

```
Update certain properties of an evaluation.

Args:
  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.

      Keys are strings with a maximum length of 64 characters. Values are strings with
...
```

#### Sub-resource: `runs`

##### `cancel(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCancelResponse'`

```
Cancel an ongoing evaluation run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(eval_id: 'str', *, data_source: 'run_create_params.DataSource', metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunCreateResponse'`

```
Kicks off a new run for a given evaluation, specifying the data source, and what
model configuration to use to test. The datasource will be validated against the
schema specified in the config of the evaluation.

Args:
  data_source: Details about the run's data source.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
...
```

##### `delete(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunDeleteResponse'`

```
Delete an eval run.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(eval_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['queued', 'in_progress', 'completed', 'canceled', 'failed'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[RunListResponse]'`

```
Get a list of runs for an evaluation.

Args:
  after: Identifier for the last run from the previous pagination request.

  limit: Number of runs to retrieve.

  order: Sort order for runs by timestamp. Use `asc` for ascending order or `desc` for
...
```

##### `retrieve(run_id: 'str', *, eval_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'RunRetrieveResponse'`

```
Get an evaluation run by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### Sub-resource: `output_items`

###### `list(run_id: 'str', *, eval_id: 'str', after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, status: "Literal['fail', 'pass'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[OutputItemListResponse]'`

```
Get a list of output items for an evaluation run.

Args:
  after: Identifier for the last output item from the previous pagination request.

  limit: Number of output items to retrieve.

  order: Sort order for output items by timestamp. Use `asc` for ascending order or
...
```

###### `retrieve(output_item_id: 'str', *, eval_id: 'str', run_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'OutputItemRetrieveResponse'`

```
Get an evaluation run output item by ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `files`

#### `content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `create(*, file: 'FileTypes', purpose: 'FilePurpose', expires_after: 'file_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Upload a file that can be used across various endpoints.

Individual files can be
up to 512 MB, and each project can store up to 2.5 TB of files in total. There
is no organization-wide storage limit.

- The Assistants API supports files up to 2 million tokens and of specific file
  types. See the
...
```

#### `delete(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileDeleted'`

```
Delete a file and remove it from all vector stores.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, purpose: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[FileObject]'`

```
Returns a list of files.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileObject'`

```
Returns information about a specific file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve_content(file_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'str'`

```
Returns the contents of the specified file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### Sub-resource: `images`

#### `create_variation(*, image: 'FileTypes', model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse'`

```
Creates a variation of a given image.

This endpoint only supports `dall-e-2`.

Args:
  image: The image to use as the basis for the variation(s). Must be a valid PNG file,
      less than 4MB, and square.

...
```

#### `edit(*, image: 'Union[FileTypes, SequenceNotStr[FileTypes]]', prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, input_fidelity: "Optional[Literal['high', 'low']] | Omit" = OMIT, mask: 'FileTypes | Omit' = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['256x256', '512x512', '1024x1024', '1536x1024', '1024x1536', 'auto']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageEditStreamEvent]'`

#### `generate(*, prompt: 'str', background: "Optional[Literal['transparent', 'opaque', 'auto']] | Omit" = OMIT, model: 'Union[str, ImageModel, None] | Omit' = OMIT, moderation: "Optional[Literal['low', 'auto']] | Omit" = OMIT, n: 'Optional[int] | Omit' = OMIT, output_compression: 'Optional[int] | Omit' = OMIT, output_format: "Optional[Literal['png', 'jpeg', 'webp']] | Omit" = OMIT, partial_images: 'Optional[int] | Omit' = OMIT, quality: "Optional[Literal['standard', 'hd', 'low', 'medium', 'high', 'auto']] | Omit" = OMIT, response_format: "Optional[Literal['url', 'b64_json']] | Omit" = OMIT, size: "Optional[Literal['auto', '1024x1024', '1536x1024', '1024x1536', '256x256', '512x512', '1792x1024', '1024x1792']] | Omit" = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, style: "Optional[Literal['vivid', 'natural']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ImagesResponse | Stream[ImageGenStreamEvent]'`

### Sub-resource: `models`

#### `delete(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelDeleted'`

```
Delete a fine-tuned model.

You must have the Owner role in your organization to
delete a model.

Args:
  extra_headers: Send extra headers

...
```

#### `list(*, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[Model]'`

```
Lists the currently available models, and provides basic information about each
one such as the owner and availability.
```

#### `retrieve(model: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Model'`

```
Retrieves a model instance, providing basic information about the model such as
the owner and permissioning.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

...
```

### Sub-resource: `moderations`

#### `create(*, input: 'Union[str, SequenceNotStr[str], Iterable[ModerationMultiModalInputParam]]', model: 'Union[str, ModerationModel] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModerationCreateResponse'`

```
Classifies if text and/or image inputs are potentially harmful.

Learn more in
the [moderation guide](https://platform.openai.com/docs/guides/moderation).

Args:
  input: Input (or inputs) to classify. Can be a single string, an array of strings, or
      an array of multi-modal input objects similar to other models.
...
```

### Sub-resource: `responses`

#### `cancel(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response'`

```
Cancels a model response with the given ID.

Only responses created with the
`background` parameter set to `true` can be cancelled.
[Learn more](https://platform.openai.com/docs/guides/background).

Args:
  extra_headers: Send extra headers
...
```

#### `compact(*, model: "Union[Literal['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-mini-2026-03-17', 'gpt-5.4-nano-2026-03-17', 'gpt-5.3-chat-latest', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-chat-latest', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5.1-codex', 'gpt-5.1-mini', 'gpt-5.1-chat-latest', 'gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-5-2025-08-07', 'gpt-5-mini-2025-08-07', 'gpt-5-nano-2025-08-07', 'gpt-5-chat-latest', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano-2025-04-14', 'o4-mini', 'o4-mini-2025-04-16', 'o3', 'o3-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o1-preview', 'o1-preview-2024-09-12', 'o1-mini', 'o1-mini-2024-09-12', 'gpt-4o', 'gpt-4o-2024-11-20', 'gpt-4o-2024-08-06', 'gpt-4o-2024-05-13', 'gpt-4o-audio-preview', 'gpt-4o-audio-preview-2024-10-01', 'gpt-4o-audio-preview-2024-12-17', 'gpt-4o-audio-preview-2025-06-03', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-4o-search-preview', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview-2025-03-11', 'gpt-4o-mini-search-preview-2025-03-11', 'chatgpt-4o-latest', 'codex-mini-latest', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-1106-preview', 'gpt-4-vision-preview', 'gpt-4', 'gpt-4-0314', 'gpt-4-0613', 'gpt-4-32k', 'gpt-4-32k-0314', 'gpt-4-32k-0613', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-0301', 'gpt-3.5-turbo-0613', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-16k-0613', 'o1-pro', 'o1-pro-2025-03-19', 'o3-pro', 'o3-pro-2025-06-10', 'o3-deep-research', 'o3-deep-research-2025-06-26', 'o4-mini-deep-research', 'o4-mini-deep-research-2025-06-26', 'computer-use-preview', 'computer-use-preview-2025-03-11', 'gpt-5-codex', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5.1-codex-max'], str, None]", input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt_cache_key: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'CompactedResponse'`

```
Compact a conversation.

Returns a compacted response object.

Learn when and how to compact long-running conversations in the
[conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
For ZDR-compatible compaction details, see
[Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
...
```

#### `create(*, background: 'Optional[bool] | Omit' = OMIT, context_management: 'Optional[Iterable[response_create_params.ContextManagement]] | Omit' = OMIT, conversation: 'Optional[response_create_params.Conversation] | Omit' = OMIT, include: 'Optional[List[ResponseIncludable]] | Omit' = OMIT, input: 'Union[str, ResponseInputParam] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, max_output_tokens: 'Optional[int] | Omit' = OMIT, max_tool_calls: 'Optional[int] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, model: 'ResponsesModel | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, prompt: 'Optional[ResponsePromptParam] | Omit' = OMIT, prompt_cache_key: 'str | Omit' = OMIT, prompt_cache_retention: "Optional[Literal['in-memory', '24h']] | Omit" = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, safety_identifier: 'str | Omit' = OMIT, service_tier: "Optional[Literal['auto', 'default', 'flex', 'scale', 'priority']] | Omit" = OMIT, store: 'Optional[bool] | Omit' = OMIT, stream: 'Optional[Literal[False]] | Literal[True] | Omit' = OMIT, stream_options: 'Optional[response_create_params.StreamOptions] | Omit' = OMIT, temperature: 'Optional[float] | Omit' = OMIT, text: 'ResponseTextConfigParam | Omit' = OMIT, tool_choice: 'response_create_params.ToolChoice | Omit' = OMIT, tools: 'Iterable[ToolParam] | Omit' = OMIT, top_logprobs: 'Optional[int] | Omit' = OMIT, top_p: 'Optional[float] | Omit' = OMIT, truncation: "Optional[Literal['auto', 'disabled']] | Omit" = OMIT, user: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### `delete(response_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'None'`

```
Deletes a model response with the given ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `retrieve(response_id: 'str', *, include: 'List[ResponseIncludable] | Omit' = OMIT, include_obfuscation: 'bool | Omit' = OMIT, starting_after: 'int | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Response | Stream[ResponseStreamEvent]'`

#### Sub-resource: `input_items`

##### `list(response_id: 'str', *, after: 'str | Omit' = OMIT, include: 'List[ResponseIncludable] | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[ResponseItem]'`

```
Returns a list of input items for a given response.

Args:
  after: An item ID to list items after, used in pagination.

  include: Additional fields to include in the response. See the `include` parameter for
      Response creation above for more information.

...
```

#### Sub-resource: `input_tokens`

##### `count(*, conversation: 'Optional[input_token_count_params.Conversation] | Omit' = OMIT, input: 'Union[str, Iterable[ResponseInputItemParam], None] | Omit' = OMIT, instructions: 'Optional[str] | Omit' = OMIT, model: 'Optional[str] | Omit' = OMIT, parallel_tool_calls: 'Optional[bool] | Omit' = OMIT, previous_response_id: 'Optional[str] | Omit' = OMIT, reasoning: 'Optional[Reasoning] | Omit' = OMIT, text: 'Optional[input_token_count_params.Text] | Omit' = OMIT, tool_choice: 'Optional[input_token_count_params.ToolChoice] | Omit' = OMIT, tools: 'Optional[Iterable[ToolParam]] | Omit' = OMIT, truncation: "Literal['auto', 'disabled'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'InputTokenCountResponse'`

```
Returns input token counts of the request.

Returns an object with `object` set to `response.input_tokens` and an
`input_tokens` count.

Args:
  conversation: The conversation that this response belongs to. Items from this conversation are
      prepended to `input_items` for this response request. Input items and output
...
```

### Sub-resource: `skills`

#### `create(*, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Create a new skill.

Args:
  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `delete(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkill'`

```
Delete a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[Skill]'`

```
List all skills for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Get a skill by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `update(skill_id: 'str', *, default_version: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Skill'`

```
Update the default version pointer for a skill.

Args:
  default_version: The skill version number to set as default.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `content`

##### `retrieve(skill_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill zip bundle by its ID.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `versions`

##### `create(skill_id: 'str', *, default: 'bool | Omit' = OMIT, files: 'Union[SequenceNotStr[FileTypes], FileTypes] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Create a new immutable skill version.

Args:
  default: Whether to set this version as the default.

  files: Skill files to upload (directory upload) or a single zip file.

  extra_headers: Send extra headers
...
```

##### `delete(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedSkillVersion'`

```
Delete a skill version.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(skill_id: 'str', *, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[SkillVersion]'`

```
List skill versions for a skill.

Args:
  after: The skill version ID to start after.

  limit: Number of versions to retrieve.

  order: Sort order of results by version number.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillVersion'`

```
Get a specific skill version.

Args:
  version: The version number to retrieve.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `content`

###### `retrieve(version: 'str', *, skill_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download a skill version zip bundle.

Args:
  version: The skill version number.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### Sub-resource: `uploads`

#### `cancel(upload_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Cancels the Upload.

No Parts may be added after an Upload is cancelled.

Returns the Upload object with status `cancelled`.

Args:
  extra_headers: Send extra headers
...
```

#### `complete(upload_id: 'str', *, part_ids: 'SequenceNotStr[str]', md5: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Completes the
[Upload](https://platform.openai.com/docs/api-reference/uploads/object).

Within the returned Upload object, there is a nested
[File](https://platform.openai.com/docs/api-reference/files/object) object that
is ready to use in the rest of the platform.

You can specify the order of the Parts by passing in an ordered list of the Part
...
```

#### `create(*, bytes: 'int', filename: 'str', mime_type: 'str', purpose: 'FilePurpose', expires_after: 'upload_create_params.ExpiresAfter | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Upload'`

```
Creates an intermediate
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
that you can add
[Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
Currently, an Upload can accept at most 8 GB in total and expires after an hour
after you create it.

Once you complete the Upload, we will create a
...
```

#### Sub-resource: `parts`

##### `create(upload_id: 'str', *, data: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'UploadPart'`

```
Adds a
[Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
[Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
A Part represents a chunk of bytes from the file you are trying to upload.

Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
maximum of 8 GB.

...
```

### Sub-resource: `vector_stores`

#### `create(*, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, description: 'str | Omit' = OMIT, expires_after: 'vector_store_create_params.ExpiresAfter | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'str | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Create a vector store.

Args:
  chunking_strategy: The chunking strategy used to chunk the file(s). If not set, will use the `auto`
      strategy. Only applicable if `file_ids` is non-empty.

  description: A description for the vector store. Can be used to describe the vector store's
      purpose.
...
```

#### `delete(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreDeleted'`

```
Delete a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStore]'`

```
Returns a list of vector stores.

Args:
  after: A cursor for use in pagination.

`after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
...
```

#### `retrieve(vector_store_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Retrieves a vector store.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `search(vector_store_id: 'str', *, query: 'Union[str, SequenceNotStr[str]]', filters: 'vector_store_search_params.Filters | Omit' = OMIT, max_num_results: 'int | Omit' = OMIT, ranking_options: 'vector_store_search_params.RankingOptions | Omit' = OMIT, rewrite_query: 'bool | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[VectorStoreSearchResponse]'`

```
Search a vector store for relevant chunks based on a query and file attributes
filter.

Args:
  query: A query string for a search

  filters: A filter to apply based on file attributes.

...
```

#### `update(vector_store_id: 'str', *, expires_after: 'Optional[vector_store_update_params.ExpiresAfter] | Omit' = OMIT, metadata: 'Optional[Metadata] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStore'`

```
Modifies a vector store.

Args:
  expires_after: The expiration policy for a vector store.

  metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard.
...
```

#### Sub-resource: `file_batches`

##### `cancel(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Cancel a vector store file batch.

This attempts to cancel the processing of
files in this batch as soon as possible.

Args:
  extra_headers: Send extra headers

...
```

##### `create(vector_store_id: 'str', *, attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, file_ids: 'SequenceNotStr[str] | Omit' = OMIT, files: 'Iterable[file_batch_create_params.File] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Create a vector store file batch.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

##### `list_files(batch_id: 'str', *, vector_store_id: 'str', after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files in a batch.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(batch_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileBatch'`

```
Retrieves a vector store file batch.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### Sub-resource: `files`

##### `content(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileContentResponse]'`

```
Retrieve the parsed contents of a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `create(vector_store_id: 'str', *, file_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]] | Omit' = OMIT, chunking_strategy: 'FileChunkingStrategyParam | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Create a vector store file by attaching a
[File](https://platform.openai.com/docs/api-reference/files) to a
[vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).

Args:
  file_id: A [File](https://platform.openai.com/docs/api-reference/files) ID that the
      vector store should use. Useful for tools like `file_search` that can access
      files. For multi-file ingestion, we recommend
...
```

##### `delete(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFileDeleted'`

```
Delete a vector store file.

This will remove the file from the vector store but
the file itself will not be deleted. To delete the file, use the
[delete file](https://platform.openai.com/docs/api-reference/files/delete)
endpoint.

Args:
...
```

##### `list(vector_store_id: 'str', *, after: 'str | Omit' = OMIT, before: 'str | Omit' = OMIT, filter: "Literal['in_progress', 'completed', 'failed', 'cancelled'] | Omit" = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncCursorPage[VectorStoreFile]'`

```
Returns a list of vector store files.

Args:
  after: A cursor for use in pagination. `after` is an object ID that defines your place
      in the list. For instance, if you make a list request and receive 100 objects,
      ending with obj_foo, your subsequent call can include after=obj_foo in order to
      fetch the next page of the list.

...
```

##### `retrieve(file_id: 'str', *, vector_store_id: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Retrieves a vector store file.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `update(file_id: 'str', *, vector_store_id: 'str', attributes: 'Optional[Dict[str, Union[str, float, bool]]]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VectorStoreFile'`

```
Update attributes on a vector store file.

Args:
  attributes: Set of 16 key-value pairs that can be attached to an object. This can be useful
      for storing additional information about the object in a structured format, and
      querying for objects via API or the dashboard. Keys are strings with a maximum
      length of 64 characters. Values are strings with a maximum length of 512
      characters, booleans, or numbers.
...
```

### Sub-resource: `videos`

#### `create(*, prompt: 'str', input_reference: 'video_create_params.InputReference | Omit' = OMIT, model: 'VideoModelParam | Omit' = OMIT, seconds: 'VideoSeconds | Omit' = OMIT, size: 'VideoSize | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job from a prompt and optional reference assets.

Args:
  prompt: Text prompt that describes the video to generate.

  input_reference: Optional reference asset upload or reference object that guides generation.

  model: The video generation model to use (allowed values: sora-2, sora-2-pro). Defaults
...
```

#### `create_character(*, name: 'str', video: 'FileTypes', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoCreateCharacterResponse'`

```
Create a character from an uploaded video.

Args:
  name: Display name for this API character.

  video: Video file used to create a character.

  extra_headers: Send extra headers
...
```

#### `delete(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoDeleteResponse'`

```
Permanently delete a completed or failed video and its stored assets.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `download_content(video_id: 'str', *, variant: "Literal['video', 'thumbnail', 'spritesheet'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> '_legacy_response.HttpxBinaryResponseContent'`

```
Download the generated video bytes or a derived preview asset.

Streams the rendered video content for the specified video job.

Args:
  variant: Which downloadable asset to return. Defaults to the MP4 video.

  extra_headers: Send extra headers
...
```

#### `edit(*, prompt: 'str', video: 'video_edit_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a new video generation job by editing a source video or existing
generated video.

Args:
  prompt: Text prompt that describes how to edit the source video.

  video: Reference to the completed video to edit.

...
```

#### `extend(*, prompt: 'str', seconds: 'VideoSeconds', video: 'video_extend_params.Video', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create an extension of a completed video.

Args:
  prompt: Updated text prompt that directs the extension generation.

  seconds: Length of the newly generated extension segment in seconds (allowed values: 4,
      8, 12, 16, 20).

...
```

#### `get_character(character_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VideoGetCharacterResponse'`

```
Fetch a character.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, after: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncConversationCursorPage[Video]'`

```
List recently generated videos for the current project.

Args:
  after: Identifier for the last item from the previous pagination request

  limit: Number of items to retrieve

  order: Sort order of results by timestamp. Use `asc` for ascending order or `desc` for
...
```

#### `remix(video_id: 'str', *, prompt: 'str', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Create a remix of a completed video using a refreshed prompt.

Args:
  prompt: Updated text prompt that directs the remix generation.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `retrieve(video_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Video'`

```
Fetch the latest metadata for a generated video.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```
