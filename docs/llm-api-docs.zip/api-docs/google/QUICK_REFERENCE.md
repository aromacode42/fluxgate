# Google Gemini API — Quick Reference

A condensed lookup card for the most-used endpoints. For the full method-level reference, see `API_REFERENCE.md`.

There are **two distinct deployment surfaces** for Gemini, and they differ in URL, auth, and quota model:

| Surface | Base URL | Auth | When to use |
|---|---|---|---|
| **Gemini Developer API** | `https://generativelanguage.googleapis.com` | API key (`?key=...` or `x-goog-api-key` header) | Quick start, hobby, individual dev |
| **Vertex AI** | `https://{LOCATION}-aiplatform.googleapis.com` | GCP OAuth (Application Default Credentials) | Enterprise, GCP integration, IAM-controlled |

The same model IDs work on both. The `google-genai` SDK abstracts the difference via a constructor flag.

---

## Two parallel API versions

| Path | What lives there |
|---|---|
| `/v1/...` | Stable GA features only |
| `/v1beta/...` | Newer features, especially: File API, certain tools, Live API, Cached Content, some structured-output configs |

Many real-world features are **`v1beta`-only**. Pick `v1beta` unless you have a strict stability requirement.

---

## Core: Generate Content

### Gemini Developer API
```bash
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-pro-preview:generateContent?key=$GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [
      {"role": "user", "parts": [{"text": "Hello"}]}
    ],
    "systemInstruction": {"parts": [{"text": "You are helpful."}]},
    "generationConfig": {
      "maxOutputTokens": 1024,
      "thinkingConfig": {"thinkingLevel": "medium"}
    }
  }'
```

### Vertex AI
```
POST https://{LOCATION}-aiplatform.googleapis.com/v1/projects/{PROJECT}/locations/{LOCATION}/publishers/google/models/{MODEL}:generateContent
```
Same body shape; auth via `Authorization: Bearer $(gcloud auth print-access-token)`.

### Streaming variant
Use `:streamGenerateContent` instead of `:generateContent`. Returns SSE.

---

## Request body fields

| Field | Type | Notes |
|---|---|---|
| `contents` | array of Content | Required. Each item: `{role: "user"\|"model", parts: [...]}` |
| `systemInstruction` | Content | Top-level system prompt |
| `tools` | array | Function declarations or built-in tools |
| `toolConfig` | object | `{functionCallingConfig: {mode: "AUTO"\|"ANY"\|"NONE", allowedFunctionNames: [...]}}` |
| `safetySettings` | array | Per-category thresholds |
| `generationConfig` | object | See below |
| `cachedContent` | string | Reference to a Cached Content resource |

### `generationConfig` fields

| Field | Notes |
|---|---|
| `temperature` | 0..2 |
| `topP`, `topK` | sampling |
| `maxOutputTokens` | output cap |
| `stopSequences` | array of strings |
| `responseMimeType` | `"application/json"` for JSON mode |
| `responseSchema` | JSON schema for structured output |
| `thinkingConfig.thinkingLevel` | `"low" \| "medium" \| "high"` (Gemini 3+) |
| `thinkingConfig.thinkingBudget` | int (legacy 2.5 series; **mutually exclusive with `thinkingLevel`** — combining returns 400) |
| `thinkingConfig.includeThoughts` | bool — return thought summaries |
| `seed` | reproducibility |
| `candidateCount` | how many completions |

---

## `parts` array — multimodal content

Each `part` has exactly one of:
- `text` — string
- `inlineData` — `{mimeType, data}` (base64 inline, ≤ 20MB)
- `fileData` — `{mimeType, fileUri}` (reference uploaded file or GCS URI)
- `functionCall` — `{name, args}` (model output)
- `functionResponse` — `{name, response}` (your tool's output)
- `executableCode`, `codeExecutionResult` — for code execution tool
- `thought` (with `thoughtSignature`) — extended thinking

Sample multimodal user turn:
```json
{
  "role": "user",
  "parts": [
    {"inlineData": {"mimeType": "image/jpeg", "data": "<base64>"}},
    {"text": "What's in this image?"}
  ]
}
```

---

## Tool / function calling

```json
{
  "tools": [{
    "functionDeclarations": [{
      "name": "get_weather",
      "description": "Get weather for a location",
      "parameters": {
        "type": "object",
        "properties": {"location": {"type": "string"}},
        "required": ["location"]
      }
    }]
  }]
}
```

Built-in tools (specify each as its own object in the `tools` array):
- `{"googleSearch": {}}` — Google Search grounding
- `{"googleSearchRetrieval": {}}` — older search variant
- `{"codeExecution": {}}` — sandboxed Python
- `{"urlContext": {}}` — fetch URLs the model decides to read
- `{"computerUse": {}}` — computer-use tool (Gemini 3 only)

---

## Other top-level methods on a model

| Method | Purpose |
|---|---|
| `:generateContent` | One-shot generation |
| `:streamGenerateContent` | SSE-streamed generation |
| `:countTokens` | Token counting (no billing) |
| `:embedContent` (embedding models) | Single-input embedding |
| `:batchEmbedContents` | Batch embeddings |

---

## File API (`v1beta` only)

For files > 20MB or to reuse across calls:

```bash
# Upload (resumable; this is the "start" call)
curl -X POST "https://generativelanguage.googleapis.com/upload/v1beta/files?key=$KEY" \
  -H "X-Goog-Upload-Command: start, upload, finalize" \
  -H "X-Goog-Upload-Header-Content-Length: <BYTES>" \
  -H "X-Goog-Upload-Header-Content-Type: image/jpeg" \
  -H "Content-Type: application/json" \
  -d '{"file":{"displayName":"my-image"}}' \
  --data-binary @image.jpg
```

Returns a `name` like `files/abc123` and `uri`. Reference in subsequent requests via `fileData.fileUri`. Files auto-expire after 48h.

Other endpoints: `GET /v1beta/files`, `GET /v1beta/files/{id}`, `DELETE /v1beta/files/{id}`.

---

## Cached Content

Reuse a long prefix across many requests for cost savings:
```
POST /v1beta/cachedContents
{
  "model": "models/gemini-2.5-pro",
  "contents": [...],
  "systemInstruction": {...},
  "ttl": "3600s"
}
```
Returns a resource name; pass via `cachedContent` in subsequent `generateContent` calls.

---

## Live API (`v1beta`)

WebSocket for realtime audio/video bidirectional streaming. Model: `gemini-3.1-flash-live-preview` (current). Endpoint: `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=...`

Session config and tool use are sent as JSON messages over the WebSocket.

---

## Models

| Endpoint | Purpose |
|---|---|
| `GET /v1/models` | List all models |
| `GET /v1/models/{model}` | Single model details |

---

## Image / Video / Music generation

| Family | Endpoint | Notes |
|---|---|---|
| Imagen | `models/imagen-4.0-...:predict` | Image generation |
| Gemini image | `models/gemini-3-pro-image-preview:generateContent` | "Nano Banana Pro" — uses Generate Content shape |
| Veo | `models/veo-3.0-generate-001:predictLongRunning` | Long-running operation; poll for completion |
| Lyria | `models/lyria-3-pro-preview:predictLongRunning` | Music generation |

The long-running operations return an Operation resource; poll `GET /v1beta/{operation_name}` until `done: true`.

---

## OpenAI-compatibility shim

Gemini exposes an OpenAI-compatible endpoint to ease migration:

```python
from openai import OpenAI
client = OpenAI(
    api_key="GEMINI_API_KEY",
    base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
)
resp = client.chat.completions.create(
    model="gemini-3.1-pro-preview",
    messages=[{"role": "user", "content": "Hello"}]
)
```

Most `/v1/chat/completions` features work; some Gemini-specific things (thinking levels, certain built-in tools) require the native API.

---

## Errors

```json
{
  "error": {
    "code": 400,
    "message": "...",
    "status": "INVALID_ARGUMENT",
    "details": [...]
  }
}
```

Common `status` values: `INVALID_ARGUMENT`, `UNAUTHENTICATED`, `PERMISSION_DENIED`, `NOT_FOUND`, `RESOURCE_EXHAUSTED` (rate limit), `INTERNAL`, `UNAVAILABLE`.

---

## Rate limits and quotas

- Quotas are per-project (Vertex AI) or per-API-key (Developer API).
- Free tier exists for the Developer API with much lower limits.
- Inspect quotas in: AI Studio (Developer API) or GCP Console > IAM & Admin > Quotas (Vertex AI).
- 429 responses include retry guidance.

---

## SDK migration: `google-generativeai` → `google-genai`

The old SDK is **deprecated**. Key differences:

| Old (`google-generativeai`) | New (`google-genai`) |
|---|---|
| `import google.generativeai as genai` | `from google import genai` |
| `genai.configure(api_key=...)` | `client = genai.Client(api_key=...)` |
| `model = genai.GenerativeModel("gemini-1.5-pro")` | (no model object — pass model on each call) |
| `model.generate_content(...)` | `client.models.generate_content(model="...", contents=...)` |
| `model.start_chat()` | `client.chats.create(model="...")` |

Vertex AI also unifies under the same client:
```python
client = genai.Client(vertexai=True, project="my-project", location="us-central1")
```

Full migration guide: https://ai.google.dev/gemini-api/docs/migrate
