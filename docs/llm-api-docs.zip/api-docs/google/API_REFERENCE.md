# Google Gemini Python SDK (google-genai) — API Reference

**SDK Version:** `1.73.1`
**API Base URL (Gemini Developer API):** `https://generativelanguage.googleapis.com`
**API Base URL (Vertex AI):** `https://{LOCATION}-aiplatform.googleapis.com`
**API Version:** `v1` (stable), `v1beta` (preview features)

> Note: The package name `google-generativeai` is **deprecated** in favor of `google-genai`.
> Auto-generated from SDK introspection.

---

## Authentication

**Gemini Developer API:**
```python
from google import genai
client = genai.Client(api_key="GEMINI_API_KEY")
```

**Vertex AI:**
```python
client = genai.Client(vertexai=True, project='my-project', location='us-central1')
```

---

## Top-level Resources on `Client`

| Resource | Class |
|---|---|
| `client.aio` | `AsyncClient` |
| `client.auth_tokens` | `Tokens` |
| `client.batches` | `Batches` |
| `client.caches` | `Caches` |
| `client.chats` | `Chats` |
| `client.file_search_stores` | `FileSearchStores` |
| `client.files` | `Files` |
| `client.interactions` | `InteractionsResource` |
| `client.models` | `Models` |
| `client.operations` | `Operations` |
| `client.tunings` | `Tunings` |
| `client.webhooks` | `WebhooksResource` |

---

## `client.aio`

Client for making asynchronous (non-blocking) requests.

### `aclose() -> None`

```
Closes the async client explicitly.

However, it doesn't close the sync client, which can be closed using the
Client.close() method or using the context manager.

Usage:
.. code-block:: python

...
```

### Sub-resource: `auth_tokens`

#### `create(*, config: Union[google.genai.types.CreateAuthTokenConfig, google.genai.types.CreateAuthTokenConfigDict, NoneType] = None) -> google.genai.types.AuthToken`

```
Creates an auth token asynchronously. Support in v1alpha only.

Args:
  config (CreateAuthTokenConfig): Optional configuration for the request.

Usage:

.. code-block:: python
...
```

### Sub-resource: `batches`

#### `cancel(*, name: str, config: Union[google.genai.types.CancelBatchJobConfig, google.genai.types.CancelBatchJobConfigDict, NoneType] = None) -> None`

```
Cancels a batch job.

Only available for batch jobs that are running or pending.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the Vertex AI client. Or
...
```

#### `create(*, model: str, src: Union[google.genai.types.BatchJobSource, list[google.genai.types.InlinedRequest], str, google.genai.types.BatchJobSourceDict, list[google.genai.types.InlinedRequestDict]], config: Union[google.genai.types.CreateBatchJobConfig, google.genai.types.CreateBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
Creates a batch job asynchronously.

Args:
  model (str): The model to use for the batch job.
  src: The source of the batch job. Currently Vertex AI supports GCS URI(-s)
    or BigQuery URI. Example: "gs://path/to/input/data" or
    "bq://projectId.bqDatasetId.bqTableId". Gemini Develop API supports List
    of inlined_request, or file name. Example: "files/file_name".
...
```

#### `create_embeddings(*, model: str, src: Union[google.genai.types.EmbeddingsBatchJobSource, google.genai.types.EmbeddingsBatchJobSourceDict], config: Union[google.genai.types.CreateEmbeddingsBatchJobConfig, google.genai.types.CreateEmbeddingsBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
**Experimental** Creates an asynchronously embedding batch job.

Args:
  model (str): The model to use for the batch job.
  src: Gemini Developer API supports inlined_requests, or file name.
    Example: "files/file_name".
  config (CreateBatchJobConfig): Optional configuration for the batch job.

...
```

#### `delete(*, name: str, config: Union[google.genai.types.DeleteBatchJobConfig, google.genai.types.DeleteBatchJobConfigDict, NoneType] = None) -> google.genai.types.DeleteResourceJob`

```
Deletes a batch job.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the client.

Returns:
...
```

#### `get(*, name: str, config: Union[google.genai.types.GetBatchJobConfig, google.genai.types.GetBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
Gets a batch job.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the Vertex AI client. Or
      "batches/abc" using the Gemini Developer AI client.

...
```

#### `list(*, config: Union[google.genai.types.ListBatchJobsConfig, google.genai.types.ListBatchJobsConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.BatchJob]`

```
Lists batch jobs asynchronously.

Args:
  config (ListBatchJobsConfig): Optional configuration for the list request.

Returns:
  A Pager object that contains one page of batch jobs. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

### Sub-resource: `caches`

#### `create(*, model: str, config: Union[google.genai.types.CreateCachedContentConfig, google.genai.types.CreateCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Creates a cached contents resource.

Usage:

.. code-block:: python

  contents = ... // Initialize the content to cache.
  response = await client.aio.caches.create(
...
```

#### `delete(*, name: str, config: Union[google.genai.types.DeleteCachedContentConfig, google.genai.types.DeleteCachedContentConfigDict, NoneType] = None) -> google.genai.types.DeleteCachedContentResponse`

```
Deletes cached content.

Usage:

.. code-block:: python

  await client.aio.caches.delete(name= ... ) // The server-generated
  resource name.
```

#### `get(*, name: str, config: Union[google.genai.types.GetCachedContentConfig, google.genai.types.GetCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Gets cached content configurations.

.. code-block:: python

  await client.aio.caches.get(name= ... ) // The server-generated resource
  name.
```

#### `list(*, config: Union[google.genai.types.ListCachedContentsConfig, google.genai.types.ListCachedContentsConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.CachedContent]`

```
Lists cached contents asynchronously.

Args:
  config (ListCachedContentsConfig): Optional configuration for the list
    request.

Returns:
  A Pager object that contains one page of cached contents. When iterating
...
```

#### `update(*, name: str, config: Union[google.genai.types.UpdateCachedContentConfig, google.genai.types.UpdateCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Updates cached content configurations.

.. code-block:: python

  response = await client.aio.caches.update(
      name= ... // The server-generated resource name.
      config={
          'ttl': '7600s',
...
```

### Sub-resource: `chats`

#### `create(*, model: str, config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None, history: Optional[list[Union[google.genai.types.Content, google.genai.types.ContentDict]]] = None) -> google.genai.chats.AsyncChat`

```
Creates a new chat session.

Args:
  model: The model to use for the chat.
  config: The configuration to use for the generate content request.
  history: The history to use for the chat.

Returns:
...
```

### Sub-resource: `file_search_stores`

#### `create(*, config: Union[google.genai.types.CreateFileSearchStoreConfig, google.genai.types.CreateFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.FileSearchStore`

```
Creates a File Search Store.

Args:
  config (CreateFileSearchStoreConfig | None): Optional parameters for the
    request.

Returns:
  FileSearchStore
```

#### `delete(*, name: str, config: Union[google.genai.types.DeleteFileSearchStoreConfig, google.genai.types.DeleteFileSearchStoreConfigDict, NoneType] = None) -> None`

```
Deletes a FileSearchStore.

Args:
  name (str): The resource name of the FileSearchStore. Example:
    `FileSearchStores/my-file-search-store-123`
  config (DeleteFileSearchStoreConfig | None): Optional parameters for the
    request.

...
```

#### `get(*, name: str, config: Union[google.genai.types.GetFileSearchStoreConfig, google.genai.types.GetFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.FileSearchStore`

```
Gets metadata about a FileSearchStore.

Args:
  name (str): The resource name of the FileSearchStore. Example:
    `FileSearchStores/my-file-search-store-123`
  config (GetFileSearchStoreConfig | None): Optional parameters for the
    request.

...
```

#### `import_file(*, file_search_store_name: str, file_name: str, config: Union[google.genai.types.ImportFileConfig, google.genai.types.ImportFileConfigDict, NoneType] = None) -> google.genai.types.ImportFileOperation`

```
Imports a File from File Service to a FileSearchStore.

This is a long-running operation, see aip.dev/151

Args:
  file_search_store_name (str): The resource name of the FileSearchStore.
    Example: `fileSearchStores/my-file-search-store-123`
  file_name (str): The resource name of the File to import. Example:
...
```

#### `list(*, config: Union[google.genai.types.ListFileSearchStoresConfig, google.genai.types.ListFileSearchStoresConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.FileSearchStore]`

```
Lists FileSearchStores asynchronously.

Args:
  config (ListFileSearchStoresConfig): Optional parameters for the request,
    such as page_size.

Returns:
  A Pager object that contains one page of FileSearchStores. When iterating
...
```

#### `upload_to_file_search_store(*, file_search_store_name: str, file: Union[str, os.PathLike[str], io.IOBase], config: Union[google.genai.types.UploadToFileSearchStoreConfig, google.genai.types.UploadToFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.UploadToFileSearchStoreOperation`

```
Calls the API to upload a file to the given file search store.

Args:
  file_search_store_name: The resource name of the FileSearchStore. Example:
    `fileSearchStores/file-search-store-123`
  file: A path to the file or an `IOBase` object to be uploaded. If it's an
    IOBase object, it must be opened in blocking (the default) mode and
    binary mode. In other words, do not use non-blocking mode or text mode.
...
```

#### Sub-resource: `documents`

##### `delete(*, name: str, config: Union[google.genai.types.DeleteDocumentConfig, google.genai.types.DeleteDocumentConfigDict, NoneType] = None) -> None`

```
Deletes a Document.

Args:
  name (str): The resource name of the Document.
    Example: ragStores/rag-store-foo/documents/documents-bar
  config (DeleteDocumentConfig | None): Optional parameters for the request.

Returns:
...
```

##### `get(*, name: str, config: Union[google.genai.types.GetDocumentConfig, google.genai.types.GetDocumentConfigDict, NoneType] = None) -> google.genai.types.Document`

```
Gets metadata about a Document.

Args:
  name (str): The resource name of the Document.
    Example: ragStores/rag-store-foo/documents/documents-bar
  config (GetDocumentConfig | None): Optional parameters for the request.

Returns:
...
```

##### `list(*, parent: str, config: Union[google.genai.types.ListDocumentsConfig, google.genai.types.ListDocumentsConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.Document]`

```
Lists documents asynchronously.

Args:
  parent (str): The name of the RagStore containing the Documents.
  config (ListDocumentsConfig): Optional configuration for the list request.

Returns:
  A Pager object that contains one page of documents. When iterating over
...
```

### Sub-resource: `files`

#### `delete(*, name: str, config: Union[google.genai.types.DeleteFileConfig, google.genai.types.DeleteFileConfigDict, NoneType] = None) -> google.genai.types.DeleteFileResponse`

```
Deletes a remotely stored file.

Args:
  name (str): The name identifier for the file to delete.
  config (DeleteFileConfig): Optional, configuration for the delete method.

Returns:
  DeleteFileResponse: The response for the delete method
...
```

#### `download(*, file: Union[str, google.genai.types.File], config: Union[google.genai.types.DownloadFileConfig, google.genai.types.DownloadFileConfigDict, NoneType] = None) -> bytes`

```
Downloads a file's data from the file service.

The Vertex-AI implementation of the API foes not include the file service.

Files created by `upload` can't be downloaded. You can tell which files are
downloadable by checking the `download_uri` property.

Args:
...
```

#### `get(*, name: str, config: Union[google.genai.types.GetFileConfig, google.genai.types.GetFileConfigDict, NoneType] = None) -> google.genai.types.File`

```
Retrieves the file information from the service.

Args:
  name (str): The name identifier for the file to retrieve.
  config (GetFileConfig): Optional, configuration for the get method.

Returns:
  File: The file information.
...
```

#### `list(*, config: Union[google.genai.types.ListFilesConfig, google.genai.types.ListFilesConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.File]`

```
Lists all files from the service asynchronously.

Args:
  config (ListFilesConfig): Optional, configuration for the list method.

Returns:
  A Pager object that contains one page of files. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

#### `register_files(*, auth: google.auth.credentials.Credentials, uris: list[str], config: Union[google.genai.types.RegisterFilesConfig, google.genai.types.RegisterFilesConfigDict, NoneType] = None) -> google.genai.types.RegisterFilesResponse`

```
Registers gcs files with the file service.
```

#### `upload(*, file: Union[str, os.PathLike[str], io.IOBase], config: Union[google.genai.types.UploadFileConfig, google.genai.types.UploadFileConfigDict, NoneType] = None) -> google.genai.types.File`

```
Calls the API to upload a file asynchronously using a supported file service.

Args:
  file: A path to the file or an `IOBase` object to be uploaded. If it's an
    IOBase object, it must be opened in blocking (the default) mode and
    binary mode. In other words, do not use non-blocking mode or text mode.
    The given stream must be seekable, that is, it must be able to call
    `seek()` on 'path'.
...
```

### Sub-resource: `interactions`

#### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

#### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

#### Sub-resource: `with_raw_response`

##### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

##### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

##### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

#### Sub-resource: `with_streaming_response`

##### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

##### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

##### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | AsyncStream[InteractionSSEEvent]'`

### Sub-resource: `live`

#### `connect(*, model: str, config: Union[google.genai.types.LiveConnectConfig, google.genai.types.LiveConnectConfigDict, NoneType] = None) -> AsyncIterator[google.genai.live.AsyncSession]`

```
[Preview] Connect to the live server.

Note: the live API is currently in preview.

Usage:

.. code-block:: python

...
```

#### Sub-resource: `music`

##### `connect(*, model: str) -> AsyncIterator[google.genai.live_music.AsyncMusicSession]`

```
[Experimental] Connect to the live music server.
```

### Sub-resource: `models`

#### `compute_tokens(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.ComputeTokensConfig, google.genai.types.ComputeTokensConfigDict, NoneType] = None) -> google.genai.types.ComputeTokensResponse`

```
Given a list of contents, returns a corresponding TokensInfo containing the

list of tokens and list of token ids.


Args:
  model (str): The model to use.
  contents (list[shared.Content]): The content to compute tokens for.
...
```

#### `count_tokens(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.CountTokensConfig, google.genai.types.CountTokensConfigDict, NoneType] = None) -> google.genai.types.CountTokensResponse`

```
Counts the number of tokens in the given content.

Multimodal input is supported for Gemini models.

Args:
  model (str): The model to use for counting tokens.
  contents (list[types.Content]): The content to count tokens for.
  config (CountTokensConfig): The configuration for counting tokens.
...
```

#### `delete(*, model: str, config: Union[google.genai.types.DeleteModelConfig, google.genai.types.DeleteModelConfigDict, NoneType] = None) -> google.genai.types.DeleteModelResponse`

#### `edit_image(*, model: str, prompt: str, reference_images: list[typing.Union[google.genai.types._ReferenceImageAPI, google.genai.types._ReferenceImageAPIDict]], config: Union[google.genai.types.EditImageConfig, google.genai.types.EditImageConfigDict, NoneType] = None) -> google.genai.types.EditImageResponse`

```
Edits an image based on a text description and configuration.

Args:
  model (str): The model to use.
  prompt (str): A text description of the edit to apply to the image.
    reference_images (list[Union[RawReferenceImage, MaskReferenceImage,
    ControlReferenceImage, StyleReferenceImage, SubjectReferenceImage]): The
    reference images for editing.
...
```

#### `embed_content(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.EmbedContentConfig, google.genai.types.EmbedContentConfigDict, NoneType] = None) -> google.genai.types.EmbedContentResponse`

```
Calculates embeddings for the given contents.

Args:
  model (str): The model to use.
  contents (list[Content]): The contents to embed.
  config (EmbedContentConfig): Optional configuration for embeddings.

Usage:
...
```

#### `generate_content(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None) -> google.genai.types.GenerateContentResponse`

```
Makes an API request to generate content using a model.

Some models support multimodal input and output.

Built-in MCP support is an experimental feature.

Usage:

...
```

#### `generate_content_stream(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None) -> AsyncIterator[google.genai.types.GenerateContentResponse]`

```
Makes an API request to generate content using a model and yields the model's response in chunks.

For the `model` parameter, supported formats for Vertex AI API include:
- The Gemini model ID, for example: 'gemini-2.0-flash'
- The full resource name starts with 'projects/', for example:
  'projects/my-project-id/locations/us-central1/publishers/google/models/gemini-2.0-flash'
- The partial resource name with 'publishers/', for example:
  'publishers/google/models/gemini-2.0-flash' or
...
```

#### `generate_images(*, model: str, prompt: str, config: Union[google.genai.types.GenerateImagesConfig, google.genai.types.GenerateImagesConfigDict, NoneType] = None) -> google.genai.types.GenerateImagesResponse`

```
Generates images based on a text description and configuration.

Args:
  model (str): The model to use.
  prompt (str): A text description of the images to generate.
  config (GenerateImagesConfig): Configuration for generation.

Usage:
...
```

#### `generate_videos(*, model: str, prompt: Optional[str] = None, image: Union[google.genai.types.Image, google.genai.types.ImageDict, NoneType] = None, video: Union[google.genai.types.Video, google.genai.types.VideoDict, NoneType] = None, source: Union[google.genai.types.GenerateVideosSource, google.genai.types.GenerateVideosSourceDict, NoneType] = None, config: Union[google.genai.types.GenerateVideosConfig, google.genai.types.GenerateVideosConfigDict, NoneType] = None) -> google.genai.types.GenerateVideosOperation`

```
Generates videos based on an input (text, image, or video) and configuration.

The following use cases are supported:
1. Text to video generation.
2a. Image to video generation (additional text prompt is optional).
2b. Image to video generation with frame interpolation (specify last_frame
in config).
3. Video extension (additional text prompt is optional)
...
```

#### `get(*, model: str, config: Union[google.genai.types.GetModelConfig, google.genai.types.GetModelConfigDict, NoneType] = None) -> google.genai.types.Model`

#### `list(*, config: Union[google.genai.types.ListModelsConfig, google.genai.types.ListModelsConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.Model]`

```
Makes an API request to list the available models.

If `query_base` is set to True in the config or not set (default), the
API will return all available base models. If set to False, it will return
all tuned models.

Args:
  config (ListModelsConfigOrDict): Configuration for retrieving models.
...
```

#### `recontext_image(*, model: str, source: Union[google.genai.types.RecontextImageSource, google.genai.types.RecontextImageSourceDict], config: Union[google.genai.types.RecontextImageConfig, google.genai.types.RecontextImageConfigDict, NoneType] = None) -> google.genai.types.RecontextImageResponse`

```
Recontextualizes an image.

There is one type of recontextualization currently supported:
1) Virtual Try-On: Generate images of persons modeling fashion products.

Args:
  model (str): The model to use.
  source (RecontextImageSource): An object containing the source inputs
...
```

#### `segment_image(*, model: str, source: Union[google.genai.types.SegmentImageSource, google.genai.types.SegmentImageSourceDict], config: Union[google.genai.types.SegmentImageConfig, google.genai.types.SegmentImageConfigDict, NoneType] = None) -> google.genai.types.SegmentImageResponse`

```
Segments an image, creating a mask of a specified area.

Args:
  model (str): The model to use.
  source (SegmentImageSource): An object containing the source inputs
    (prompt, image, scribble_image) for image segmentation. The prompt is
    required for prompt mode and semantic mode, disallowed for other modes.
    scribble_image is required for the interactive mode, disallowed for
...
```

#### `update(*, model: str, config: Union[google.genai.types.UpdateModelConfig, google.genai.types.UpdateModelConfigDict, NoneType] = None) -> google.genai.types.Model`

#### `upscale_image(*, model: str, image: Union[google.genai.types.Image, google.genai.types.ImageDict], upscale_factor: str, config: Union[google.genai.types.UpscaleImageConfig, google.genai.types.UpscaleImageConfigDict, NoneType] = None) -> google.genai.types.UpscaleImageResponse`

```
Makes an API request to upscale a provided image.

Args:
  model (str): The model to use.
  image (Image): The input image for upscaling.
  upscale_factor (str): The factor to upscale the image (x2 or x4).
  config (UpscaleImageConfig): Configuration for upscaling.

...
```

### Sub-resource: `operations`

#### `get(operation: ~T, *, config: Union[google.genai.types.GetOperationConfig, google.genai.types.GetOperationConfigDict, NoneType] = None) -> ~T`

```
Gets the status of a long-running operation.

Args:
  operation (Operation): The operation instance to get the status for.
  config (GetOperationConfig): Configuration for getting the operation.

Returns:
  Operation: The updated operation instance with the latest status or
...
```

### Sub-resource: `tunings`

#### `cancel(*, name: str, config: Union[google.genai.types.CancelTuningJobConfig, google.genai.types.CancelTuningJobConfigDict, NoneType] = None) -> google.genai.types.CancelTuningJobResponse`

```
Cancels a tuning job asynchronously.

Args:
  name (str): A TuningJob resource name.
```

#### `get(*, name: str, config: Union[google.genai.types.GetTuningJobConfig, google.genai.types.GetTuningJobConfigDict, NoneType] = None) -> google.genai.types.TuningJob`

#### `list(*, config: Union[google.genai.types.ListTuningJobsConfig, google.genai.types.ListTuningJobsConfigDict, NoneType] = None) -> google.genai.pagers.AsyncPager[google.genai.types.TuningJob]`

```
Lists `TuningJob` objects asynchronously.

Args:
  config: The configuration for the list request.

Returns:
  A Pager object that contains one page of tuning jobs. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

#### `tune(*, base_model: str, training_dataset: Union[google.genai.types.TuningDataset, google.genai.types.TuningDatasetDict], config: Union[google.genai.types.CreateTuningJobConfig, google.genai.types.CreateTuningJobConfigDict, NoneType] = None) -> google.genai.types.TuningJob`

### Sub-resource: `webhooks`

#### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

#### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

#### Sub-resource: `with_raw_response`

##### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

##### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

##### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

##### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

##### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

##### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

---

## `client.auth_tokens`

[Experimental] Auth Tokens API client.

This class provides methods for creating auth tokens.

### `create(*, config: Union[google.genai.types.CreateAuthTokenConfig, google.genai.types.CreateAuthTokenConfigDict, NoneType] = None) -> google.genai.types.AuthToken`

```
[Experimental] Creates an auth token.

Args:
  config (CreateAuthTokenConfig): Optional configuration for the request.

The CreateAuthTokenConfig's `live_constrained_parameters` attrubite
Can be used to lock the parameters of the live session so they
can't be changed client side. This behavior has two basic modes depending on
...
```

---

## `client.batches`

### `cancel(*, name: str, config: Union[google.genai.types.CancelBatchJobConfig, google.genai.types.CancelBatchJobConfigDict, NoneType] = None) -> None`

```
Cancels a batch job.

Only available for batch jobs that are running or pending.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the Vertex AI client. Or
...
```

### `create(*, model: str, src: Union[google.genai.types.BatchJobSource, list[google.genai.types.InlinedRequest], str, google.genai.types.BatchJobSourceDict, list[google.genai.types.InlinedRequestDict]], config: Union[google.genai.types.CreateBatchJobConfig, google.genai.types.CreateBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
Creates a batch job.

Args:
  model (str): The model to use for the batch job.
  src: The source of the batch job. Currently Vertex AI supports GCS URI(-s)
    or BigQuery URI. Example: "gs://path/to/input/data" or
    "bq://projectId.bqDatasetId.bqTableId". Gemini Developer API supports
    List of inlined_request, or file name. Example: "files/file_name".
...
```

### `create_embeddings(*, model: str, src: Union[google.genai.types.EmbeddingsBatchJobSource, google.genai.types.EmbeddingsBatchJobSourceDict], config: Union[google.genai.types.CreateEmbeddingsBatchJobConfig, google.genai.types.CreateEmbeddingsBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
**Experimental** Creates an embedding batch job.

Args:
  model (str): The model to use for the batch job.
  src: Gemini Developer API supports List of inlined_request, or file name.
    Example: "files/file_name".
  config (CreateBatchJobConfig): Optional configuration for the batch job.

...
```

### `delete(*, name: str, config: Union[google.genai.types.DeleteBatchJobConfig, google.genai.types.DeleteBatchJobConfigDict, NoneType] = None) -> google.genai.types.DeleteResourceJob`

```
Deletes a batch job.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the client.

Returns:
...
```

### `get(*, name: str, config: Union[google.genai.types.GetBatchJobConfig, google.genai.types.GetBatchJobConfigDict, NoneType] = None) -> google.genai.types.BatchJob`

```
Gets a batch job.

Args:
  name (str): A fully-qualified BatchJob resource name or ID.
    Example: "projects/.../locations/.../batchPredictionJobs/456" or "456"
      when project and location are initialized in the Vertex AI client. Or
      "batches/abc" using the Gemini Developer AI client.

...
```

### `list(*, config: Union[google.genai.types.ListBatchJobsConfig, google.genai.types.ListBatchJobsConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.BatchJob]`

```
Lists batch jobs.

Args:
  config (ListBatchJobsConfig): Optional configuration for the list request.

Returns:
  A Pager object that contains one page of batch jobs. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

---

## `client.caches`

### `create(*, model: str, config: Union[google.genai.types.CreateCachedContentConfig, google.genai.types.CreateCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Creates a cached contents resource.

Usage:

.. code-block:: python

  contents = ... // Initialize the content to cache.
  response = client.caches.create(
...
```

### `delete(*, name: str, config: Union[google.genai.types.DeleteCachedContentConfig, google.genai.types.DeleteCachedContentConfigDict, NoneType] = None) -> google.genai.types.DeleteCachedContentResponse`

```
Deletes cached content.

Usage:

.. code-block:: python

  client.caches.delete(name= ... ) // The server-generated resource name.
```

### `get(*, name: str, config: Union[google.genai.types.GetCachedContentConfig, google.genai.types.GetCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Gets cached content configurations.

.. code-block:: python

  client.caches.get(name= ... ) // The server-generated resource name.
```

### `list(*, config: Union[google.genai.types.ListCachedContentsConfig, google.genai.types.ListCachedContentsConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.CachedContent]`

```
Lists cached contents.

Args:
  config (ListCachedContentsConfig): Optional configuration for the list
    request.

Returns:
  A Pager object that contains one page of cached contents. When iterating
...
```

### `update(*, name: str, config: Union[google.genai.types.UpdateCachedContentConfig, google.genai.types.UpdateCachedContentConfigDict, NoneType] = None) -> google.genai.types.CachedContent`

```
Updates cached content configurations.

.. code-block:: python

  response = client.caches.update(
      name= ... // The server-generated resource name.
      config={
          'ttl': '7600s',
...
```

---

## `client.chats`

A util class to create chat sessions.

### `create(*, model: str, config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None, history: Optional[list[Union[google.genai.types.Content, google.genai.types.ContentDict]]] = None) -> google.genai.chats.Chat`

```
Creates a new chat session.

Args:
  model: The model to use for the chat.
  config: The configuration to use for the generate content request.
  history: The history to use for the chat.

Returns:
...
```

---

## `client.file_search_stores`

### `create(*, config: Union[google.genai.types.CreateFileSearchStoreConfig, google.genai.types.CreateFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.FileSearchStore`

```
Creates a File Search Store.

Args:
  config (CreateFileSearchStoreConfig | None): Optional parameters for the
    request.

Returns:
  FileSearchStore
```

### `delete(*, name: str, config: Union[google.genai.types.DeleteFileSearchStoreConfig, google.genai.types.DeleteFileSearchStoreConfigDict, NoneType] = None) -> None`

```
Deletes a FileSearchStore.

Args:
  name (str): The resource name of the FileSearchStore. Example:
    `FileSearchStores/my-file-search-store-123`
  config (DeleteFileSearchStoreConfig | None): Optional parameters for the
    request.

...
```

### `get(*, name: str, config: Union[google.genai.types.GetFileSearchStoreConfig, google.genai.types.GetFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.FileSearchStore`

```
Gets metadata about a FileSearchStore.

Args:
  name (str): The resource name of the FileSearchStore. Example:
    `FileSearchStores/my-file-search-store-123`
  config (GetFileSearchStoreConfig | None): Optional parameters for the
    request.

...
```

### `import_file(*, file_search_store_name: str, file_name: str, config: Union[google.genai.types.ImportFileConfig, google.genai.types.ImportFileConfigDict, NoneType] = None) -> google.genai.types.ImportFileOperation`

```
Imports a File from File Service to a FileSearchStore.

This is a long-running operation, see aip.dev/151

Args:
  file_search_store_name (str): The resource name of the FileSearchStore.
    Example: `fileSearchStores/my-file-search-store-123`
  file_name (str): The resource name of the File to import. Example:
...
```

### `list(*, config: Union[google.genai.types.ListFileSearchStoresConfig, google.genai.types.ListFileSearchStoresConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.FileSearchStore]`

```
Lists FileSearchStores.

Args:
  config (ListFileSearchStoresConfig): Optional configuration for the list
    request.

Returns:
  A Pager object that contains one page of file search stores. When
...
```

### `upload_to_file_search_store(*, file_search_store_name: str, file: Union[str, os.PathLike[str], io.IOBase], config: Union[google.genai.types.UploadToFileSearchStoreConfig, google.genai.types.UploadToFileSearchStoreConfigDict, NoneType] = None) -> google.genai.types.UploadToFileSearchStoreOperation`

```
Calls the API to upload a file to the given file search store.

Args:
  file_search_store_name: The resource name of the FileSearchStore. Example:
    `fileSearchStores/file-search-store-123`
  file: A path to the file or an `IOBase` object to be uploaded. If it's an
    IOBase object, it must be opened in blocking (the default) mode and
    binary mode. In other words, do not use non-blocking mode or text mode.
...
```

### Sub-resource: `documents`

#### `delete(*, name: str, config: Union[google.genai.types.DeleteDocumentConfig, google.genai.types.DeleteDocumentConfigDict, NoneType] = None) -> None`

```
Deletes a Document.

Args:
  name (str): The resource name of the Document.
    Example: ragStores/rag-store-foo/documents/documents-bar
  config (DeleteDocumentConfig | None): Optional parameters for the request.

Returns:
...
```

#### `get(*, name: str, config: Union[google.genai.types.GetDocumentConfig, google.genai.types.GetDocumentConfigDict, NoneType] = None) -> google.genai.types.Document`

```
Gets metadata about a Document.

Args:
  name (str): The resource name of the Document.
    Example: ragStores/rag-store-foo/documents/documents-bar
  config (GetDocumentConfig | None): Optional parameters for the request.

Returns:
...
```

#### `list(*, parent: str, config: Union[google.genai.types.ListDocumentsConfig, google.genai.types.ListDocumentsConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.Document]`

```
Lists documents.

Args:
  parent (str): The name of the RagStore containing the Documents.
  config (ListDocumentsConfig): Optional configuration for the list request.

Returns:
  A Pager object that contains one page of documents. When iterating over
...
```

---

## `client.files`

### `delete(*, name: str, config: Union[google.genai.types.DeleteFileConfig, google.genai.types.DeleteFileConfigDict, NoneType] = None) -> google.genai.types.DeleteFileResponse`

```
Deletes a remotely stored file.

Args:
  name (str): The name identifier for the file to delete.
  config (DeleteFileConfig): Optional, configuration for the delete method.

Returns:
  DeleteFileResponse: The response for the delete method
...
```

### `download(*, file: Union[str, google.genai.types.File, google.genai.types.Video, google.genai.types.GeneratedVideo], config: Union[google.genai.types.DownloadFileConfig, google.genai.types.DownloadFileConfigDict, NoneType] = None) -> bytes`

```
Downloads a file's data from storage.

Files created by `upload` can't be downloaded. You can tell which files are
downloadable by checking the `source` or `download_uri` property.

Note: This method returns the data as bytes. For `Video` and
`GeneratedVideo` objects there is an additional side effect, that it also
sets the `video_bytes` property on the `Video` object.
...
```

### `get(*, name: str, config: Union[google.genai.types.GetFileConfig, google.genai.types.GetFileConfigDict, NoneType] = None) -> google.genai.types.File`

```
Retrieves the file information from the service.

Args:
  name (str): The name identifier for the file to retrieve.
  config (GetFileConfig): Optional, configuration for the get method.

Returns:
  File: The file information.
...
```

### `list(*, config: Union[google.genai.types.ListFilesConfig, google.genai.types.ListFilesConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.File]`

```
Lists all files from the service.

Args:
  config (ListFilesConfig): Optional, configuration for the list method.

Returns:
  A Pager object that contains one page of files. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

### `register_files(*, auth: google.auth.credentials.Credentials, uris: list[str], config: Union[google.genai.types.RegisterFilesConfig, google.genai.types.RegisterFilesConfigDict, NoneType] = None) -> google.genai.types.RegisterFilesResponse`

```
Registers gcs files with the file service.
```

### `upload(*, file: Union[str, os.PathLike[str], io.IOBase], config: Union[google.genai.types.UploadFileConfig, google.genai.types.UploadFileConfigDict, NoneType] = None) -> google.genai.types.File`

```
Calls the API to upload a file using a supported file service.

Args:
  file: A path to the file or an `IOBase` object to be uploaded. If it's an
    IOBase object, it must be opened in blocking (the default) mode and
    binary mode. In other words, do not use non-blocking mode or text mode.
    The given stream must be seekable, that is, it must be able to call
    `seek()` on 'path'.
...
```

---

## `client.interactions`

### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

### Sub-resource: `with_raw_response`

#### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

#### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

### Sub-resource: `with_streaming_response`

#### `cancel(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction'`

```
Cancels an interaction by id.

This only applies to background interactions that
are still running.

Args:
  extra_headers: Send extra headers

...
```

#### `create(*, api_version: 'str | None' = None, input: 'interaction_create_params.Input', model: 'ModelParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, background: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, generation_config: 'GenerationConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, previous_interaction_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_format: 'object | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_mime_type: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, response_modalities: "List[Literal['text', 'image', 'audio', 'video', 'document']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, service_tier: "Literal['flex', 'standard', 'priority'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, store: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, system_instruction: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, tools: 'Iterable[ToolParam] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, webhook_config: 'WebhookConfigParam | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent: "Union[str, Literal['deep-research-pro-preview-12-2025']] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, agent_config: 'interaction_create_params.AgentConfig | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'object'`

```
Deletes the interaction by id.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, include_input: 'bool | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, last_event_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, stream: 'Literal[False] | Literal[True] | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Interaction | Stream[InteractionSSEEvent]'`

---

## `client.models`

### `compute_tokens(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.ComputeTokensConfig, google.genai.types.ComputeTokensConfigDict, NoneType] = None) -> google.genai.types.ComputeTokensResponse`

```
Given a list of contents, returns a corresponding TokensInfo containing the

list of tokens and list of token ids.

This method is not supported by the Gemini Developer API.

Args:
  model (str): The model to use.
...
```

### `count_tokens(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.CountTokensConfig, google.genai.types.CountTokensConfigDict, NoneType] = None) -> google.genai.types.CountTokensResponse`

```
Counts the number of tokens in the given content.

Multimodal input is supported for Gemini models.

Args:
  model (str): The model to use for counting tokens.
  contents (list[types.Content]): The content to count tokens for.
  config (CountTokensConfig): The configuration for counting tokens.
...
```

### `delete(*, model: str, config: Union[google.genai.types.DeleteModelConfig, google.genai.types.DeleteModelConfigDict, NoneType] = None) -> google.genai.types.DeleteModelResponse`

### `edit_image(*, model: str, prompt: str, reference_images: list[typing.Union[google.genai.types._ReferenceImageAPI, google.genai.types._ReferenceImageAPIDict]], config: Union[google.genai.types.EditImageConfig, google.genai.types.EditImageConfigDict, NoneType] = None) -> google.genai.types.EditImageResponse`

```
Edits an image based on a text description and configuration.

Args:
  model (str): The model to use.
  prompt (str): A text description of the edit to apply to the image.
    reference_images (list[Union[RawReferenceImage, MaskReferenceImage,
    ControlReferenceImage, StyleReferenceImage, SubjectReferenceImage]): The
    reference images for editing.
...
```

### `embed_content(*, model: str, contents: Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]], list[Union[google.genai.types.Content, str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.Part]]]], google.genai.types.ContentDict, google.genai.types.FileDict, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.EmbedContentConfig, google.genai.types.EmbedContentConfigDict, NoneType] = None) -> google.genai.types.EmbedContentResponse`

```
Calculates embeddings for the given contents.

Args:
  model (str): The model to use.
  contents (list[Content]): The contents to embed.
  config (EmbedContentConfig): Optional configuration for embeddings.

Usage:
...
```

### `generate_content(*, model: str, contents: Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None) -> google.genai.types.GenerateContentResponse`

```
Makes an API request to generate content using a model.

For the `model` parameter, supported formats for Vertex AI API include:
- The Gemini model ID, for example: 'gemini-2.0-flash'
- The full resource name starts with 'projects/', for example:
  'projects/my-project-id/locations/us-central1/publishers/google/models/gemini-2.0-flash'
- The partial resource name with 'publishers/', for example:
  'publishers/google/models/gemini-2.0-flash' or
...
```

### `generate_content_stream(*, model: str, contents: Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]], list[Union[google.genai.types.Content, google.genai.types.ContentDict, str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict, list[Union[str, PIL.Image.Image, google.genai.types.File, google.genai.types.FileDict, google.genai.types.Part, google.genai.types.PartDict]]]]], config: Union[google.genai.types.GenerateContentConfig, google.genai.types.GenerateContentConfigDict, NoneType] = None) -> Iterator[google.genai.types.GenerateContentResponse]`

```
Makes an API request to generate content using a model and yields the model's response in chunks.

For the `model` parameter, supported formats for Vertex AI API include:
- The Gemini model ID, for example: 'gemini-2.0-flash'
- The full resource name starts with 'projects/', for example:
  'projects/my-project-id/locations/us-central1/publishers/google/models/gemini-2.0-flash'
- The partial resource name with 'publishers/', for example:
  'publishers/google/models/gemini-2.0-flash' or
...
```

### `generate_images(*, model: str, prompt: str, config: Union[google.genai.types.GenerateImagesConfig, google.genai.types.GenerateImagesConfigDict, NoneType] = None) -> google.genai.types.GenerateImagesResponse`

```
Generates images based on a text description and configuration.

Args:
  model (str): The model to use.
  prompt (str): A text description of the images to generate.
  config (GenerateImagesConfig): Configuration for generation.

Usage:
...
```

### `generate_videos(*, model: str, prompt: Optional[str] = None, image: Union[google.genai.types.Image, google.genai.types.ImageDict, NoneType] = None, video: Union[google.genai.types.Video, google.genai.types.VideoDict, NoneType] = None, source: Union[google.genai.types.GenerateVideosSource, google.genai.types.GenerateVideosSourceDict, NoneType] = None, config: Union[google.genai.types.GenerateVideosConfig, google.genai.types.GenerateVideosConfigDict, NoneType] = None) -> google.genai.types.GenerateVideosOperation`

```
Generates videos based on an input (text, image, or video) and configuration.

The following use cases are supported:
1. Text to video generation.
2a. Image to video generation (additional text prompt is optional).
2b. Image to video generation with frame interpolation (specify last_frame
in config).
3. Video extension (additional text prompt is optional)
...
```

### `get(*, model: str, config: Union[google.genai.types.GetModelConfig, google.genai.types.GetModelConfigDict, NoneType] = None) -> google.genai.types.Model`

### `list(*, config: Union[google.genai.types.ListModelsConfig, google.genai.types.ListModelsConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.Model]`

```
Makes an API request to list the available models.

If `query_base` is set to True in the config or not set (default), the
API will return all available base models. If set to False, it will return
all tuned models.

Args:
  config (ListModelsConfigOrDict): Configuration for retrieving models.
...
```

### `recontext_image(*, model: str, source: Union[google.genai.types.RecontextImageSource, google.genai.types.RecontextImageSourceDict], config: Union[google.genai.types.RecontextImageConfig, google.genai.types.RecontextImageConfigDict, NoneType] = None) -> google.genai.types.RecontextImageResponse`

```
Recontextualizes an image.

There is one type of recontextualization currently supported:
1) Virtual Try-On: Generate images of persons modeling fashion products.

Args:
  model (str): The model to use.
  source (RecontextImageSource): An object containing the source inputs
...
```

### `segment_image(*, model: str, source: Union[google.genai.types.SegmentImageSource, google.genai.types.SegmentImageSourceDict], config: Union[google.genai.types.SegmentImageConfig, google.genai.types.SegmentImageConfigDict, NoneType] = None) -> google.genai.types.SegmentImageResponse`

```
Segments an image, creating a mask of a specified area.

Args:
  model (str): The model to use.
  source (SegmentImageSource): An object containing the source inputs
    (prompt, image, scribble_image) for image segmentation. The prompt is
    required for prompt mode and semantic mode, disallowed for other modes.
    scribble_image is required for the interactive mode, disallowed for
...
```

### `update(*, model: str, config: Union[google.genai.types.UpdateModelConfig, google.genai.types.UpdateModelConfigDict, NoneType] = None) -> google.genai.types.Model`

### `upscale_image(*, model: str, image: Union[google.genai.types.Image, google.genai.types.ImageDict], upscale_factor: str, config: Union[google.genai.types.UpscaleImageConfig, google.genai.types.UpscaleImageConfigDict, NoneType] = None) -> google.genai.types.UpscaleImageResponse`

```
Makes an API request to upscale a provided image.

Args:
  model (str): The model to use.
  image (Image): The input image for upscaling.
  upscale_factor (str): The factor to upscale the image (x2 or x4).
  config (UpscaleImageConfig): Configuration for upscaling.

...
```

---

## `client.operations`

### `get(operation: ~T, *, config: Union[google.genai.types.GetOperationConfig, google.genai.types.GetOperationConfigDict, NoneType] = None) -> ~T`

```
Gets the status of a long-running operation.

Args:
  operation (Operation): The operation instance to get the status for.
  config (GetOperationConfig): Configuration for getting the operation.

Returns:
  Operation: The updated operation instance with the latest status or
...
```

---

## `client.tunings`

### `cancel(*, name: str, config: Union[google.genai.types.CancelTuningJobConfig, google.genai.types.CancelTuningJobConfigDict, NoneType] = None) -> google.genai.types.CancelTuningJobResponse`

```
Cancels a tuning job.

Args:
  name (str): TuningJob resource name.
```

### `get(*, name: str, config: Union[google.genai.types.GetTuningJobConfig, google.genai.types.GetTuningJobConfigDict, NoneType] = None) -> google.genai.types.TuningJob`

### `list(*, config: Union[google.genai.types.ListTuningJobsConfig, google.genai.types.ListTuningJobsConfigDict, NoneType] = None) -> google.genai.pagers.Pager[google.genai.types.TuningJob]`

```
Lists `TuningJob` objects.

Args:
  config: The configuration for the list request.

Returns:
  A Pager object that contains one page of tuning jobs. When iterating over
  the pager, it automatically fetches the next page if there are more.
...
```

### `tune(*, base_model: str, training_dataset: Union[google.genai.types.TuningDataset, google.genai.types.TuningDatasetDict], config: Union[google.genai.types.CreateTuningJobConfig, google.genai.types.CreateTuningJobConfigDict, NoneType] = None) -> google.genai.types.TuningJob`

---

## `client.webhooks`

### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

### Sub-resource: `with_raw_response`

#### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

#### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

### Sub-resource: `with_streaming_response`

#### `create(*, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', webhook_id: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Creates a new Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```

#### `delete(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookDeleteResponse'`

```
Deletes a Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `get(id: 'str', *, api_version: 'str | None' = None, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Gets a specific Webhook.

Args:
  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request

  extra_body: Add additional JSON properties to the request
...
```

#### `list(*, api_version: 'str | None' = None, page_size: 'int | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, page_token: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookListResponse'`

```
Lists all Webhooks.

Args:
  page_size: Optional.

The maximum number of webhooks to return. The service may return fewer
      than this value. If unspecified, at most 50 webhooks will be returned. The
      maximum value is 1000.
...
```

#### `ping(id: 'str', *, api_version: 'str | None' = None, body: 'webhook_ping_params.Body | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookPingResponse'`

```
Sends a ping event to a Webhook.

Args:
  body: Request message for WebhookService.PingWebhook.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `rotate_signing_secret(id: 'str', *, api_version: 'str | None' = None, revocation_behavior: "Literal['revoke_previous_secrets_after_h24', 'revoke_previous_secrets_immediately'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'WebhookRotateSigningSecretResponse'`

```
Generates a new signing secret for a Webhook.

Args:
  revocation_behavior: Optional. The revocation behavior for previous signing secrets.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(id: 'str', *, api_version: 'str | None' = None, subscribed_events: "List[Union[Literal['batch.succeeded', 'batch.cancelled', 'batch.expired', 'batch.failed', 'interaction.requires_action', 'interaction.completed', 'interaction.failed', 'interaction.cancelled', 'video.generated'], str]]", uri: 'str', update_mask: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, name: 'str | Omit' = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, state: "Literal['enabled', 'disabled', 'disabled_due_to_failed_deliveries'] | Omit" = <google.genai._interactions.Omit object at 0x7ec2a22e70b0>, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Webhook'`

```
Updates an existing Webhook.

Args:
  subscribed_events:
      Required.

The events that the webhook is subscribed to. Available events:

...
```
