# Anthropic Claude API — Quick Reference

A condensed lookup card for the most-used endpoints. For the full method-level reference, see `API_REFERENCE.md`.

**Base URL:** `https://api.anthropic.com`
**Required headers on every request:**
- `x-api-key: sk-ant-...`
- `anthropic-version: 2023-06-01`
- `content-type: application/json`

---

## Core: Messages API

### `POST /v1/messages` — single response
```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-opus-4-7",
    "max_tokens": 1024,
    "system": "You are a helpful assistant.",
    "messages": [
      {"role": "user", "content": "Hello"}
    ]
  }'
```

Required body fields: `model`, `max_tokens`, `messages`.

Notable optional fields:
- `system` — string or array of content blocks (top-level, not in messages)
- `temperature` (0..1, default 1.0) — **disallowed on Opus 4.7+** (returns 400)
- `tools` — array of tool definitions
- `tool_choice` — `{"type": "auto" | "any" | "tool" | "none"}`
- `stop_sequences` — list of strings
- `stream` — boolean (use SSE if true)
- `thinking` — `{"type": "enabled", "budget_tokens": N}` for extended thinking
- `metadata.user_id` — opaque user identifier for abuse tracking

### `POST /v1/messages` with streaming
Set `"stream": true`. Response is a stream of SSE events: `message_start`, `content_block_start`, `content_block_delta`, `content_block_stop`, `message_delta`, `message_stop`, plus optional `ping` keep-alives.

### `POST /v1/messages/count_tokens`
Same body as `/v1/messages` but returns `{"input_tokens": N}` without billing.

### `POST /v1/messages/batches`
Submit up to 10,000 requests for async processing at 50% discount. Each item in `requests` array has `custom_id` and `params` (full Messages body).

```json
{
  "requests": [
    {
      "custom_id": "request-1",
      "params": {
        "model": "claude-opus-4-7",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": "Hello"}]
      }
    }
  ]
}
```

Then `GET /v1/messages/batches/{id}` to check status; results downloadable from `results_url` once complete (~24h SLA).

---

## Models

### `GET /v1/models`
Lists all available models with metadata: `id`, `display_name`, `created_at`, `max_input_tokens`, `max_tokens`, `capabilities`.

### `GET /v1/models/{model_id}`
Single model details.

---

## Files

### `POST /v1/files` — upload
Multipart upload. Returns `file_id` usable in messages content as `{"type": "document", "source": {"type": "file", "file_id": "..."}}`.

### `GET /v1/files`, `GET /v1/files/{id}`, `DELETE /v1/files/{id}`

---

## Tools (in Messages requests)

### Tool definition shape
```json
{
  "name": "get_weather",
  "description": "Get current weather for a location",
  "input_schema": {
    "type": "object",
    "properties": {
      "location": {"type": "string"}
    },
    "required": ["location"]
  }
}
```

### Built-in / server tools
Provided by Anthropic, no schema needed:
- `{"type": "web_search_20250305", "name": "web_search"}` — web search
- `{"type": "web_fetch_20250910", "name": "web_fetch"}` — URL fetch
- `{"type": "code_execution_20250522", "name": "code_execution"}` — Python sandbox
- `{"type": "computer_20250124", "name": "computer", ...}` — screen / mouse / keyboard
- `{"type": "bash_20250124", "name": "bash"}` — shell
- `{"type": "text_editor_20250124", "name": "str_replace_editor"}` — file editing
- `{"type": "memory_20250818", "name": "memory"}` — persistent memory
- `{"type": "advisor_20251024", "name": "advisor"}` — agent advice loop

Most server tools require an `anthropic-beta` header to enable.

---

## Beta features (set `anthropic-beta` header)

| Beta | Use |
|---|---|
| `prompt-caching-2024-07-31` | Mark `cache_control` on content blocks |
| `extended-cache-ttl-2025-04-11` | 1-hour cache TTL |
| `output-300k-2026-03-24` | Increase max output to 300k tokens |
| `computer-use-2025-01-24` | Computer use tool |
| `pdfs-2024-09-25` | PDF input (now mostly GA) |
| `managed-agents-2026-04-01` | Claude Managed Agents API |

Stack via comma: `anthropic-beta: prompt-caching-2024-07-31,output-300k-2026-03-24`

---

## Prompt caching

Add `cache_control` to a content block to mark it as a cache breakpoint:
```json
{
  "type": "text",
  "text": "<long system prompt or document>",
  "cache_control": {"type": "ephemeral"}
}
```
- 5 minutes TTL by default; 1 hour with `extended-cache-ttl-2025-04-11` beta
- Cache write costs 1.25× base; cache reads cost 0.1× base
- Up to 4 cache breakpoints per request
- Cache is matched by exact-prefix hash through the breakpoint

---

## Errors

Standard JSON error envelope:
```json
{
  "type": "error",
  "error": {
    "type": "invalid_request_error",
    "message": "..."
  }
}
```

Common `error.type` values:
- `invalid_request_error` (400)
- `authentication_error` (401)
- `permission_error` (403)
- `not_found_error` (404)
- `request_too_large` (413)
- `rate_limit_error` (429)
- `api_error` (500)
- `overloaded_error` (529)

---

## Admin API (separate auth)

Under `/v1/organizations/{org_id}/...` for org admins. Uses `x-api-key` set to an Admin API key (different from regular API keys). Covers:
- API keys CRUD
- Workspaces CRUD
- Workspace members
- Invites
- Usage and cost reports

See full method list in `API_REFERENCE.md` under `client.beta.organizations` etc.

---

## Vertex AI / Bedrock variants

**Vertex AI:**
- Base URL: `https://{LOCATION}-aiplatform.googleapis.com`
- Path: `/v1/projects/{project}/locations/{location}/publishers/anthropic/models/{model}:rawPredict` (or `:streamRawPredict`)
- Auth: GCP OAuth (no `x-api-key`)
- Model IDs: `claude-opus-4-7@YYYYMMDD`
- SDK: `from anthropic import AnthropicVertex`

**AWS Bedrock:**
- Auth: AWS SigV4
- Model IDs: `anthropic.claude-opus-4-7-YYYYMMDD-v1:0`
- SDK: `from anthropic import AnthropicBedrock`
- Available APIs: native Bedrock InvokeModel/Converse, or Anthropic Messages-compatible via `bedrock-mantle` endpoint
