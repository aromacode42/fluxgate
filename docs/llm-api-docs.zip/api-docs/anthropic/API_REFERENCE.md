# Anthropic Claude Python SDK — API Reference

**SDK Version:** `0.97.0`
**API Base URL:** `https://api.anthropic.com`
**API Version Header:** `anthropic-version: 2023-06-01`

> Auto-generated from SDK introspection.

## Required Headers

| Header | Required | Example |
|---|---|---|
| `x-api-key` | Yes | `sk-ant-...` |
| `anthropic-version` | Yes | `2023-06-01` |
| `content-type` | Yes | `application/json` |
| `anthropic-beta` | No | `prompt-caching-2024-07-31` (comma-separate multiple) |

---

## Top-level Resources on `Anthropic` client

| Resource | Class |
|---|---|
| `client.beta` | `Beta` |
| `client.completions` | `Completions` |
| `client.messages` | `Messages` |
| `client.models` | `Models` |
| `client.qs` | `Querystring` |
| `client.timeout` | `Timeout` |
| `client.with_raw_response` | `AnthropicWithRawResponse` |
| `client.with_streaming_response` | `AnthropicWithStreamedResponse` |

---

## `client.beta`

### Sub-resource: `agents`

#### `archive(agent_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Archive Agent

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `create(*, model: 'agent_create_params.Model', name: 'str', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaManagedAgentsURLMCPServerParams] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, skills: 'Iterable[BetaManagedAgentsSkillParams] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Iterable[agent_create_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Create Agent

Args:
  model: Model identifier.

Accepts the
      [model string](https://platform.claude.com/docs/en/about-claude/models/overview#latest-models-comparison),
      e.g. `claude-opus-4-6`, or a `model_config` object for additional configuration
...
```

#### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agents

Args:
  created_at_gte: Return agents created at or after this time (inclusive).

  created_at_lte: Return agents created at or before this time (inclusive).

  include_archived: Include archived agents in results. Defaults to false.
...
```

#### `retrieve(agent_id: 'str', *, version: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Get Agent

Args:
  version: Agent version.

Omit for the most recent version. Must be at least 1 if
      specified.

...
```

#### `update(agent_id: 'str', *, version: 'int', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Optional[Iterable[BetaManagedAgentsURLMCPServerParams]] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, model: 'agent_update_params.Model | Omit' = OMIT, name: 'str | Omit' = OMIT, skills: 'Optional[Iterable[BetaManagedAgentsSkillParams]] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Optional[Iterable[agent_update_params.Tool]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Update Agent

Args:
  version: The agent's current version, used to prevent concurrent overwrites. Obtain this
      value from a create or retrieve response. The request fails if this does not
      match the server's current version.

  description: Description. Up to 2048 characters. Omit to preserve; send empty string or null
...
```

#### Sub-resource: `versions`

##### `list(agent_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agent Versions

Args:
  limit: Maximum results per page.

Default 20, maximum 100.

  page: Opaque pagination cursor.
...
```

##### Sub-resource: `with_raw_response`

###### `list(agent_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agent Versions

Args:
  limit: Maximum results per page.

Default 20, maximum 100.

  page: Opaque pagination cursor.
...
```

##### Sub-resource: `with_streaming_response`

###### `list(agent_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agent Versions

Args:
  limit: Maximum results per page.

Default 20, maximum 100.

  page: Opaque pagination cursor.
...
```

#### Sub-resource: `with_raw_response`

##### `archive(agent_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Archive Agent

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, model: 'agent_create_params.Model', name: 'str', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaManagedAgentsURLMCPServerParams] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, skills: 'Iterable[BetaManagedAgentsSkillParams] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Iterable[agent_create_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Create Agent

Args:
  model: Model identifier.

Accepts the
      [model string](https://platform.claude.com/docs/en/about-claude/models/overview#latest-models-comparison),
      e.g. `claude-opus-4-6`, or a `model_config` object for additional configuration
...
```

##### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agents

Args:
  created_at_gte: Return agents created at or after this time (inclusive).

  created_at_lte: Return agents created at or before this time (inclusive).

  include_archived: Include archived agents in results. Defaults to false.
...
```

##### `retrieve(agent_id: 'str', *, version: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Get Agent

Args:
  version: Agent version.

Omit for the most recent version. Must be at least 1 if
      specified.

...
```

##### `update(agent_id: 'str', *, version: 'int', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Optional[Iterable[BetaManagedAgentsURLMCPServerParams]] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, model: 'agent_update_params.Model | Omit' = OMIT, name: 'str | Omit' = OMIT, skills: 'Optional[Iterable[BetaManagedAgentsSkillParams]] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Optional[Iterable[agent_update_params.Tool]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Update Agent

Args:
  version: The agent's current version, used to prevent concurrent overwrites. Obtain this
      value from a create or retrieve response. The request fails if this does not
      match the server's current version.

  description: Description. Up to 2048 characters. Omit to preserve; send empty string or null
...
```

##### Sub-resource: `versions`

###### `list(agent_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agent Versions

Args:
  limit: Maximum results per page.

Default 20, maximum 100.

  page: Opaque pagination cursor.
...
```

#### Sub-resource: `with_streaming_response`

##### `archive(agent_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Archive Agent

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, model: 'agent_create_params.Model', name: 'str', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaManagedAgentsURLMCPServerParams] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, skills: 'Iterable[BetaManagedAgentsSkillParams] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Iterable[agent_create_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Create Agent

Args:
  model: Model identifier.

Accepts the
      [model string](https://platform.claude.com/docs/en/about-claude/models/overview#latest-models-comparison),
      e.g. `claude-opus-4-6`, or a `model_config` object for additional configuration
...
```

##### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agents

Args:
  created_at_gte: Return agents created at or after this time (inclusive).

  created_at_lte: Return agents created at or before this time (inclusive).

  include_archived: Include archived agents in results. Defaults to false.
...
```

##### `retrieve(agent_id: 'str', *, version: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Get Agent

Args:
  version: Agent version.

Omit for the most recent version. Must be at least 1 if
      specified.

...
```

##### `update(agent_id: 'str', *, version: 'int', description: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Optional[Iterable[BetaManagedAgentsURLMCPServerParams]] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, model: 'agent_update_params.Model | Omit' = OMIT, name: 'str | Omit' = OMIT, skills: 'Optional[Iterable[BetaManagedAgentsSkillParams]] | Omit' = OMIT, system: 'Optional[str] | Omit' = OMIT, tools: 'Optional[Iterable[agent_update_params.Tool]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsAgent'`

```
Update Agent

Args:
  version: The agent's current version, used to prevent concurrent overwrites. Obtain this
      value from a create or retrieve response. The request fails if this does not
      match the server's current version.

  description: Description. Up to 2048 characters. Omit to preserve; send empty string or null
...
```

##### Sub-resource: `versions`

###### `list(agent_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsAgent]'`

```
List Agent Versions

Args:
  limit: Maximum results per page.

Default 20, maximum 100.

  page: Opaque pagination cursor.
...
```

### Sub-resource: `environments`

#### `archive(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Archive an environment by ID.

Archived environments cannot be used to create new
sessions.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

...
```

#### `create(*, name: 'str', config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Create a new environment with the specified configuration.

Args:
  name: Human-readable name for the environment

  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.
...
```

#### `delete(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironmentDeleteResponse'`

```
Delete an environment by ID.

Returns a confirmation of the deletion.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaEnvironment]'`

```
List environments with pagination support.

Args:
  include_archived: Include archived environments in the response

  limit: Maximum number of environments to return

  page: Opaque cursor from previous response for pagination. Pass the `next_page` value
...
```

#### `retrieve(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Retrieve a specific environment by ID.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(environment_id: 'str', *, config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, Optional[str]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Update an existing environment's configuration.

Args:
  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.

  description: Updated description of the environment
...
```

#### Sub-resource: `with_raw_response`

##### `archive(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Archive an environment by ID.

Archived environments cannot be used to create new
sessions.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

...
```

##### `create(*, name: 'str', config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Create a new environment with the specified configuration.

Args:
  name: Human-readable name for the environment

  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.
...
```

##### `delete(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironmentDeleteResponse'`

```
Delete an environment by ID.

Returns a confirmation of the deletion.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaEnvironment]'`

```
List environments with pagination support.

Args:
  include_archived: Include archived environments in the response

  limit: Maximum number of environments to return

  page: Opaque cursor from previous response for pagination. Pass the `next_page` value
...
```

##### `retrieve(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Retrieve a specific environment by ID.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(environment_id: 'str', *, config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, Optional[str]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Update an existing environment's configuration.

Args:
  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.

  description: Updated description of the environment
...
```

#### Sub-resource: `with_streaming_response`

##### `archive(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Archive an environment by ID.

Archived environments cannot be used to create new
sessions.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

...
```

##### `create(*, name: 'str', config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Create a new environment with the specified configuration.

Args:
  name: Human-readable name for the environment

  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.
...
```

##### `delete(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironmentDeleteResponse'`

```
Delete an environment by ID.

Returns a confirmation of the deletion.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaEnvironment]'`

```
List environments with pagination support.

Args:
  include_archived: Include archived environments in the response

  limit: Maximum number of environments to return

  page: Opaque cursor from previous response for pagination. Pass the `next_page` value
...
```

##### `retrieve(environment_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Retrieve a specific environment by ID.

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(environment_id: 'str', *, config: 'Optional[BetaCloudConfigParams] | Omit' = OMIT, description: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, Optional[str]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaEnvironment'`

```
Update an existing environment's configuration.

Args:
  config: Request params for `cloud` environment configuration.

      Fields default to null; on update, omitted fields preserve the existing value.

  description: Updated description of the environment
...
```

### Sub-resource: `files`

#### `delete(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedFile'`

```
Delete File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### `download(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BinaryAPIResponse'`

```
Download File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, scope_id: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileMetadata]'`

```
List Files

Args:
  after_id: ID of the object to use as a cursor for pagination.

When provided, returns the
      page of results immediately after this object.

...
```

#### `retrieve_metadata(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Get File Metadata

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### `upload(*, file: 'FileTypes', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Upload File

Args:
  file: The file to upload

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_raw_response`

##### `delete(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedFile'`

```
Delete File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `download(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BinaryAPIResponse'`

```
Download File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, scope_id: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileMetadata]'`

```
List Files

Args:
  after_id: ID of the object to use as a cursor for pagination.

When provided, returns the
      page of results immediately after this object.

...
```

##### `retrieve_metadata(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Get File Metadata

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `upload(*, file: 'FileTypes', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Upload File

Args:
  file: The file to upload

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_streaming_response`

##### `delete(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedFile'`

```
Delete File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `download(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BinaryAPIResponse'`

```
Download File

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, scope_id: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[FileMetadata]'`

```
List Files

Args:
  after_id: ID of the object to use as a cursor for pagination.

When provided, returns the
      page of results immediately after this object.

...
```

##### `retrieve_metadata(file_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Get File Metadata

Args:
  file_id: ID of the File.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `upload(*, file: 'FileTypes', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'FileMetadata'`

```
Upload File

Args:
  file: The file to upload

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

### Sub-resource: `memory_stores`

#### `archive(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
ArchiveMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `create(*, name: 'str', description: 'str | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
CreateMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `delete(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemoryStore'`

```
DeleteMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryStore]'`

```
ListMemoryStores

Args:
  created_at_gte: Return stores created at or after this time (inclusive).

  created_at_lte: Return stores created at or before this time (inclusive).

  include_archived: Query parameter for include_archived
...
```

#### `retrieve(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
GetMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(memory_store_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
UpdateMemoryStore

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve. The stored bag is limited to 16 keys (up to 64 chars
      each) with values up to 512 chars.
...
```

#### Sub-resource: `memories`

##### `create(memory_store_id: 'str', *, content: 'Optional[str]', path: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
CreateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `delete(memory_id: 'str', *, memory_store_id: 'str', expected_content_sha256: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemory'`

```
DeleteMemory

Args:
  expected_content_sha256: Query parameter for expected_content_sha256

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `list(memory_store_id: 'str', *, depth: 'int | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: 'str | Omit' = OMIT, page: 'str | Omit' = OMIT, path_prefix: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryListItem]'`

```
ListMemories

Args:
  depth: Query parameter for depth

  limit: Query parameter for limit

  order: Query parameter for order
...
```

##### `retrieve(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
GetMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `update(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, content: 'Optional[str] | Omit' = OMIT, path: 'Optional[str] | Omit' = OMIT, precondition: 'BetaManagedAgentsPreconditionParam | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
UpdateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_raw_response`

###### `create(memory_store_id: 'str', *, content: 'Optional[str]', path: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
CreateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `delete(memory_id: 'str', *, memory_store_id: 'str', expected_content_sha256: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemory'`

```
DeleteMemory

Args:
  expected_content_sha256: Query parameter for expected_content_sha256

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `list(memory_store_id: 'str', *, depth: 'int | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: 'str | Omit' = OMIT, page: 'str | Omit' = OMIT, path_prefix: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryListItem]'`

```
ListMemories

Args:
  depth: Query parameter for depth

  limit: Query parameter for limit

  order: Query parameter for order
...
```

###### `retrieve(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
GetMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `update(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, content: 'Optional[str] | Omit' = OMIT, path: 'Optional[str] | Omit' = OMIT, precondition: 'BetaManagedAgentsPreconditionParam | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
UpdateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_streaming_response`

###### `create(memory_store_id: 'str', *, content: 'Optional[str]', path: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
CreateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `delete(memory_id: 'str', *, memory_store_id: 'str', expected_content_sha256: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemory'`

```
DeleteMemory

Args:
  expected_content_sha256: Query parameter for expected_content_sha256

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `list(memory_store_id: 'str', *, depth: 'int | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: 'str | Omit' = OMIT, page: 'str | Omit' = OMIT, path_prefix: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryListItem]'`

```
ListMemories

Args:
  depth: Query parameter for depth

  limit: Query parameter for limit

  order: Query parameter for order
...
```

###### `retrieve(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
GetMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `update(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, content: 'Optional[str] | Omit' = OMIT, path: 'Optional[str] | Omit' = OMIT, precondition: 'BetaManagedAgentsPreconditionParam | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
UpdateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `memory_versions`

##### `list(memory_store_id: 'str', *, api_key_id: 'str | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, limit: 'int | Omit' = OMIT, memory_id: 'str | Omit' = OMIT, operation: 'BetaManagedAgentsMemoryVersionOperation | Omit' = OMIT, page: 'str | Omit' = OMIT, session_id: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryVersion]'`

```
ListMemoryVersions

Args:
  api_key_id: Query parameter for api_key_id

  created_at_gte: Return versions created at or after this time (inclusive).

  created_at_lte: Return versions created at or before this time (inclusive).
...
```

##### `redact(memory_version_id: 'str', *, memory_store_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
RedactMemoryVersion

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `retrieve(memory_version_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
GetMemoryVersion

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_raw_response`

###### `list(memory_store_id: 'str', *, api_key_id: 'str | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, limit: 'int | Omit' = OMIT, memory_id: 'str | Omit' = OMIT, operation: 'BetaManagedAgentsMemoryVersionOperation | Omit' = OMIT, page: 'str | Omit' = OMIT, session_id: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryVersion]'`

```
ListMemoryVersions

Args:
  api_key_id: Query parameter for api_key_id

  created_at_gte: Return versions created at or after this time (inclusive).

  created_at_lte: Return versions created at or before this time (inclusive).
...
```

###### `redact(memory_version_id: 'str', *, memory_store_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
RedactMemoryVersion

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `retrieve(memory_version_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
GetMemoryVersion

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `with_streaming_response`

###### `list(memory_store_id: 'str', *, api_key_id: 'str | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, limit: 'int | Omit' = OMIT, memory_id: 'str | Omit' = OMIT, operation: 'BetaManagedAgentsMemoryVersionOperation | Omit' = OMIT, page: 'str | Omit' = OMIT, session_id: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryVersion]'`

```
ListMemoryVersions

Args:
  api_key_id: Query parameter for api_key_id

  created_at_gte: Return versions created at or after this time (inclusive).

  created_at_lte: Return versions created at or before this time (inclusive).
...
```

###### `redact(memory_version_id: 'str', *, memory_store_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
RedactMemoryVersion

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `retrieve(memory_version_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
GetMemoryVersion

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_raw_response`

##### `archive(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
ArchiveMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, name: 'str', description: 'str | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
CreateMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `delete(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemoryStore'`

```
DeleteMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryStore]'`

```
ListMemoryStores

Args:
  created_at_gte: Return stores created at or after this time (inclusive).

  created_at_lte: Return stores created at or before this time (inclusive).

  include_archived: Query parameter for include_archived
...
```

##### `retrieve(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
GetMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(memory_store_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
UpdateMemoryStore

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve. The stored bag is limited to 16 keys (up to 64 chars
      each) with values up to 512 chars.
...
```

##### Sub-resource: `memories`

###### `create(memory_store_id: 'str', *, content: 'Optional[str]', path: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
CreateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `delete(memory_id: 'str', *, memory_store_id: 'str', expected_content_sha256: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemory'`

```
DeleteMemory

Args:
  expected_content_sha256: Query parameter for expected_content_sha256

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `list(memory_store_id: 'str', *, depth: 'int | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: 'str | Omit' = OMIT, page: 'str | Omit' = OMIT, path_prefix: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryListItem]'`

```
ListMemories

Args:
  depth: Query parameter for depth

  limit: Query parameter for limit

  order: Query parameter for order
...
```

###### `retrieve(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
GetMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `update(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, content: 'Optional[str] | Omit' = OMIT, path: 'Optional[str] | Omit' = OMIT, precondition: 'BetaManagedAgentsPreconditionParam | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
UpdateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `memory_versions`

###### `list(memory_store_id: 'str', *, api_key_id: 'str | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, limit: 'int | Omit' = OMIT, memory_id: 'str | Omit' = OMIT, operation: 'BetaManagedAgentsMemoryVersionOperation | Omit' = OMIT, page: 'str | Omit' = OMIT, session_id: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryVersion]'`

```
ListMemoryVersions

Args:
  api_key_id: Query parameter for api_key_id

  created_at_gte: Return versions created at or after this time (inclusive).

  created_at_lte: Return versions created at or before this time (inclusive).
...
```

###### `redact(memory_version_id: 'str', *, memory_store_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
RedactMemoryVersion

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `retrieve(memory_version_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
GetMemoryVersion

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

#### Sub-resource: `with_streaming_response`

##### `archive(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
ArchiveMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, name: 'str', description: 'str | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
CreateMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `delete(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemoryStore'`

```
DeleteMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryStore]'`

```
ListMemoryStores

Args:
  created_at_gte: Return stores created at or after this time (inclusive).

  created_at_lte: Return stores created at or before this time (inclusive).

  include_archived: Query parameter for include_archived
...
```

##### `retrieve(memory_store_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
GetMemoryStore

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(memory_store_id: 'str', *, description: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, name: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryStore'`

```
UpdateMemoryStore

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve. The stored bag is limited to 16 keys (up to 64 chars
      each) with values up to 512 chars.
...
```

##### Sub-resource: `memories`

###### `create(memory_store_id: 'str', *, content: 'Optional[str]', path: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
CreateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `delete(memory_id: 'str', *, memory_store_id: 'str', expected_content_sha256: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedMemory'`

```
DeleteMemory

Args:
  expected_content_sha256: Query parameter for expected_content_sha256

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `list(memory_store_id: 'str', *, depth: 'int | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, order_by: 'str | Omit' = OMIT, page: 'str | Omit' = OMIT, path_prefix: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryListItem]'`

```
ListMemories

Args:
  depth: Query parameter for depth

  limit: Query parameter for limit

  order: Query parameter for order
...
```

###### `retrieve(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
GetMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `update(memory_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, content: 'Optional[str] | Omit' = OMIT, path: 'Optional[str] | Omit' = OMIT, precondition: 'BetaManagedAgentsPreconditionParam | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemory'`

```
UpdateMemory

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### Sub-resource: `memory_versions`

###### `list(memory_store_id: 'str', *, api_key_id: 'str | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, limit: 'int | Omit' = OMIT, memory_id: 'str | Omit' = OMIT, operation: 'BetaManagedAgentsMemoryVersionOperation | Omit' = OMIT, page: 'str | Omit' = OMIT, session_id: 'str | Omit' = OMIT, view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsMemoryVersion]'`

```
ListMemoryVersions

Args:
  api_key_id: Query parameter for api_key_id

  created_at_gte: Return versions created at or after this time (inclusive).

  created_at_lte: Return versions created at or before this time (inclusive).
...
```

###### `redact(memory_version_id: 'str', *, memory_store_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
RedactMemoryVersion

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `retrieve(memory_version_id: 'str', *, memory_store_id: 'str', view: 'BetaManagedAgentsMemoryView | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsMemoryVersion'`

```
GetMemoryVersion

Args:
  view: Query parameter for view

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

### Sub-resource: `messages`

#### `count_tokens(*, messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[message_count_tokens_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

#### `create(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessage | Stream[BetaRawMessageStreamEvent]'`

#### `parse(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[type[ResponseFormatT]] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedBetaMessage[ResponseFormatT]'`

#### `stream(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'None | BetaJSONOutputFormatParam | type[ResponseFormatT] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageStreamManager[ResponseFormatT]'`

#### `tool_runner(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', tools: 'Iterable[BetaRunnableTool | BetaToolUnionParam]', compaction_control: 'CompactionControl | Omit' = OMIT, max_iterations: 'int | Omit' = OMIT, cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[type[ResponseFormatT]] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'bool | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaStreamingToolRunner[ResponseFormatT] | BetaToolRunner[ResponseFormatT]'`

```
Create a Message stream
```

#### Sub-resource: `batches`

##### `cancel(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaDeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaMessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `results(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[BetaMessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `retrieve(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### Sub-resource: `with_raw_response`

###### `cancel(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

###### `create(*, requests: 'Iterable[batch_create_params.Request]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `delete(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaDeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaMessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `results(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[BetaMessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `retrieve(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### Sub-resource: `with_streaming_response`

###### `cancel(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

###### `create(*, requests: 'Iterable[batch_create_params.Request]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `delete(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaDeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaMessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `results(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[BetaMessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `retrieve(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### Sub-resource: `with_raw_response`

##### `count_tokens(*, messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[message_count_tokens_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

##### `create(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessage | Stream[BetaRawMessageStreamEvent]'`

##### `parse(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[type[ResponseFormatT]] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedBetaMessage[ResponseFormatT]'`

##### Sub-resource: `batches`

###### `cancel(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

###### `create(*, requests: 'Iterable[batch_create_params.Request]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `delete(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaDeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaMessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `results(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[BetaMessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `retrieve(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### Sub-resource: `with_streaming_response`

##### `count_tokens(*, messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[message_count_tokens_params.Tool] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

##### `create(*, max_tokens: 'int', messages: 'Iterable[BetaMessageParam]', model: 'ModelParam', cache_control: 'Optional[BetaCacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[message_create_params.Container] | Omit' = OMIT, context_management: 'Optional[BetaContextManagementConfigParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, mcp_servers: 'Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit' = OMIT, metadata: 'BetaMetadataParam | Omit' = OMIT, output_config: 'BetaOutputConfigParam | Omit' = OMIT, output_format: 'Optional[BetaJSONOutputFormatParam] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, speed: "Optional[Literal['standard', 'fast']] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[BetaTextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'BetaThinkingConfigParam | Omit' = OMIT, tool_choice: 'BetaToolChoiceParam | Omit' = OMIT, tools: 'Iterable[BetaToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, user_profile_id: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessage | Stream[BetaRawMessageStreamEvent]'`

##### Sub-resource: `batches`

###### `cancel(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

###### `create(*, requests: 'Iterable[batch_create_params.Request]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `delete(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaDeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaMessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

###### `results(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[BetaMessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

###### `retrieve(message_batch_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaMessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

### Sub-resource: `models`

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

#### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

#### Sub-resource: `with_raw_response`

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

##### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

#### Sub-resource: `with_streaming_response`

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[BetaModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

##### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

### Sub-resource: `sessions`

#### `archive(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Archive Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `create(*, agent: 'session_create_params.Agent', environment_id: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, resources: 'Iterable[session_create_params.Resource] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Create Session

Args:
  agent: Agent identifier.

Accepts the `agent` ID string, which pins the latest version
      for the session, or an `agent` object with both id and version specified.

...
```

#### `delete(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedSession'`

```
Delete Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `list(*, agent_id: 'str | Omit' = OMIT, agent_version: 'int | Omit' = OMIT, created_at_gt: 'Union[str, datetime] | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lt: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSession]'`

```
List Sessions

Args:
  agent_id: Filter sessions created with this agent ID.

  agent_version: Filter by agent version. Only applies when agent_id is also set.

  created_at_gt: Return sessions created after this time (exclusive).
...
```

#### `retrieve(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Get Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(session_id: 'str', *, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Update Session

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve.

...
```

#### Sub-resource: `events`

##### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionEvent]'`

```
List Events

Args:
  limit: Query parameter for limit

  order: Sort direction for results, ordered by created_at. Defaults to asc
      (chronological).

...
```

##### `send(session_id: 'str', *, events: 'Iterable[BetaManagedAgentsEventParams]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSendSessionEvents'`

```
Send Events

Args:
  events: Events to send to the `session`.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

##### `stream(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Stream[BetaManagedAgentsStreamSessionEvents]'`

```
Stream Events

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `with_raw_response`

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionEvent]'`

```
List Events

Args:
  limit: Query parameter for limit

  order: Sort direction for results, ordered by created_at. Defaults to asc
      (chronological).

...
```

###### `send(session_id: 'str', *, events: 'Iterable[BetaManagedAgentsEventParams]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSendSessionEvents'`

```
Send Events

Args:
  events: Events to send to the `session`.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `stream(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Stream[BetaManagedAgentsStreamSessionEvents]'`

```
Stream Events

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `with_streaming_response`

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionEvent]'`

```
List Events

Args:
  limit: Query parameter for limit

  order: Sort direction for results, ordered by created_at. Defaults to asc
      (chronological).

...
```

###### `send(session_id: 'str', *, events: 'Iterable[BetaManagedAgentsEventParams]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSendSessionEvents'`

```
Send Events

Args:
  events: Events to send to the `session`.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `stream(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Stream[BetaManagedAgentsStreamSessionEvents]'`

```
Stream Events

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### Sub-resource: `resources`

##### `add(session_id: 'str', *, file_id: 'str', type: "Literal['file']", mount_path: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsFileResource'`

```
Add Session Resource

Args:
  file_id: ID of a previously uploaded file.

  mount_path: Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

##### `delete(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeleteSessionResource'`

```
Delete Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionResource]'`

```
List Session Resources

Args:
  limit: Maximum number of resources to return per page (max 1000). If omitted, returns
      all resources.

  page: Opaque cursor from a previous response's next_page field.

...
```

##### `retrieve(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceRetrieveResponse'`

```
Get Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(resource_id: 'str', *, session_id: 'str', authorization_token: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceUpdateResponse'`

```
Update Session Resource

Args:
  authorization_token: New authorization token for the resource. Currently only `github_repository`
      resources support token rotation.

  betas: Optional header to specify the beta version(s) you want to use.

...
```

##### Sub-resource: `with_raw_response`

###### `add(session_id: 'str', *, file_id: 'str', type: "Literal['file']", mount_path: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsFileResource'`

```
Add Session Resource

Args:
  file_id: ID of a previously uploaded file.

  mount_path: Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

###### `delete(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeleteSessionResource'`

```
Delete Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionResource]'`

```
List Session Resources

Args:
  limit: Maximum number of resources to return per page (max 1000). If omitted, returns
      all resources.

  page: Opaque cursor from a previous response's next_page field.

...
```

###### `retrieve(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceRetrieveResponse'`

```
Get Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(resource_id: 'str', *, session_id: 'str', authorization_token: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceUpdateResponse'`

```
Update Session Resource

Args:
  authorization_token: New authorization token for the resource. Currently only `github_repository`
      resources support token rotation.

  betas: Optional header to specify the beta version(s) you want to use.

...
```

##### Sub-resource: `with_streaming_response`

###### `add(session_id: 'str', *, file_id: 'str', type: "Literal['file']", mount_path: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsFileResource'`

```
Add Session Resource

Args:
  file_id: ID of a previously uploaded file.

  mount_path: Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

###### `delete(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeleteSessionResource'`

```
Delete Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionResource]'`

```
List Session Resources

Args:
  limit: Maximum number of resources to return per page (max 1000). If omitted, returns
      all resources.

  page: Opaque cursor from a previous response's next_page field.

...
```

###### `retrieve(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceRetrieveResponse'`

```
Get Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(resource_id: 'str', *, session_id: 'str', authorization_token: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceUpdateResponse'`

```
Update Session Resource

Args:
  authorization_token: New authorization token for the resource. Currently only `github_repository`
      resources support token rotation.

  betas: Optional header to specify the beta version(s) you want to use.

...
```

#### Sub-resource: `with_raw_response`

##### `archive(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Archive Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, agent: 'session_create_params.Agent', environment_id: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, resources: 'Iterable[session_create_params.Resource] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Create Session

Args:
  agent: Agent identifier.

Accepts the `agent` ID string, which pins the latest version
      for the session, or an `agent` object with both id and version specified.

...
```

##### `delete(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedSession'`

```
Delete Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, agent_id: 'str | Omit' = OMIT, agent_version: 'int | Omit' = OMIT, created_at_gt: 'Union[str, datetime] | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lt: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSession]'`

```
List Sessions

Args:
  agent_id: Filter sessions created with this agent ID.

  agent_version: Filter by agent version. Only applies when agent_id is also set.

  created_at_gt: Return sessions created after this time (exclusive).
...
```

##### `retrieve(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Get Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(session_id: 'str', *, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Update Session

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve.

...
```

##### Sub-resource: `events`

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionEvent]'`

```
List Events

Args:
  limit: Query parameter for limit

  order: Sort direction for results, ordered by created_at. Defaults to asc
      (chronological).

...
```

###### `send(session_id: 'str', *, events: 'Iterable[BetaManagedAgentsEventParams]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSendSessionEvents'`

```
Send Events

Args:
  events: Events to send to the `session`.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `stream(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Stream[BetaManagedAgentsStreamSessionEvents]'`

```
Stream Events

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `resources`

###### `add(session_id: 'str', *, file_id: 'str', type: "Literal['file']", mount_path: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsFileResource'`

```
Add Session Resource

Args:
  file_id: ID of a previously uploaded file.

  mount_path: Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

###### `delete(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeleteSessionResource'`

```
Delete Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionResource]'`

```
List Session Resources

Args:
  limit: Maximum number of resources to return per page (max 1000). If omitted, returns
      all resources.

  page: Opaque cursor from a previous response's next_page field.

...
```

###### `retrieve(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceRetrieveResponse'`

```
Get Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(resource_id: 'str', *, session_id: 'str', authorization_token: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceUpdateResponse'`

```
Update Session Resource

Args:
  authorization_token: New authorization token for the resource. Currently only `github_repository`
      resources support token rotation.

  betas: Optional header to specify the beta version(s) you want to use.

...
```

#### Sub-resource: `with_streaming_response`

##### `archive(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Archive Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, agent: 'session_create_params.Agent', environment_id: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, resources: 'Iterable[session_create_params.Resource] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Create Session

Args:
  agent: Agent identifier.

Accepts the `agent` ID string, which pins the latest version
      for the session, or an `agent` object with both id and version specified.

...
```

##### `delete(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedSession'`

```
Delete Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, agent_id: 'str | Omit' = OMIT, agent_version: 'int | Omit' = OMIT, created_at_gt: 'Union[str, datetime] | Omit' = OMIT, created_at_gte: 'Union[str, datetime] | Omit' = OMIT, created_at_lt: 'Union[str, datetime] | Omit' = OMIT, created_at_lte: 'Union[str, datetime] | Omit' = OMIT, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSession]'`

```
List Sessions

Args:
  agent_id: Filter sessions created with this agent ID.

  agent_version: Filter by agent version. Only applies when agent_id is also set.

  created_at_gt: Return sessions created after this time (exclusive).
...
```

##### `retrieve(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Get Session

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(session_id: 'str', *, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, title: 'Optional[str] | Omit' = OMIT, vault_ids: 'SequenceNotStr[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSession'`

```
Update Session

Args:
  metadata: Metadata patch.

Set a key to a string to upsert it, or to null to delete it.
      Omit the field to preserve.

...
```

##### Sub-resource: `events`

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionEvent]'`

```
List Events

Args:
  limit: Query parameter for limit

  order: Sort direction for results, ordered by created_at. Defaults to asc
      (chronological).

...
```

###### `send(session_id: 'str', *, events: 'Iterable[BetaManagedAgentsEventParams]', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsSendSessionEvents'`

```
Send Events

Args:
  events: Events to send to the `session`.

  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers
...
```

###### `stream(session_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Stream[BetaManagedAgentsStreamSessionEvents]'`

```
Stream Events

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### Sub-resource: `resources`

###### `add(session_id: 'str', *, file_id: 'str', type: "Literal['file']", mount_path: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsFileResource'`

```
Add Session Resource

Args:
  file_id: ID of a previously uploaded file.

  mount_path: Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

###### `delete(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeleteSessionResource'`

```
Delete Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(session_id: 'str', *, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsSessionResource]'`

```
List Session Resources

Args:
  limit: Maximum number of resources to return per page (max 1000). If omitted, returns
      all resources.

  page: Opaque cursor from a previous response's next_page field.

...
```

###### `retrieve(resource_id: 'str', *, session_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceRetrieveResponse'`

```
Get Session Resource

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(resource_id: 'str', *, session_id: 'str', authorization_token: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ResourceUpdateResponse'`

```
Update Session Resource

Args:
  authorization_token: New authorization token for the resource. Currently only `github_repository`
      resources support token rotation.

  betas: Optional header to specify the beta version(s) you want to use.

...
```

### Sub-resource: `skills`

#### `create(*, display_title: 'Optional[str] | Omit' = OMIT, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillCreateResponse'`

```
Create Skill

Args:
  display_title: Display title for the skill.

      This is a human-readable label that is not included in the prompt sent to the
      model.

...
```

#### `delete(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillDeleteResponse'`

```
Delete Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

#### `list(*, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, source: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[SkillListResponse]'`

```
List Skills

Args:
  limit: Number of results to return per page.

      Maximum value is 100. Defaults to 20.

  page: Pagination token for fetching a specific page of results.
...
```

#### `retrieve(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillRetrieveResponse'`

```
Get Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

#### Sub-resource: `versions`

##### `create(skill_id: 'str', *, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionCreateResponse'`

```
Create Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  files: Files to upload for the skill.
...
```

##### `delete(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionDeleteResponse'`

```
Delete Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

##### `list(skill_id: 'str', *, limit: 'Optional[int] | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[VersionListResponse]'`

```
List Skill Versions

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  limit: Number of items to return per page.
...
```

##### `retrieve(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionRetrieveResponse'`

```
Get Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

##### Sub-resource: `with_raw_response`

###### `create(skill_id: 'str', *, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionCreateResponse'`

```
Create Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  files: Files to upload for the skill.
...
```

###### `delete(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionDeleteResponse'`

```
Delete Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

###### `list(skill_id: 'str', *, limit: 'Optional[int] | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[VersionListResponse]'`

```
List Skill Versions

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  limit: Number of items to return per page.
...
```

###### `retrieve(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionRetrieveResponse'`

```
Get Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

##### Sub-resource: `with_streaming_response`

###### `create(skill_id: 'str', *, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionCreateResponse'`

```
Create Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  files: Files to upload for the skill.
...
```

###### `delete(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionDeleteResponse'`

```
Delete Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

###### `list(skill_id: 'str', *, limit: 'Optional[int] | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[VersionListResponse]'`

```
List Skill Versions

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  limit: Number of items to return per page.
...
```

###### `retrieve(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionRetrieveResponse'`

```
Get Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, display_title: 'Optional[str] | Omit' = OMIT, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillCreateResponse'`

```
Create Skill

Args:
  display_title: Display title for the skill.

      This is a human-readable label that is not included in the prompt sent to the
      model.

...
```

##### `delete(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillDeleteResponse'`

```
Delete Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

##### `list(*, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, source: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[SkillListResponse]'`

```
List Skills

Args:
  limit: Number of results to return per page.

      Maximum value is 100. Defaults to 20.

  page: Pagination token for fetching a specific page of results.
...
```

##### `retrieve(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillRetrieveResponse'`

```
Get Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

##### Sub-resource: `versions`

###### `create(skill_id: 'str', *, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionCreateResponse'`

```
Create Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  files: Files to upload for the skill.
...
```

###### `delete(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionDeleteResponse'`

```
Delete Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

###### `list(skill_id: 'str', *, limit: 'Optional[int] | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[VersionListResponse]'`

```
List Skill Versions

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  limit: Number of items to return per page.
...
```

###### `retrieve(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionRetrieveResponse'`

```
Get Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, display_title: 'Optional[str] | Omit' = OMIT, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillCreateResponse'`

```
Create Skill

Args:
  display_title: Display title for the skill.

      This is a human-readable label that is not included in the prompt sent to the
      model.

...
```

##### `delete(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillDeleteResponse'`

```
Delete Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

##### `list(*, limit: 'int | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, source: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[SkillListResponse]'`

```
List Skills

Args:
  limit: Number of results to return per page.

      Maximum value is 100. Defaults to 20.

  page: Pagination token for fetching a specific page of results.
...
```

##### `retrieve(skill_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SkillRetrieveResponse'`

```
Get Skill

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  betas: Optional header to specify the beta version(s) you want to use.
...
```

##### Sub-resource: `versions`

###### `create(skill_id: 'str', *, files: 'Optional[SequenceNotStr[FileTypes]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionCreateResponse'`

```
Create Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  files: Files to upload for the skill.
...
```

###### `delete(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionDeleteResponse'`

```
Delete Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

###### `list(skill_id: 'str', *, limit: 'Optional[int] | Omit' = OMIT, page: 'Optional[str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[VersionListResponse]'`

```
List Skill Versions

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  limit: Number of items to return per page.
...
```

###### `retrieve(version: 'str', *, skill_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'VersionRetrieveResponse'`

```
Get Skill Version

Args:
  skill_id: Unique identifier for the skill.

      The format and length of IDs may change over time.

  version: Version identifier for the skill.
...
```

### Sub-resource: `user_profiles`

#### `create(*, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Create User Profile

Args:
  external_id: Platform's own identifier for this user. Not enforced unique. Maximum 255
      characters.

  metadata: Free-form key-value data to attach to this user profile. Maximum 16 keys, with
      keys up to 64 characters and values up to 512 characters. Values must be
...
```

#### `create_enrollment_url(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfileEnrollmentURL'`

```
Create Enrollment URL

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `list(*, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaUserProfile]'`

```
List User Profiles

Args:
  limit: Query parameter for limit

  order: Query parameter for order

  page: Query parameter for page
...
```

#### `retrieve(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Get User Profile

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(user_profile_id: 'str', *, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Update User Profile

Args:
  external_id: If present, replaces the stored external_id. Omit to leave unchanged. Maximum
      255 characters.

  metadata: Key-value pairs to merge into the stored metadata. Keys provided overwrite
      existing values. To remove a key, set its value to an empty string. Keys not
...
```

#### Sub-resource: `with_raw_response`

##### `create(*, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Create User Profile

Args:
  external_id: Platform's own identifier for this user. Not enforced unique. Maximum 255
      characters.

  metadata: Free-form key-value data to attach to this user profile. Maximum 16 keys, with
      keys up to 64 characters and values up to 512 characters. Values must be
...
```

##### `create_enrollment_url(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfileEnrollmentURL'`

```
Create Enrollment URL

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaUserProfile]'`

```
List User Profiles

Args:
  limit: Query parameter for limit

  order: Query parameter for order

  page: Query parameter for page
...
```

##### `retrieve(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Get User Profile

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(user_profile_id: 'str', *, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Update User Profile

Args:
  external_id: If present, replaces the stored external_id. Omit to leave unchanged. Maximum
      255 characters.

  metadata: Key-value pairs to merge into the stored metadata. Keys provided overwrite
      existing values. To remove a key, set its value to an empty string. Keys not
...
```

#### Sub-resource: `with_streaming_response`

##### `create(*, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Create User Profile

Args:
  external_id: Platform's own identifier for this user. Not enforced unique. Maximum 255
      characters.

  metadata: Free-form key-value data to attach to this user profile. Maximum 16 keys, with
      keys up to 64 characters and values up to 512 characters. Values must be
...
```

##### `create_enrollment_url(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfileEnrollmentURL'`

```
Create Enrollment URL

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, limit: 'int | Omit' = OMIT, order: "Literal['asc', 'desc'] | Omit" = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaUserProfile]'`

```
List User Profiles

Args:
  limit: Query parameter for limit

  order: Query parameter for order

  page: Query parameter for page
...
```

##### `retrieve(user_profile_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Get User Profile

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(user_profile_id: 'str', *, external_id: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaUserProfile'`

```
Update User Profile

Args:
  external_id: If present, replaces the stored external_id. Omit to leave unchanged. Maximum
      255 characters.

  metadata: Key-value pairs to merge into the stored metadata. Keys provided overwrite
      existing values. To remove a key, set its value to an empty string. Keys not
...
```

### Sub-resource: `vaults`

#### `archive(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Archive Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `create(*, display_name: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Create Vault

Args:
  display_name: Human-readable name for the vault.

1-255 characters.

  metadata: Arbitrary key-value metadata to attach to the vault. Maximum 16 pairs, keys up
...
```

#### `delete(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedVault'`

```
Delete Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsVault]'`

```
List Vaults

Args:
  include_archived: Whether to include archived vaults in the results.

  limit: Maximum number of vaults to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_vaults` response.
...
```

#### `retrieve(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Get Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

#### `update(vault_id: 'str', *, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Update Vault

Args:
  display_name: Updated human-readable name for the vault.

1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

#### Sub-resource: `credentials`

##### `archive(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Archive Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(vault_id: 'str', *, auth: 'credential_create_params.Auth', display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Create Credential

Args:
  auth: Authentication details for creating a credential.

  display_name: Human-readable name for the credential. Up to 255 characters.

  metadata: Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys
...
```

##### `delete(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedCredential'`

```
Delete Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(vault_id: 'str', *, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsCredential]'`

```
List Credentials

Args:
  include_archived: Whether to include archived credentials in the results.

  limit: Maximum number of credentials to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_credentials` response.
...
```

##### `retrieve(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Get Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(credential_id: 'str', *, vault_id: 'str', auth: 'credential_update_params.Auth | Omit' = OMIT, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Update Credential

Args:
  auth: Updated authentication details for a credential.

  display_name: Updated human-readable name for the credential. 1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

##### Sub-resource: `with_raw_response`

###### `archive(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Archive Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `create(vault_id: 'str', *, auth: 'credential_create_params.Auth', display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Create Credential

Args:
  auth: Authentication details for creating a credential.

  display_name: Human-readable name for the credential. Up to 255 characters.

  metadata: Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys
...
```

###### `delete(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedCredential'`

```
Delete Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(vault_id: 'str', *, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsCredential]'`

```
List Credentials

Args:
  include_archived: Whether to include archived credentials in the results.

  limit: Maximum number of credentials to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_credentials` response.
...
```

###### `retrieve(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Get Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(credential_id: 'str', *, vault_id: 'str', auth: 'credential_update_params.Auth | Omit' = OMIT, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Update Credential

Args:
  auth: Updated authentication details for a credential.

  display_name: Updated human-readable name for the credential. 1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

##### Sub-resource: `with_streaming_response`

###### `archive(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Archive Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `create(vault_id: 'str', *, auth: 'credential_create_params.Auth', display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Create Credential

Args:
  auth: Authentication details for creating a credential.

  display_name: Human-readable name for the credential. Up to 255 characters.

  metadata: Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys
...
```

###### `delete(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedCredential'`

```
Delete Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(vault_id: 'str', *, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsCredential]'`

```
List Credentials

Args:
  include_archived: Whether to include archived credentials in the results.

  limit: Maximum number of credentials to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_credentials` response.
...
```

###### `retrieve(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Get Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(credential_id: 'str', *, vault_id: 'str', auth: 'credential_update_params.Auth | Omit' = OMIT, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Update Credential

Args:
  auth: Updated authentication details for a credential.

  display_name: Updated human-readable name for the credential. 1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

#### Sub-resource: `with_raw_response`

##### `archive(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Archive Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, display_name: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Create Vault

Args:
  display_name: Human-readable name for the vault.

1-255 characters.

  metadata: Arbitrary key-value metadata to attach to the vault. Maximum 16 pairs, keys up
...
```

##### `delete(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedVault'`

```
Delete Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsVault]'`

```
List Vaults

Args:
  include_archived: Whether to include archived vaults in the results.

  limit: Maximum number of vaults to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_vaults` response.
...
```

##### `retrieve(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Get Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(vault_id: 'str', *, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Update Vault

Args:
  display_name: Updated human-readable name for the vault.

1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

##### Sub-resource: `credentials`

###### `archive(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Archive Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `create(vault_id: 'str', *, auth: 'credential_create_params.Auth', display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Create Credential

Args:
  auth: Authentication details for creating a credential.

  display_name: Human-readable name for the credential. Up to 255 characters.

  metadata: Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys
...
```

###### `delete(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedCredential'`

```
Delete Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(vault_id: 'str', *, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsCredential]'`

```
List Credentials

Args:
  include_archived: Whether to include archived credentials in the results.

  limit: Maximum number of credentials to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_credentials` response.
...
```

###### `retrieve(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Get Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(credential_id: 'str', *, vault_id: 'str', auth: 'credential_update_params.Auth | Omit' = OMIT, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Update Credential

Args:
  auth: Updated authentication details for a credential.

  display_name: Updated human-readable name for the credential. 1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

#### Sub-resource: `with_streaming_response`

##### `archive(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Archive Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `create(*, display_name: 'str', metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Create Vault

Args:
  display_name: Human-readable name for the vault.

1-255 characters.

  metadata: Arbitrary key-value metadata to attach to the vault. Maximum 16 pairs, keys up
...
```

##### `delete(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedVault'`

```
Delete Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `list(*, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsVault]'`

```
List Vaults

Args:
  include_archived: Whether to include archived vaults in the results.

  limit: Maximum number of vaults to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_vaults` response.
...
```

##### `retrieve(vault_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Get Vault

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

##### `update(vault_id: 'str', *, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsVault'`

```
Update Vault

Args:
  display_name: Updated human-readable name for the vault.

1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

##### Sub-resource: `credentials`

###### `archive(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Archive Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `create(vault_id: 'str', *, auth: 'credential_create_params.Auth', display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Dict[str, str] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Create Credential

Args:
  auth: Authentication details for creating a credential.

  display_name: Human-readable name for the credential. Up to 255 characters.

  metadata: Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys
...
```

###### `delete(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsDeletedCredential'`

```
Delete Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `list(vault_id: 'str', *, include_archived: 'bool | Omit' = OMIT, limit: 'int | Omit' = OMIT, page: 'str | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPageCursor[BetaManagedAgentsCredential]'`

```
List Credentials

Args:
  include_archived: Whether to include archived credentials in the results.

  limit: Maximum number of credentials to return per page. Defaults to 20, maximum 100.

  page: Opaque pagination token from a previous `list_credentials` response.
...
```

###### `retrieve(credential_id: 'str', *, vault_id: 'str', betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Get Credential

Args:
  betas: Optional header to specify the beta version(s) you want to use.

  extra_headers: Send extra headers

  extra_query: Add additional query parameters to the request
...
```

###### `update(credential_id: 'str', *, vault_id: 'str', auth: 'credential_update_params.Auth | Omit' = OMIT, display_name: 'Optional[str] | Omit' = OMIT, metadata: 'Optional[Dict[str, Optional[str]]] | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'BetaManagedAgentsCredential'`

```
Update Credential

Args:
  auth: Updated authentication details for a credential.

  display_name: Updated human-readable name for the credential. 1-255 characters.

  metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
...
```

---

## `client.completions`

### `create(*, max_tokens_to_sample: 'int', model: 'ModelParam', prompt: 'str', metadata: 'MetadataParam | Omit' = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `with_raw_response`

#### `create(*, max_tokens_to_sample: 'int', model: 'ModelParam', prompt: 'str', metadata: 'MetadataParam | Omit' = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `with_streaming_response`

#### `create(*, max_tokens_to_sample: 'int', model: 'ModelParam', prompt: 'str', metadata: 'MetadataParam | Omit' = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

---

## `client.messages`

### `count_tokens(*, messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[MessageCountTokensToolParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

### `create(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message | Stream[RawMessageStreamEvent]'`

### `parse(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'Optional[type[ResponseFormatT]] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ParsedMessage[ResponseFormatT]'`

### `stream(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type[ResponseFormatT] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageStreamManager[ResponseFormatT]'`

```
Create a Message stream
```

### Sub-resource: `batches`

#### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

#### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

#### `results(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'JSONLDecoder[MessageBatchIndividualResponse]'`

```
Streams the results of a Message Batch as a `.jsonl` file.

Each line in the file is a JSON object containing the result of a single request
in the Message Batch. Results are not guaranteed to be in the same order as
requests. Use the `custom_id` field to match results to requests.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### Sub-resource: `with_raw_response`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

#### Sub-resource: `with_streaming_response`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

### Sub-resource: `with_raw_response`

#### `count_tokens(*, messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[MessageCountTokensToolParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

#### `create(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message | Stream[RawMessageStreamEvent]'`

#### Sub-resource: `batches`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

### Sub-resource: `with_streaming_response`

#### `count_tokens(*, messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[MessageCountTokensToolParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

#### `create(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message | Stream[RawMessageStreamEvent]'`

#### Sub-resource: `batches`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

---

## `client.models`

### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[ModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

### Sub-resource: `with_raw_response`

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[ModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

#### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

### Sub-resource: `with_streaming_response`

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[ModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

#### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

---

## `client.qs`

### `parse(query: 'str') -> 'Mapping[str, object]'`

### `stringify(params: 'Params', *, array_format: 'ArrayFormat | NotGiven' = NOT_GIVEN, nested_format: 'NestedFormat | NotGiven' = NOT_GIVEN) -> 'str'`

### `stringify_items(params: 'Params', *, array_format: 'ArrayFormat | NotGiven' = NOT_GIVEN, nested_format: 'NestedFormat | NotGiven' = NOT_GIVEN) -> 'list[tuple[str, str]]'`

---

## `client.timeout`

Timeout configuration.

**Usage**:

Timeout(None)               # No timeouts.
Timeout(5.0)                # 5s timeout on all operations.
Timeout(None, connect=5.0)  # 5s timeout on connect, no other timeouts.
Timeout(5.0, connect=10.0)  # 10s timeout on connect. 5s timeout elsewhere.
Timeout(5.0, pool=None)     # No timeout on acquiring connection from pool.
                            # 5s timeout elsewhere.

### `as_dict() -> 'dict[str, float | None]'`

---

## `client.with_raw_response`

### Sub-resource: `completions`

#### `create(*, max_tokens_to_sample: 'int', model: 'ModelParam', prompt: 'str', metadata: 'MetadataParam | Omit' = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `messages`

#### `count_tokens(*, messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[MessageCountTokensToolParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

#### `create(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message | Stream[RawMessageStreamEvent]'`

#### Sub-resource: `batches`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

### Sub-resource: `models`

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[ModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

#### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```

---

## `client.with_streaming_response`

### Sub-resource: `completions`

#### `create(*, max_tokens_to_sample: 'int', model: 'ModelParam', prompt: 'str', metadata: 'MetadataParam | Omit' = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Completion | Stream[Completion]'`

### Sub-resource: `messages`

#### `count_tokens(*, messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, output_format: 'None | JSONOutputFormatParam | type | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[MessageCountTokensToolParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageTokensCount'`

```
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)

...
```

#### `create(*, max_tokens: 'int', messages: 'Iterable[MessageParam]', model: 'ModelParam', cache_control: 'Optional[CacheControlEphemeralParam] | Omit' = OMIT, container: 'Optional[str] | Omit' = OMIT, inference_geo: 'Optional[str] | Omit' = OMIT, metadata: 'MetadataParam | Omit' = OMIT, output_config: 'OutputConfigParam | Omit' = OMIT, service_tier: "Literal['auto', 'standard_only'] | Omit" = OMIT, stop_sequences: 'SequenceNotStr[str] | Omit' = OMIT, stream: 'Literal[False] | Literal[True] | Omit' = OMIT, system: 'Union[str, Iterable[TextBlockParam]] | Omit' = OMIT, temperature: 'float | Omit' = OMIT, thinking: 'ThinkingConfigParam | Omit' = OMIT, tool_choice: 'ToolChoiceParam | Omit' = OMIT, tools: 'Iterable[ToolUnionParam] | Omit' = OMIT, top_k: 'int | Omit' = OMIT, top_p: 'float | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'Message | Stream[RawMessageStreamEvent]'`

#### Sub-resource: `batches`

##### `cancel(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Batches may be canceled any time before processing ends.

Once cancellation is
initiated, the batch enters a `canceling` state, at which time the system may
complete any in-progress, non-interruptible requests before finalizing
cancellation.

The number of canceled requests is specified in `request_counts`. To determine
...
```

##### `create(*, requests: 'Iterable[batch_create_params.Request]', extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
Send a batch of Message creation requests.

The Message Batches API can be used to process multiple Messages API requests at
once. Once a Message Batch is created, it begins processing immediately. Batches
can take up to 24 hours to complete.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

##### `delete(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'DeletedMessageBatch'`

```
Delete a Message Batch.

Message Batches can only be deleted once they've finished processing. If you'd
like to delete an in-progress batch, you must first cancel it.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[MessageBatch]'`

```
List all Message Batches within a Workspace.

Most recently created batches are
returned first.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)

...
```

##### `retrieve(message_batch_id: 'str', *, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'MessageBatch'`

```
This endpoint is idempotent and can be used to poll for Message Batch
completion.

To access the results of a Message Batch, make a request to the
`results_url` field in the response.

Learn more about the Message Batches API in our
[user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
...
```

### Sub-resource: `models`

#### `list(*, after_id: 'str | Omit' = OMIT, before_id: 'str | Omit' = OMIT, limit: 'int | Omit' = OMIT, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'SyncPage[ModelInfo]'`

```
List available models.

The Models API response can be used to determine which models are available for
use in the API. More recently released models are listed first.

Args:
  after_id: ID of the object to use as a cursor for pagination. When provided, returns the
      page of results immediately after this object.
...
```

#### `retrieve(model_id: 'str', *, betas: 'List[AnthropicBetaParam] | Omit' = OMIT, extra_headers: 'Headers | None' = None, extra_query: 'Query | None' = None, extra_body: 'Body | None' = None, timeout: 'float | httpx.Timeout | None | NotGiven' = NOT_GIVEN) -> 'ModelInfo'`

```
Get a specific model.

The Models API response can be used to determine information about a specific
model or resolve a model alias to a model ID.

Args:
  model_id: Model identifier or alias.

...
```
